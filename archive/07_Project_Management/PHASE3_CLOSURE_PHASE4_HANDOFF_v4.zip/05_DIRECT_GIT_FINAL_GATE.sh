#!/usr/bin/env bash
# FINAL PHASE 3 GIT GATE
# Run from repository root.
COMMIT="a838a9423fc3d14c46f8cd176bafed3b691e65c0"
ROOT="03_Clinical_Knowledge/population/population_packages"

echo "TOTAL:"
git ls-tree -r --name-only "$COMMIT" -- "$ROOT/" | wc -l

for f in   "01_CKO.md"   "02_KNOWLEDGE_PASSPORT.md"   "03_PRIMARY_EVIDENCE_PACKAGE.md"   "04_QA_REPORT.md"
do
  printf "%s = " "$f"
  git ls-tree -r --name-only "$COMMIT" -- "$ROOT/" | grep -c "/$f$"
done
