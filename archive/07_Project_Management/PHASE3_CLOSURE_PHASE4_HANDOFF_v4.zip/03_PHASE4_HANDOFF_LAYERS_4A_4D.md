# PHASE 4 HANDOFF — LAYERS 4A–4D

## Entry baseline

Immutable Phase 3 commit:

`a838a9423fc3d14c46f8cd176bafed3b691e65c0`

## Layer 4A — Registry / Manifest Integration Verification

- Treat the corrected Manifest as the registry source.
- `PP ID` remains the key.
- `PP Title` remains the dedicated title field.
- `Repository Path` is exact Git-derived path.
- `Status` is verification state.
- Current Status = `PENDING`.
- Notes = `GOLD aggregate verification = PENDING`.

## Layer 4B — Repository Resolution Verification

For each PP:
1. Resolve exact Repository Path.
2. Confirm folder exists.
3. Confirm four canonical Gold artifacts exist.
4. Confirm no broken registry references.

Expected: 239/239 packages and 956/956 artifacts.

## Layer 4C — Governance / Verification State

Use a controlled Status vocabulary.

Current state:
`PENDING`

After successful aggregate verification:
`PASS`

Do not overload Status with lifecycle labels such as `GOLD`.

## Layer 4D — Immutable Integration Evidence

Record:
- repository
- branch
- commit SHA
- exact PP path
- artifact set
- verification result

Evidence chain:

`PP ID → exact path → 4 Gold artifacts → Git commit → Layer 4 integration record`

## Phase 4 rule

Do not re-author Phase 3 Gold content unless a concrete integration defect is discovered.
