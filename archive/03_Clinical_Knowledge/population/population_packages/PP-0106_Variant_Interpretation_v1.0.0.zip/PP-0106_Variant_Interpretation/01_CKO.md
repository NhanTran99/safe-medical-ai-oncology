# 01_CKO.md

# Clinical Knowledge Object (CKO)

---

## Metadata

| Field | Value |
|---|---|
| CKO ID | CKO-PP-0106 |
| Population Package ID | PP-0106 |
| Title | Variant Interpretation |
| Clinical Domain | Gastric Cancer / Precision Oncology |
| Population Wave | Wave 1 |
| Version | 1.0.0 |
| Audience | General public, patients with gastric cancer, caregivers |
| Reading Level | Plain language |
| Status | Approved |
| Last Updated | 2026-08-08 |

---

# Educational Objectives

After reading this Population Package, the reader should be able to:

- Understand what a genomic variant is in the context of molecular testing.
- Understand why finding a variant is not the same as understanding what the variant means.
- Understand what variant interpretation is.
- Understand the conceptual steps from variant detection to clinical interpretation.
- Recognize that interpretation uses multiple types of scientific and clinical evidence.
- Understand the difference between evidence review and formal variant classification.
- Recognize that germline and somatic variants can require different interpretive contexts.
- Understand what a Variant of Uncertain Significance (VUS) means at a patient-facing level.
- Understand why a VUS should not automatically be treated as a disease-causing or treatment-directing finding.
- Understand that variant interpretation can change when new evidence becomes available.
- Understand why the same gene can contain variants with different clinical meanings.
- Understand the difference between clinical significance and treatment actionability.
- Understand why expert review and clinical context are important.
- Understand the relationship between variant interpretation and gastric-cancer care without receiving a disease-specific treatment algorithm.

---

# Scope

## Included

This package covers:

- definition of variant interpretation;
- the difference between variant detection and interpretation;
- the conceptual post-analytic pathway:
  detection/calling → annotation → evidence review → evidence integration → clinical-context assessment → interpretation;
- why multiple evidence sources are needed;
- biological, population, family/clinical, functional, computational and literature evidence at conceptual level;
- germline versus somatic interpretation at foundational level;
- uncertainty and VUS;
- evolving interpretation;
- context dependence;
- clinical significance versus actionability;
- professional interpretation;
- patient-facing understanding of variant reports;
- gastric-cancer examples only where they clarify the general concept.

---

## Not Included

The following are intentionally deferred:

- detailed ACMG/AMP classification;
- detailed pathogenic/benign evidence categories;
- individual evidence codes such as PVS1, PS, PM, PP, BS, BP;
- detailed Bayesian calculations;
- detailed ClinGen implementation rules;
- detailed AMP/ASCO/CAP somatic tiering;
- gene-specific classification algorithms;
- computational prediction methodology;
- bioinformatics pipelines;
- detailed germline-testing indications or workflow;
- detailed somatic-testing workflow;
- confirmatory testing workflow;
- molecular tumor profiling;
- disease-specific biomarker testing;
- treatment algorithms;
- drug selection;
- treatment recommendations.

These subjects belong to downstream or adjacent Population Packages.

---

# Knowledge Block 1 — What Is Variant Interpretation?

## Patient Explanation

A **genomic variant** is a change in genetic material identified by a molecular test.

A test may detect a variant very accurately. However, detecting the change is only the beginning.

**Variant interpretation** is the process of evaluating what that detected change may mean.

In simple terms:

> **Detection tells us that a change was found. Interpretation asks what that change means.**

The interpretation may consider the biological effect of the change, evidence from other patients and populations, laboratory and functional evidence, published research, and the clinical context.

---

## Clinical Importance

Modern sequencing can identify many genomic variants.

Not every detected variant has an established clinical meaning.

Some variants are well understood.

Some have limited evidence.

Some remain uncertain.

Therefore, a genomic report cannot be understood simply by looking at the list of variants.

---

## Key Concepts

- Variant
- Variant detection
- Variant annotation
- Variant interpretation
- Evidence
- Clinical context
- Clinical significance

---

# Knowledge Block 2 — Why Isn't Finding a Variant Enough?

## Patient Explanation

A genomic test can identify a change in DNA, but the presence of a change does not automatically tell us whether it:

- affects the function of a gene;
- contributes to disease;
- is associated with cancer risk;
- is related to the biology of a tumor;
- has a clinically useful implication.

For example, a variant in a cancer-related gene may be common in a population, rare but harmless, functionally important, or still poorly understood.

The same gene can contain many different variants with different meanings.

---

## Clinical Importance

This distinction prevents a common misunderstanding:

> **“Mutation detected” does not automatically mean “disease-causing mutation.”**

For gastric cancer, the same principle applies to both hereditary and tumor genomic findings.

A CDH1 finding, for example, cannot be interpreted solely from the fact that it is located in the CDH1 gene. The specific variant and the available evidence matter.

---

## Key Concepts

- Detection ≠ interpretation
- Gene ≠ variant
- Variant ≠ automatic pathogenicity
- Evidence determines meaning

---

# Knowledge Block 3 — What Happens After a Variant Is Detected?

## Patient Explanation

At a conceptual level, variant interpretation can be understood as a sequence:

**Variant detection/calling**
↓
**Annotation**
↓
**Evidence review**
↓
**Evidence integration**
↓
**Clinical-context assessment**
↓
**Variant interpretation**
↓
**Clinical significance / possible actionability**

Each step answers a different question.

### Detection

Was a genomic change identified by the test?

### Annotation

What is the change?

This may include the gene, location, variant type and other descriptive information.

### Evidence review

What is already known about this variant?

### Evidence integration

How do different evidence sources fit together?

### Clinical-context assessment

What does the evidence mean in this patient or tumor context?

### Interpretation

What conclusion can reasonably be reached?

### Clinical significance / actionability

Does the interpreted finding have a clinically relevant implication?

---

## Clinical Importance

This pathway shows why variant interpretation is a **post-analytic clinical process**, not simply a laboratory detection step.

Detailed methods for sequencing, bioinformatics, formal classification and treatment matching are deliberately handled elsewhere.

---

# Knowledge Block 4 — What Information Is Used to Interpret a Variant?

## Patient Explanation

Experts do not normally rely on one piece of information alone.

Depending on the type of variant and clinical question, interpretation may consider:

- laboratory information;
- population data;
- family or segregation information;
- clinical observations;
- functional studies;
- computational or biological evidence;
- published scientific literature;
- established genomic resources;
- cancer-specific evidence;
- treatment-related evidence for somatic findings.

The relevance of each evidence type depends on the question being asked.

---

## Clinical Importance

Evidence has different strengths and limitations.

A single observation should not automatically outweigh all other information.

Interpretation is therefore an evidence-integration process.

This is also why detailed evidence codes and classification rules are separate topics.

---

## Key Concepts

- Population evidence
- Clinical evidence
- Family evidence
- Functional evidence
- Computational evidence
- Literature
- Evidence integration

---

# Knowledge Block 5 — Does Interpretation Work the Same Way for Germline and Somatic Variants?

## Patient Explanation

No.

The broad principle is the same:

> **A detected variant must be interpreted using appropriate evidence and clinical context.**

But the context can be different.

### Germline variant

A germline variant is part of the person's inherited genetic information.

Interpretation may therefore focus on questions such as:

- Could this variant be associated with inherited cancer risk?
- What evidence supports or argues against that association?
- Does the result fit the person's clinical and family context?

### Somatic variant

A somatic variant is an acquired change found in tumor cells.

Interpretation may therefore focus on questions such as:

- Is this alteration relevant to tumor biology?
- Is it associated with tumor classification or prognosis?
- Is there evidence that it may have treatment-related significance?
- Is the finding specific to the tumor rather than inherited?

---

## Clinical Importance

The same genomic change can have different implications depending on whether it is being evaluated as germline or somatic information.

This is why variant interpretation must include context.

Detailed germline and somatic testing workflows are outside this package.

---

# Knowledge Block 6 — What Is a Variant of Uncertain Significance (VUS)?

## Patient Explanation

A **Variant of Uncertain Significance (VUS)** is a variant for which the available evidence is not sufficient to determine its clinical meaning with confidence.

In other words:

> **The variant has been identified, but current evidence does not allow a confident conclusion about whether it is clinically meaningful.**

A VUS is not the same as a confirmed disease-causing finding.

---

## Clinical Importance

VUS results are an important part of genetic and genomic testing.

They can occur because:

- the variant is rare;
- there are limited clinical observations;
- functional evidence is incomplete;
- population data are limited;
- different evidence sources do not yet provide a clear conclusion.

The existence of a VUS does not mean that the patient definitely has a hereditary cancer syndrome or that a tumor is driven by that alteration.

A VUS should therefore not automatically be treated as a pathogenic finding or used as the sole basis for a major clinical decision.

---

## Key Concepts

- VUS
- Uncertainty
- Insufficient evidence
- Evidence accumulation
- Reclassification

---

# Knowledge Block 7 — Can Variant Interpretation Change Over Time?

## Patient Explanation

Yes.

Variant interpretation is not always permanent.

Scientific knowledge changes.

New information may become available from:

- additional patients;
- larger population datasets;
- functional studies;
- new publications;
- improved genomic resources;
- improved interpretation methods.

As evidence changes, the interpretation of a variant may also change.

---

## Clinical Importance

A result that was uncertain in the past may become better understood later.

Likewise, an interpretation may be revised when new evidence changes the balance of available information.

This is one reason genomic knowledge must be maintained and updated over time.

---

## Key Concepts

- Evolving evidence
- Reinterpretation
- Reclassification
- Knowledge updates
- Variant databases

Detailed reclassification workflows are outside PP-0106.

---

# Knowledge Block 8 — Why Does the Same Gene Have Variants With Different Meanings?

## Patient Explanation

A gene is a long sequence of genetic information.

Different variants can affect different parts of that gene and can have very different biological effects.

Therefore:

> **A gene should not be treated as if every variant in that gene has the same meaning.**

For example, one variant may have strong evidence of clinical significance while another variant in the same gene may remain uncertain.

This is particularly important in hereditary cancer genes, including genes relevant to gastric cancer.

---

## Clinical Importance

Clinical interpretation must therefore consider the **specific variant**, not simply the gene name.

The NCI gastric-cancer genetics context illustrates why gene-specific interpretation can be important, including situations in which different types of CDH1 variants require different levels of evidence.

PP-0106 introduces this principle without teaching gene-specific classification rules.

---

# Knowledge Block 9 — What Is the Difference Between Clinical Significance and Actionability?

## Patient Explanation

A variant can have a recognized biological or clinical meaning without automatically leading to a specific treatment.

These are related but different questions.

### Clinical significance

> **What does the variant mean in the disease or inherited-risk context?**

### Actionability

> **Is there enough evidence that this finding can meaningfully influence clinical management?**

A variant may therefore be:

- biologically interesting;
- clinically significant;
- associated with prognosis;

without necessarily being a finding for which a specific treatment is recommended.

---

## Clinical Importance

This distinction is especially important in oncology.

A genomic finding should not be translated directly into:

> **“This mutation means this drug will work.”**

Clinical actionability requires additional evidence and clinical context.

Treatment selection and actionability frameworks are handled in downstream precision-oncology packages.

---

# Knowledge Block 10 — Why Is Clinical Context Essential?

## Patient Explanation

A genomic finding should be interpreted together with the situation in which it was found.

Relevant context can include:

- cancer type;
- tumor histology;
- disease stage;
- treatment history;
- specimen type;
- whether the finding is tumor-derived or germline;
- the specific clinical question;
- other pathology and laboratory findings.

For gastric cancer, the same genomic finding may need to be understood differently depending on whether the clinical question concerns hereditary risk, tumor classification, prognosis, or treatment-related information.

---

## Clinical Importance

ESMO/ASCO emphasizes placing genomic variants in the correct clinical context.

This prevents two opposite errors:

1. ignoring a clinically important finding because it is treated as “just a mutation”;
2. overinterpreting a finding without considering the patient and tumor context.

---

# Knowledge Block 11 — Why Is Expert Review Important?

## Patient Explanation

Variant interpretation can require substantial scientific and clinical knowledge.

Professionals may need to evaluate:

- laboratory quality;
- variant identity;
- evidence quality;
- literature;
- genomic resources;
- disease context;
- whether the finding is germline or somatic;
- potential clinical implications.

For complex findings, more than one specialty may contribute.

---

## Clinical Importance

Genomic interpretation is therefore not simply a task of reading a mutation list.

Appropriate professionals may include:

- molecular pathologists;
- clinical geneticists;
- genetic counselors;
- oncologists;
- laboratory/genomic specialists.

The exact team depends on the clinical question and healthcare setting.

---

# Knowledge Block 12 — What Does Variant Interpretation Mean for a Gastric Cancer Patient?

## Patient Explanation

If genomic testing is performed during gastric-cancer care, the result may contain several findings.

Some may have established significance.

Some may have limited evidence.

Some may remain uncertain.

The interpretation process helps the healthcare team distinguish among these possibilities and decide what information is clinically relevant.

The important principle is:

> **The genomic report is information that needs interpretation, not a treatment plan by itself.**

---

## Clinical Importance

Gastric cancer may involve both tumor genomic testing and hereditary cancer evaluation.

Variant interpretation provides the conceptual bridge between the genomic finding and its potential clinical meaning while leaving detailed testing and treatment decisions to the appropriate downstream packages.

---

# Common Misconceptions

## Myth 1

**“Every mutation causes cancer.”**

### Fact

A detected variant does not automatically cause cancer or have established clinical significance.

---

## Myth 2

**“If a variant is found in a cancer gene, it must be pathogenic.”**

### Fact

The specific variant and the available evidence must be evaluated.

---

## Myth 3

**“A VUS means I have a hereditary cancer syndrome.”**

### Fact

A VUS means that current evidence is insufficient to determine its clinical meaning with confidence.

---

## Myth 4

**“A VUS proves that my tumor is driven by that variant.”**

### Fact

Uncertain significance does not establish a causal role in tumor development or treatment response.

---

## Myth 5

**“A pathogenic or clinically significant variant automatically tells my doctor which drug to use.”**

### Fact

Clinical significance and treatment actionability are related but not identical.

---

## Myth 6

**“Variant interpretation is permanent.”**

### Fact

Interpretation can change when new evidence becomes available.

---

## Myth 7

**“The gene name is enough to interpret the result.”**

### Fact

Different variants in the same gene can have different biological and clinical meanings.

---

## Myth 8

**“Tumor and inherited variants are interpreted in exactly the same way.”**

### Fact

The underlying principle of evidence integration is shared, but the clinical context and questions can differ.

---

# Key Messages

- Variant interpretation begins after a genomic variant has been detected.
- Finding a variant is not the same as understanding its meaning.
- Interpretation integrates multiple sources of scientific and clinical evidence.
- The clinical context matters.
- Germline and somatic variants require context-appropriate interpretation.
- A VUS means that current evidence is insufficient for a confident clinical conclusion.
- A VUS should not automatically be treated as a pathogenic finding or as proof of cancer causation.
- Variant interpretation can change as scientific knowledge evolves.
- The same gene can contain variants with very different meanings.
- Clinical significance and treatment actionability are not identical.
- Expert review is important because genomic interpretation can be complex.
- A genomic result is not, by itself, a treatment plan.
- Detailed classification systems, evidence codes and treatment algorithms belong to downstream Population Packages.

---


# Knowledge Block 13 — How Should a Patient Read a Variant Result?

## Patient Explanation

A genomic report may contain several different pieces of information.

A patient should not assume that the most prominent-looking variant is automatically the most important one.

Useful questions include:

- What variant was identified?
- In which gene?
- Was it found in the tumor, in germline testing, or both?
- What evidence supports its interpretation?
- Is the interpretation established or uncertain?
- Does the report describe a clinical significance?
- Is there evidence of clinical actionability?
- What additional context is needed?

---

## Clinical Importance

A report is a communication tool between the laboratory and the clinical team.

Its meaning comes from the combination of:

**variant information + evidence + clinical context**

rather than from a single word such as “mutation” or “positive.”

---

## Key Concepts

- Variant report
- Evidence
- Interpretation
- Clinical significance
- Actionability
- Context

---

# Knowledge Block 14 — Why Can Two Reports Interpret the Same Variant Differently?

## Patient Explanation

Different laboratories or clinical teams may sometimes use different evidence sources, databases, reporting conventions, or dates of evidence review.

This does not necessarily mean that one report is automatically wrong.

Interpretation may depend on:

- which evidence was available;
- when the evidence was reviewed;
- the clinical context;
- whether the question is germline or somatic;
- the framework being applied.

When differences matter clinically, the appropriate response is expert review rather than choosing the interpretation that sounds most reassuring or most concerning.

---

## Clinical Importance

This is another reason genomic interpretation is a professional process and why interpretation may be revisited as evidence changes.

---

# Knowledge Block 15 — What Are the Limits of Variant Interpretation?

## Patient Explanation

Even after careful review, some variants remain uncertain.

Limitations may arise because:

- the variant is rare;
- there are few clinical observations;
- functional evidence is unavailable;
- population data are incomplete;
- studies disagree;
- the biological effect is difficult to determine;
- the clinical context is complex.

A careful interpretation may therefore be:

> **“Current evidence is not sufficient for a confident conclusion.”**

That is a valid scientific conclusion.

---

## Clinical Importance

Uncertainty is not a failure of the testing process.

It reflects the limits of current knowledge.

Presenting uncertainty honestly is safer than creating a stronger conclusion than the evidence supports.

---

# Practical Interpretation Pathway

A useful patient-facing model is:

### 1. What was found?

Identify the specific genomic variant.

### 2. Where was it found?

Determine whether the finding is from tumor material, germline testing, or another context.

### 3. What is known?

Review relevant scientific and clinical evidence.

### 4. How strong is the evidence?

Consider whether evidence is sufficient, limited, conflicting, or uncertain.

### 5. What does it mean here?

Place the finding in the patient's disease and clinical context.

### 6. Does it have clinical significance?

Determine whether the finding has an established clinical meaning.

### 7. Is it actionable?

Only if supported by appropriate clinical evidence should actionability be considered.

### 8. What remains uncertain?

Identify what the result cannot establish.

This pathway is conceptual and does not replace formal classification or treatment frameworks.

---

# Patient Safety Messages

- Do not make a major medical decision from a mutation name alone.
- Do not assume that every variant in a cancer-related gene is harmful.
- Do not treat a VUS as proof of hereditary disease.
- Do not assume that a tumor variant is inherited.
- Do not assume that a clinically significant finding automatically has an effective treatment.
- Ask what evidence supports the interpretation.
- Ask whether the finding is germline or somatic.
- Ask whether the interpretation is established or uncertain.
- Discuss individual results with the appropriate healthcare team.


# Knowledge Graph

## Prerequisite Population Packages

- PP-0099 — Molecular Testing
- PP-0101 — NGS
- PP-0102 — Gene Panel Testing
- PP-0103 — WGS
- foundational molecular-testing knowledge

These provide the conceptual foundation for understanding where a detected variant comes from.

---

## Related Population Packages

- PP-0107 — Clinical Genomics
- PP-0108 — Variant Classification
- PP-0109 — Germline Genetic Testing
- PP-0110 — Somatic Genetic Testing
- Biomarker Testing
- Molecular Tumor Profiling
- Precision Oncology
- Hereditary Gastric Cancer

---

## Next Population Package

**PP-0108 — Variant Classification**

PP-0108 provides the downstream framework for formal classification after PP-0106 has established the broader interpretation process.

---

# Revision History

| Version | Date | Summary |
|---|---|---|
| 1.0.0 | 2026-08-08 | Gold revision following locked PP-0106 Discussion Batch and Gold Population Package Specification v1.0 |

