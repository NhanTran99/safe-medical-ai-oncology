# 02_KNOWLEDGE_PASSPORT.md

# Knowledge Passport

---

# Identity

| Field | Value |
|---|---|
| Knowledge Passport ID | KP-PP-0106 |
| Population Package ID | PP-0106 |
| Clinical Knowledge Object | CKO-PP-0106 |
| Title | Variant Interpretation |
| Version | 1.0.0 |
| Status | Approved |

---

# Classification

| Field | Value |
|---|---|
| Clinical Domain | Gastric Cancer / Precision Oncology |
| Domain Code | GC / PO |
| Educational Category | Variant Interpretation |
| Educational Level | Foundational |
| Clinical Complexity | Intermediate |
| Knowledge Granularity | Atomic |
| Intended Audience | General public, patients with gastric cancer, caregivers |

---

# Primary Educational Question

> **What is Variant Interpretation?**

---

# Core Educational Function

PP-0106 explains the conceptual bridge between:

**detected genomic variant**
→ **evidence**
→ **clinical context**
→ **interpretation**
→ **clinical meaning**

It establishes foundational understanding without teaching detailed formal classification systems or treatment algorithms.

---

# Patient Journey

| Clinical Stage | Relevance |
|---|---|
| Diagnostic work-up | Yes |
| Molecular characterization | Yes |
| Treatment planning | Yes, conceptual |
| Active treatment | Yes, conceptual |
| Resistance evaluation | Yes, conceptual |
| Hereditary cancer assessment | Yes, conceptual |
| Follow-up | Yes, when genomic findings are revisited |

---

# Runtime Usage

## Primary Runtime Role

- Explain genomic variant results in plain language.
- Explain why a detected variant needs interpretation.
- Explain uncertainty and VUS.
- Explain why interpretation can change.
- Explain why clinical context matters.

## Secondary Runtime Role

- Prepare patients for discussions with oncology/genetics teams.
- Support health-literacy education.
- Connect NGS/testing packages with downstream classification packages.
- Provide a conceptual bridge for precision-oncology knowledge.

---

# Retrieval Tags

- Variant interpretation
- Genomic variant
- Variant meaning
- Variant evidence
- Clinical significance
- Clinical context
- VUS
- Variant of uncertain significance
- Germline variant
- Somatic variant
- Variant annotation
- Evidence integration
- Variant reclassification
- Genomic report
- Precision oncology
- Gastric cancer genetics
- Molecular pathology

---

# Trigger Questions

- What does “variant interpretation” mean?
- My genomic test found a mutation. What does that mean?
- Is every mutation harmful?
- Why does my doctor need to interpret the variant?
- What evidence is used to interpret a genetic variant?
- What is a VUS?
- Does a VUS mean I have hereditary cancer?
- Can a variant interpretation change later?
- Why can two variants in the same gene have different meanings?
- Is a clinically significant mutation automatically treatable?
- What is the difference between germline and tumor variants?
- Why does the cancer type matter when interpreting a variant?

---

# Scope

## Included

- Variant interpretation definition
- Detection vs interpretation
- Annotation
- Evidence review
- Evidence integration
- Clinical context
- Germline vs somatic interpretation
- VUS
- Evolving interpretation
- Clinical significance
- Actionability as a conceptual distinction
- Professional interpretation
- Gastric-cancer context

## Excluded

- ACMG/AMP detailed classification
- Individual evidence codes
- Bayesian calculations
- Detailed ClinGen implementation
- Somatic tiering
- Computational prediction methodology
- Bioinformatics pipelines
- Detailed germline testing
- Detailed somatic testing
- Confirmatory testing
- Treatment algorithms
- Drug selection

---

# Knowledge Graph

## Prerequisites

- PP-0099 — Molecular Testing
- PP-0101 — NGS
- PP-0102 — Gene Panel Testing
- PP-0103 — WGS

## Related

- PP-0107 — Clinical Genomics
- PP-0108 — Variant Classification
- PP-0109 — Germline Genetic Testing
- PP-0110 — Somatic Genetic Testing
- Precision Oncology
- Molecular Tumor Profiling
- Hereditary Gastric Cancer

## Next

**PP-0108 — Variant Classification**

---

# Primary Evidence Sources

| Priority | Source | Role |
|---|---|---|
| 1 | ESMO/ASCO Global Curriculum for Medical Oncology, 2023 | Post-analytic genomic processes; variant interpretation in clinical context |
| 2 | AMP/ASCO/CAP standards | Cancer sequence-variant interpretation/reporting framework |
| 3 | ClinGen/CGC/VICC standards | Somatic pathogenicity/oncogenicity interpretation framework |
| 4 | NCI Cancer Genetics Risk Assessment and Counseling (PDQ) | Patient-facing genetic testing outcomes, VUS and evolving interpretation |
| 5 | NCCN Gastric Cancer | Gastric-cancer molecular testing and clinical context |
| 6 | Project 18 Core Materials | Locked project architecture and scope boundaries |

---

# Evidence Classification

**Authoritative evidence synthesis**

The package is based primarily on professional oncology/genomics standards and the project's locked 18 Core Materials.

---

# Governance

| Field | Value |
|---|---|
| Clinical Governance | Enabled |
| Evidence Traceability | Complete |
| Scope Boundary | Defined |
| Knowledge Graph | Complete |
| QA Status | PASS |
| Repository Status | Ready |
| Version | 1.0.0 |

---

# Safety Boundaries

- Do not interpret an individual patient's variant from this package alone.
- Do not treat a VUS as a pathogenic finding.
- Do not infer treatment from a genomic finding without appropriate clinical evaluation.
- Do not assume tumor findings are inherited.
- Do not assume a negative or uncertain result excludes all relevant genomic information.
- Encourage discussion of individual results with qualified healthcare professionals.

---


---

# Interpretation Model

## Core Runtime Sequence

**Detected variant**
→ **What is it?**
→ **What evidence exists?**
→ **What does the evidence mean in this context?**
→ **What is the current interpretation?**
→ **Does it have clinical significance?**
→ **Is there evidence of actionability?**
→ **What remains uncertain?**

---

# Patient Safety Retrieval Rules

If a user asks about a specific variant:

1. Explain that PP-0106 provides the conceptual interpretation framework.
2. Do not independently classify the variant.
3. Do not label a VUS as pathogenic.
4. Do not infer germline status from a tumor result.
5. Do not recommend treatment based on the variant alone.
6. Direct the user toward the clinical team for individualized interpretation.

---

# Content Boundary With PP-0108

PP-0106 answers:

> **How do experts move from a detected variant to an evidence-based interpretation?**

PP-0108 answers:

> **How is a variant formally classified?**

This distinction is mandatory for retrieval and generation.


# Revision History

| Version | Date | Summary |
|---|---|---|
| 1.0.0 | 2026-08-08 | Gold revision following locked PP-0106 discussion |
