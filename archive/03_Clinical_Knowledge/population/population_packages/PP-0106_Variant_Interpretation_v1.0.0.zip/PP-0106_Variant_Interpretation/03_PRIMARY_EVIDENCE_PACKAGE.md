# 03_PRIMARY_EVIDENCE_PACKAGE.md

# Primary Evidence Package

---

# Identity

| Field | Value |
|---|---|
| Evidence Package ID | EP-PP-0106 |
| Population Package ID | PP-0106 |
| Title | Variant Interpretation |
| Clinical Domain | Gastric Cancer / Precision Oncology |
| Version | 1.0.0 |
| Status | Approved |

---

# Clinical Question

> **What is Variant Interpretation?**

---

# Educational Intent

Provide patients and caregivers with an evidence-based explanation of **variant interpretation** as the post-analytic process of determining what a detected genomic variant may mean by integrating scientific evidence with the relevant clinical context.

The package deliberately bridges:

**variant detection**
→ **annotation**
→ **evidence review**
→ **evidence integration**
→ **clinical context**
→ **interpretation**
→ **clinical significance / possible actionability**

It does not replace dedicated packages for formal variant classification, evidence codes, germline or somatic testing, or treatment selection.

---

# Scope

## Included

- Definition of variant interpretation
- Detection versus interpretation
- Conceptual annotation
- Evidence review
- Evidence integration
- Clinical context
- Germline versus somatic interpretation
- VUS
- Evolving interpretation
- Context dependence
- Clinical significance versus actionability
- Professional interpretation
- Gastric-cancer relevance at foundational level

---

## Excluded

- ACMG/AMP detailed classification
- PVS1/PS/PM/PP/BA1/BS/BP and other individual evidence codes
- Bayesian calculations
- Detailed ClinGen implementation rules
- Detailed AMP/ASCO/CAP tiering
- Computational prediction methods
- Bioinformatics pipelines
- Detailed germline testing
- Detailed somatic testing
- Confirmatory testing workflow
- Molecular tumor profiling workflow
- Treatment algorithms
- Drug selection
- Disease-specific treatment recommendations

---

# Primary Evidence Sources

| Priority | Source | Evidence Role |
|---|---|---|
| 1 | ESMO/ASCO Recommendations for a Global Curriculum in Medical Oncology, Edition 2023 | Defines post-analytic genomic processes including variant calling, annotation, functional interpretation and clinical variant interpretation; emphasizes clinical context |
| 2 | AMP/ASCO/CAP standards for interpretation and reporting of sequence variants in cancer | Foundational cancer variant-interpretation/reporting framework |
| 3 | ClinGen/CGC/VICC standards for classification of somatic variants | Supports the distinction between interpretation/classification and downstream formal frameworks |
| 4 | NCI Cancer Genetics Risk Assessment and Counseling (PDQ) | Germline testing outcomes, VUS, evidence evolution and patient-facing interpretation context |
| 5 | NCCN Gastric Cancer Guidelines | Gastric-cancer molecular testing context and clinical implementation |
| 6 | 18 Core Materials / locked project discussion | Project-specific scope, boundaries and gastric-cancer knowledge architecture |

---

# Evidence Hierarchy

## Level I — Professional / Guideline / Standards Sources

- ESMO/ASCO
- AMP/ASCO/CAP
- ClinGen/CGC/VICC
- NCCN
- NCI

## Project Governance Evidence

- 18 Core Materials
- Locked PP-0106 Discussion Batch
- Gold Population Package Specification v1.0

---

# Evidence Matrix

| Clinical Claim | Supporting Evidence |
|---|---|
| Variant interpretation is a post-analytic process that follows detection/calling and annotation. | ESMO/ASCO |
| Interpretation requires assessment of a variant in the appropriate clinical context. | ESMO/ASCO |
| Cancer sequence-variant interpretation and reporting require structured professional standards. | AMP/ASCO/CAP |
| Somatic variant interpretation/classification has dedicated professional frameworks. | ClinGen/CGC/VICC |
| A detected variant does not automatically have established clinical significance. | ACMG/AMP concepts + NCI |
| Genetic testing can produce a VUS result. | NCI |
| VUS and pathogenic-variant rates vary with testing context and available evidence. | NCI |
| Variant interpretation can evolve as evidence accumulates and methods improve. | NCI + ClinGen/AMP |
| Interpretation requires integration of multiple evidence sources rather than reliance on one observation. | ACMG/AMP + ClinGen |
| Germline and somatic findings require different clinical contexts. | ESMO/ASCO + NCI |
| Clinical significance and treatment actionability are related but distinct concepts. | ESMO/ASCO + oncology precision-medicine frameworks |
| Genomic findings should be considered with the overall clinical context. | ESMO/ASCO + NCCN |
| Gastric-cancer molecular findings are incorporated into broader molecular/pathology and clinical management workflows. | NCCN |
| A genomic finding should not automatically be converted into a treatment recommendation. | NCCN + ESMO/ASCO + project scope boundary |

---

# Evidence Synthesis

## 1. Variant Interpretation Is Not Variant Detection

The core evidence architecture distinguishes the laboratory act of identifying a genomic change from the clinical process of determining its meaning.

ESMO/ASCO places variant calling, annotation, functional interpretation and clinical variant interpretation among post-analytic genomic processes.

Therefore:

**Variant detected**
does not equal
**variant clinically understood**.

This distinction is the foundation of PP-0106.

---

## 2. Interpretation Requires Evidence Integration

A variant may be evaluated using several forms of evidence.

Depending on the clinical question, these can include:

- population data;
- clinical observations;
- family/segregation information;
- functional studies;
- computational evidence;
- published literature;
- laboratory information;
- disease-specific evidence;
- cancer-specific evidence;
- treatment-related evidence.

The important patient-facing principle is not how each evidence code is calculated.

The important principle is:

> **Experts integrate multiple evidence sources before assigning clinical meaning.**

Detailed evidence weighting is intentionally delegated to downstream classification packages.

---

## 3. Annotation Is a Different Step From Interpretation

Annotation describes the variant in a standardized biological and genomic context.

It may identify:

- the gene;
- genomic location;
- variant type;
- transcript or other reference information;
- predicted or known biological information.

Annotation supplies information used during interpretation.

It is not, by itself, a conclusion about clinical significance.

---

## 4. Germline and Somatic Interpretation

The same broad interpretive principle applies to both germline and somatic variants.

However, the clinical question differs.

### Germline

The question may concern inherited cancer susceptibility or another inherited condition.

### Somatic

The question may concern tumor biology, classification, prognosis, treatment-related relevance or resistance.

ESMO/ASCO also highlights the importance of distinguishing tumor-only sequencing from situations in which germline information may need separate consideration.

Detailed testing pathways remain outside PP-0106.

---

## 5. VUS and Uncertainty

NCI identifies VUS as one of the possible outcomes of genetic testing.

A VUS means that current evidence is insufficient to establish a confident clinical interpretation.

This is not equivalent to:

- confirmed pathogenicity;
- confirmed benign status;
- proof of hereditary cancer;
- proof of tumor causation;
- automatic treatment eligibility.

This distinction is a major patient-safety element of PP-0106.

---

## 6. Interpretation Can Change

NCI describes variation in VUS and pathogenic-variant rates and notes that VUS rates can change as data pools grow and variant-interpretation methods improve.

This supports the broader principle that interpretation is an evolving knowledge process.

New evidence may include:

- additional clinical observations;
- larger population datasets;
- functional studies;
- new publications;
- improved genomic resources;
- improved interpretation methods.

A variant that was once uncertain may later become better characterized.

The reverse direction can also occur if new evidence changes the interpretation.

PP-0106 introduces this concept without defining a formal reclassification workflow.

---

## 7. The Gene Name Is Not Enough

Variant interpretation must focus on the specific variant rather than only the gene.

Different variants in the same gene can have different:

- molecular effects;
- population frequencies;
- functional evidence;
- clinical observations;
- disease associations.

The project discussion specifically highlights gastric-cancer relevance, including CDH1, where different variant types may require different evidence and some variants may remain uncertain.

This illustrates why:

> **“Variant in a cancer gene” is not a sufficient interpretation.**

---

## 8. Clinical Context Matters

ESMO/ASCO emphasizes placing genomic variants in the correct clinical context.

Relevant context can include:

- disease type;
- tumor histology;
- stage;
- treatment history;
- specimen;
- germline versus somatic setting;
- clinical question;
- other pathology findings.

In gastric cancer, genomic information may be used for different questions, including characterization, prognosis, hereditary-risk assessment, or treatment-related biomarker evaluation.

The same molecular finding should therefore not be interpreted without considering why and where it was identified.

---

## 9. Clinical Significance Versus Actionability

A variant can have a recognized biological or clinical significance without automatically being an actionable treatment target.

A useful conceptual sequence is:

**Variant**
→ **interpretation**
→ **clinical significance**
→ **assessment of actionability**
→ **clinical decision**

Each step requires appropriate evidence.

PP-0106 establishes this distinction but does not provide treatment algorithms.

---

## 10. Professional Interpretation

Variant interpretation may require expertise across laboratory science, molecular pathology, genetics and oncology.

The exact professional combination depends on:

- variant type;
- germline or somatic context;
- disease;
- clinical question;
- local healthcare system.

The patient-facing principle is:

> **A genomic result should be discussed with an appropriately qualified healthcare team rather than interpreted from the mutation list alone.**

---

## 11. Gastric-Cancer Context

The project is gastric-cancer focused.

PP-0106 therefore uses gastric cancer as the clinical anchor while maintaining a foundational interpretation scope.

Gastric-cancer molecular information may arise in:

- tumor genomic testing;
- hereditary gastric-cancer evaluation;
- molecular characterization;
- biomarker assessment.

NCCN places molecular and biomarker testing within the gastric-cancer clinical workflow.

PP-0106 does not reproduce individual biomarker-testing or treatment pathways.

Those are downstream packages.

---


---

# Detailed Evidence Interpretation Model

## Evidence Layer 1 — What the Laboratory Detected

Before clinical interpretation, the finding must be understood as a laboratory result.

Questions include:

- What variant was reported?
- What genomic context is provided?
- What specimen was tested?
- What type of alteration was identified?

PP-0106 does not teach the underlying sequencing or bioinformatics pipeline.

---

## Evidence Layer 2 — What the Variant Is

Annotation provides the descriptive identity of the variant.

Relevant descriptors may include:

- gene;
- genomic position;
- variant type;
- transcript/reference information;
- other standardized identifiers.

Annotation is an input to interpretation, not the final interpretation.

---

## Evidence Layer 3 — What Is Known From Populations and Clinical Data

Population and clinical data can help establish whether a variant is:

- commonly observed;
- rare;
- associated with disease;
- observed in affected individuals;
- observed in unaffected populations.

The meaning of such evidence depends on the clinical question and on the framework used.

---

## Evidence Layer 4 — What Is Known Biologically

Functional studies and other biological evidence may provide information about whether a variant affects:

- gene function;
- protein function;
- cellular behavior;
- other relevant biological processes.

PP-0106 introduces this evidence category but does not teach functional-assay methodology or evidence-code scoring.

---

## Evidence Layer 5 — What Does the Variant Mean in This Disease?

Disease context matters.

A variant may have different implications depending on:

- the disease;
- tumor type;
- histology;
- inherited versus acquired context;
- clinical question.

For gastric cancer, the same gene may contain variants with different levels of evidence and different clinical implications.

---

## Evidence Layer 6 — What Is the Current Interpretation?

After evidence is reviewed and integrated, the interpretation should reflect the strength and limitations of the available evidence.

Possible conceptual outcomes include:

- established clinical significance;
- limited evidence;
- uncertain significance;
- evidence requiring further review.

The package deliberately avoids teaching the formal category systems used to generate those labels.

---

# Interpretation Scenarios

## Scenario A — Clearly Established Finding

A genomic test identifies a variant for which strong, consistent evidence exists and the clinical context is appropriate.

The interpretation can be relatively confident.

The patient-facing message is:

> The variant has an established interpretation supported by available evidence.

This still does not automatically establish a treatment recommendation.

---

## Scenario B — VUS

A variant is identified but evidence is insufficient for a confident conclusion.

The appropriate interpretation is:

> The variant's clinical significance is currently uncertain.

The correct response is not to convert uncertainty into a pathogenic conclusion.

---

## Scenario C — Same Gene, Different Variant

Two patients have variants in the same cancer-related gene.

One variant has strong evidence.

The other has limited evidence.

The gene name alone cannot determine that both variants have the same clinical meaning.

---

## Scenario D — Tumor Finding With Possible Germline Relevance

A tumor test identifies a variant that may raise a question about inherited status.

The tumor result itself does not establish that the variant is germline.

Separate clinical evaluation and, when appropriate, germline testing may be required.

PP-0106 introduces this distinction; the testing workflow belongs to PP-0109/PP-0110 and related packages.

---

# Clinical Significance and Actionability: A Two-Step Model

A useful conceptual separation is:

### Step A — Interpretation

> What does the variant mean?

### Step B — Actionability

> Does that meaning have an evidence-supported implication for clinical management?

A finding can have established significance without automatically providing a treatment option.

This distinction protects against a common precision-oncology error:

> **“Genomic finding = drug recommendation.”**

PP-0106 stops before treatment selection.

---

# Patient-Facing Interpretation Checklist

When discussing a genomic result, a patient can ask:

1. What exact variant was found?
2. Was it found in the tumor or in germline testing?
3. What evidence supports the interpretation?
4. Is the interpretation established or uncertain?
5. Could the interpretation change in the future?
6. Does the result have established clinical significance?
7. Is there evidence that it is clinically actionable?
8. What does the result not tell us?
9. Does this finding require another type of testing?
10. Who should explain the result in my specific clinical context?

This checklist is educational and is not a substitute for individualized medical interpretation.

---

# Evidence-Source Roles

| Evidence Source | Role in PP-0106 |
|---|---|
| ESMO/ASCO | Defines clinical genomics/post-analytic interpretation competencies |
| AMP/ASCO/CAP | Establishes professional cancer variant interpretation/reporting context |
| ClinGen/CGC/VICC | Establishes somatic pathogenicity/oncogenicity framework context |
| NCI | Supports VUS, testing outcomes and evolving interpretation |
| NCCN | Anchors molecular interpretation within gastric-cancer clinical care |
| 18 Core Materials | Locks project-specific scope and package boundaries |

---

# Interpretation Limitations

The following are deliberately not resolved by PP-0106:

- exact evidence weights;
- exact classification thresholds;
- exact database hierarchy;
- exact computational prediction thresholds;
- exact somatic tier assignment;
- exact treatment matching;
- exact confirmatory-testing requirements.

Those questions require specialized downstream knowledge products.


# Clinical Claims Summary

The evidence supports these core messages:

- Variant interpretation follows variant detection.
- Detection alone does not establish clinical meaning.
- Annotation provides information used during interpretation.
- Interpretation integrates multiple evidence sources.
- Germline and somatic variants require context-appropriate interpretation.
- VUS represents uncertainty rather than confirmed pathogenicity.
- Interpretation may change as evidence evolves.
- The same gene can contain variants with different meanings.
- Clinical context is essential.
- Clinical significance and treatment actionability are not identical.
- Expert interpretation is important.
- A genomic result is not automatically a treatment plan.

---

# Evidence Consistency Review

No material conflict was identified among the evidence sources used for the locked scope.

The sources are complementary:

### ESMO/ASCO

Provides the broad oncology competency and post-analytic genomic framework.

### AMP/ASCO/CAP

Provides the professional cancer sequence-variant interpretation/reporting framework.

### ClinGen/CGC/VICC

Provides the professional somatic pathogenicity/oncogenicity classification framework and reinforces the distinction between interpretation and detailed classification.

### NCI

Provides patient-facing genetic-testing outcomes, VUS context and evidence-evolution concepts.

### NCCN Gastric Cancer

Provides the gastric-cancer clinical implementation context.

The package does not use these sources to create treatment recommendations.

---

# Evidence Gaps

PP-0106 intentionally does not determine:

- exact classification thresholds;
- evidence-code weights;
- Bayesian probabilities;
- somatic tier assignments;
- gene-specific ClinGen rules;
- a universal database or software hierarchy;
- confirmatory testing requirements;
- disease-specific treatment eligibility.

These require dedicated downstream knowledge products.

---

# Out-of-Scope Topics

| Topic | Delegation |
|---|---|
| NGS methodology | PP-0101 |
| Gene panel methodology | PP-0102 |
| WGS methodology | PP-0103 |
| Variant Classification | PP-0108 |
| ACMG evidence codes | Downstream evidence-code packages |
| Germline Genetic Testing | PP-0109 |
| Somatic Genetic Testing | PP-0110 |
| Clinical Genomics | PP-0107 |
| Molecular Tumor Profiling | Dedicated downstream package |
| Biomarker-specific testing | Dedicated biomarker packages |
| Treatment algorithms | Treatment / Precision Oncology packages |
| Variant reclassification workflow | Dedicated package if required |

---

# Clinical Safety Boundaries

## Boundary 1

**Do not equate a detected variant with pathogenicity.**

## Boundary 2

**Do not treat a VUS as a confirmed disease-causing finding.**

## Boundary 3

**Do not infer inherited status from a tumor finding alone.**

## Boundary 4

**Do not infer treatment from a genomic finding alone.**

## Boundary 5

**Do not interpret a variant without considering the relevant clinical context.**

## Boundary 6

**Do not assume an interpretation is permanently fixed.**

---

# Future Update Triggers

Review PP-0106 when:

- ESMO/ASCO materially updates genomic interpretation competencies.
- AMP/ASCO/CAP revises cancer variant interpretation/reporting standards.
- ClinGen/CGC/VICC substantially updates somatic interpretation/classification standards.
- NCI substantially changes patient-facing genetic-testing/VUS guidance.
- NCCN changes the role of molecular testing in gastric cancer.
- Project governance changes the boundary between interpretation and classification.

---

# Evidence Package Decision

**APPROVED**

Evidence traceability is complete for the locked scope.

Repository Status: **Ready**.
