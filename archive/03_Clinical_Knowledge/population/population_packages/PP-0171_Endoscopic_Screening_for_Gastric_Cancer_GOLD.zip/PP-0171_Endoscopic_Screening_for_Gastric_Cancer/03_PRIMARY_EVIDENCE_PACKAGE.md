# Primary Evidence Package

## Identity

| Field | Value |
|---|---|
| Evidence Package ID | EP-PP-0171 |
| Population Package ID | PP-0171 |
| Title | Endoscopic Screening for Gastric Cancer |
| Clinical Domain | Risk & Prevention |
| Version | 1.0.0 |
| Status | Approved |

## Clinical Question

> **How is upper endoscopy used to screen for gastric cancer in people for whom screening is being considered?**

## Educational Intent

Explain the role of upper endoscopy as a gastric-cancer screening modality, including what it examines, what it may detect, how abnormal findings can lead to biopsy and further evaluation, and what is known and not known about its effectiveness and risks.

The package is intentionally limited to screening-purpose endoscopy and does not become a generic upper-endoscopy, diagnostic-endoscopy, biopsy, pathology, or treatment package.

# Scope

## Included

- Screening-purpose upper endoscopy
- Direct examination of gastric mucosa
- Abnormal visual findings
- Early gastric cancer
- Precursor abnormalities
- Conceptual biopsy transition
- Screening versus diagnostic endoscopy
- Effectiveness evidence
- Comparison with radiographic screening at high level
- Geographic context
- Evidence limitations
- Conceptual procedural risks
- Transition to diagnostic evaluation

## Excluded

- Detailed EGD preparation
- Sedation/anesthesia
- Technical endoscopy
- Diagnostic endoscopy
- Biopsy strategy
- Histopathology
- Serum pepsinogen methodology
- High-incidence population screening programs
- HDGC surveillance
- Detailed harms and false-result analysis
- Universal screening intervals or age thresholds
- Endoscopic resection, EMR, ESD
- Gastric cancer treatment

# Primary Evidence Sources

| Priority | Source | Purpose |
|---|---|---|
| 1 | NCI — Stomach (Gastric) Cancer Screening PDQ | Core evidence for endoscopic screening, comparative sensitivity, observational mortality evidence, limitations, and harms |
| 2 | NCI — Screening for Stomach Cancer | Patient-facing explanation of upper endoscopy and screening purpose |
| 3 | NCCN Gastric Cancer Version 2.2026 | Current gastric-cancer clinical and endoscopic framework |
| 4 | NCI — Genetics of Gastric Cancer PDQ | Population and hereditary context relevant to interpretation of screening evidence |
| 5 | American Cancer Society — Stomach Cancer | Patient-facing screening and risk communication |

# Supporting Sources

- NCI HDGC PDQ
- NCI Prevention PDQ
- ESMO/ASCO Global Curriculum 2023
- Approved adjacent Population Packages
- PP Registry and locked project governance

# Evidence Hierarchy

## Level I

### NCI Screening PDQ

Directly supports:

- gastric-cancer screening context;
- upper endoscopy as a screening modality;
- endoscopy versus radiographic photofluorography;
- observational evidence from East Asia;
- limitations of mortality evidence;
- procedure-related screening harms.

### NCI Screening for Stomach Cancer

Directly supports:

- plain-language definition of upper endoscopy;
- screening purpose;
- examination of the stomach;
- patient-facing explanation of high-risk screening.

### NCCN Gastric Cancer Version 2.2026

Supports:

- current clinical framework;
- endoscopic evaluation context;
- separation of endoscopic diagnosis and treatment.

### NCI Genetics / Prevention PDQ

Supports:

- population-risk context;
- hereditary and geographic context;
- relationship between high-risk screening and gastric-cancer risk.

### ACS

Supports:

- patient-facing screening explanation;
- risk/benefit framing.

# Evidence Matrix

| Clinical Claim | Supporting Evidence |
|---|---|
| Upper endoscopy can be used to screen for gastric cancer in selected higher-risk populations. | NCI Screening PDQ; NCI Screening for Stomach Cancer |
| Upper endoscopy directly examines the stomach and can identify abnormal areas. | NCI Screening for Stomach Cancer; NCI Screening PDQ |
| Screening endoscopy is different in purpose from diagnostic endoscopy. | NCI Screening PDQ; project PP architecture |
| Endoscopy appears more sensitive than radiographic photofluorography for detecting gastric cancer. | NCI Screening PDQ |
| Observational studies from East Asia generally suggest lower gastric-cancer mortality with endoscopic screening. | NCI Screening PDQ |
| The evidence for mortality benefit is not definitive across all populations because the evidence is predominantly nonrandomized. | NCI Screening PDQ |
| Abnormal endoscopic findings may require biopsy and further evaluation. | NCI Screening PDQ; NCI Screening for Stomach Cancer |
| Endoscopic screening is not risk-free. | NCI Screening PDQ |
| Geographic variation in gastric-cancer incidence affects the context in which screening evidence should be interpreted. | NCI Genetics PDQ; NCCN Gastric Cancer |
| A normal screening examination does not guarantee that gastric cancer can never develop. | Screening evidence limitations; patient-facing screening framework |

# Evidence Notes

## 1. Endoscopy as a Screening Modality

NCI identifies gastric endoscopy as one of the principal approaches studied for gastric-cancer screening.

The patient-facing NCI source explains upper endoscopy as direct examination of the esophagus, stomach, and proximal small intestine with a thin flexible camera passed through the mouth.

## 2. Comparative Sensitivity

NCI reports that endoscopy appears to be more sensitive than photofluorography for detecting gastric cancer.

This supports describing endoscopy as an important direct-visualization screening modality.

The package does not introduce a universal numerical sensitivity estimate because the supplied evidence is heterogeneous and the package is not a diagnostic-accuracy methodology package.

## 3. Mortality Evidence

NCI reports that evidence for mortality reduction from endoscopic screening remains inadequate overall.

At the same time, observational studies from South Korea, China, and Japan generally suggest lower gastric-cancer mortality among screened populations.

A cited meta-analysis of ten nonrandomized Asian studies reported a pooled RR for gastric-cancer mortality of approximately 0.60 (95% CI 0.49–0.73), with heterogeneity and observational-design limitations.

Therefore the appropriate patient-facing interpretation is:

> Endoscopic screening has encouraging observational evidence, particularly in high-incidence Asian settings, but the magnitude of mortality benefit is not established for every population.

## 4. Geographic Context

A substantial portion of the evidence base comes from high-incidence East Asian settings.

This matters because screening benefit depends partly on baseline disease incidence and population risk.

Detailed high-incidence population screening is delegated to PP-0173.

## 5. Biopsy Transition

An abnormal endoscopic finding may lead to biopsy and pathology.

PP-0171 should stop at this transition point.

Detailed biopsy strategy belongs to PP-0177 and diagnostic endoscopy to PP-0176.

## 6. Screening Harms

NCI reports uncommon but potentially serious endoscopic complications, including bleeding, perforation, aspiration pneumonia, and cardiopulmonary events.

PP-0171 includes only conceptual procedure-level risk.

Detailed screening harms and false-result analysis belong to PP-0174.

# Clinical Claims Summary

The evidence supports these core messages:

- Endoscopic screening can directly examine the stomach for gastric cancer and abnormal precursor findings.
- It is used in selected screening contexts rather than as a universal test for every person.
- Endoscopy appears more sensitive than radiographic photofluorography for detecting gastric cancer.
- Observational Asian studies suggest possible mortality benefit.
- Evidence remains predominantly nonrandomized and is not definitive across all populations.
- An abnormal screening finding may require biopsy and diagnostic evaluation.
- Endoscopy has potential harms even though serious complications are uncommon.
- Screening endoscopy is different from diagnostic endoscopy.
- A normal screening endoscopy does not provide a lifelong guarantee against gastric cancer.

# Evidence Consistency Review

The supplied NCI, NCCN, ACS, and ESMO/ASCO materials are consistent on the central framework:

1. Endoscopy is an important gastric-cancer screening modality.
2. Screening is most relevant in selected risk/population contexts.
3. Endoscopy provides direct visualization of the gastric lining.
4. Observational evidence supports potential benefit, especially in high-incidence Asian settings.
5. Mortality benefit is not definitively established across all populations.
6. Screening is not risk-free.
7. Abnormal findings require appropriate diagnostic follow-up.

No contradiction affecting the approved PP-0171 scope was identified.

# Evidence Gaps

The supplied evidence does not support:

- a universal endoscopic screening interval;
- a universal starting age;
- universal mortality benefit across all populations;
- a single endoscopic technique or protocol for all screening settings;
- a universal claim that endoscopy is the best screening modality for every population;
- individualized screening prescriptions.

These gaps are intentionally preserved.

# Out-of-Scope Topics / Delegation

| Topic | Delegated To |
|---|---|
| High-risk screening eligibility | PP-0170 |
| HDGC-specific endoscopic surveillance | PP-0159 |
| Serum pepsinogen | PP-0172 |
| High-incidence population screening | PP-0173 |
| Screening harms and false results | PP-0174 |
| Diagnostic work-up | PP-0175 |
| Diagnostic endoscopy | PP-0176 |
| Biopsy strategy | PP-0177 |
| Histopathology | PP-0178+ |
| Endoscopic resection / EMR / ESD | PP-0192–0194 |

# Future Update Triggers

Review this package when:

- NCI substantially updates gastric-cancer screening evidence.
- NCCN changes endoscopic screening or gastric-cancer screening recommendations.
- Major randomized trials provide stronger mortality evidence.
- New evidence materially changes the role of endoscopy in low-incidence populations.
- New screening modalities change the comparative landscape.
- PP Registry changes ownership of endoscopic screening, diagnosis, or biopsy.

# Evidence Package Decision

**APPROVED**

The evidence package supports the approved scope of:

> **PP-0171 — Endoscopic Screening for Gastric Cancer**

The package deliberately preserves uncertainty around mortality benefit and does not create universal screening intervals or individualized recommendations.

# Source Traceability

| Source | Relevant Content |
|---|---|
| NCI — Stomach (Gastric) Cancer Screening PDQ | Endoscopic screening, comparative sensitivity, Asian observational mortality evidence, limitations, harms |
| NCI — Screening for Stomach Cancer | Patient-facing upper endoscopy explanation and screening purpose |
| NCI — Genetics of Gastric Cancer PDQ | Geographic/population risk context |
| NCCN Gastric Cancer Version 2.2026 | Clinical endoscopic framework |
| ACS — Stomach Cancer | Patient-facing screening and risk communication |
| ESMO/ASCO Global Curriculum 2023 | General oncology screening/prevention framework |

# Boundary Verification

**Core =** screening-purpose upper endoscopy, direct gastric visualization, abnormalities sought, early cancer/precursor detection, conceptual biopsy transition, screening versus diagnostic endoscopy, endoscopic screening evidence, evidence limitations, and conceptual procedural risks; **Supporting =** high-incidence Asian evidence context, high-level comparison with radiographic screening, high-level reference to serum pepsinogen, and transition to diagnostic evaluation; **Explicitly Excluded =** generic EGD indications, detailed preparation/sedation, technical endoscopy, diagnostic endoscopy, detailed biopsy strategy, pathology, serum pepsinogen methodology, high-incidence population screening programs, HDGC surveillance, detailed screening harms/false-result analysis, universal intervals/age thresholds, EMR/ESD and treatment; **Delegated-to PP =** PP-0159, PP-0170, PP-0172, PP-0173, PP-0174, PP-0175, PP-0176, PP-0177, PP-0178+, PP-0192–0194.

# Final Evidence Status

**PASS — Evidence traceability complete.**
