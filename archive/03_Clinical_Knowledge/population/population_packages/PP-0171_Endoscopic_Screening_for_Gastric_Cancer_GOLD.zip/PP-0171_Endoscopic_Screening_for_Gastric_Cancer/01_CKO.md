# Clinical Knowledge Object (CKO)

## Metadata

| Field | Value |
|---|---|
| CKO ID | CKO-PP-0171 |
| PP ID | PP-0171 |
| Title | Endoscopic Screening for Gastric Cancer |
| Clinical Domain | Risk & Prevention |
| Population Wave | Wave 1 |
| Version | 1.0.0 |
| Audience | General public, patients for whom gastric-cancer screening is being considered, caregivers |
| Reading Level | Plain language |
| Last Updated | 2026-08-09 |

## Educational Objectives

After reading this Population Package, the reader should be able to:

- Understand what upper endoscopy means when it is used for gastric-cancer screening.
- Understand the difference between screening endoscopy and diagnostic endoscopy.
- Understand what an endoscope examines and what clinicians look for.
- Understand how screening endoscopy may identify gastric cancer or precursor abnormalities.
- Understand why an abnormal finding may lead to biopsy or further diagnostic evaluation.
- Understand the evidence and limitations surrounding endoscopic screening.
- Understand that endoscopy is not risk-free and that a normal examination does not guarantee that cancer can never develop.
- Understand why detailed biopsy, pathology, diagnostic endoscopy, and treatment are separate clinical topics.

## Scope

### Included

- Screening-purpose upper endoscopy
- What the procedure examines
- What clinicians look for during screening
- Early gastric cancer and precursor abnormalities
- Conceptual role of biopsy after an abnormal finding
- Screening endoscopy versus diagnostic endoscopy
- Evidence for endoscopic screening
- High-level comparison with radiographic screening
- Geographic context of the evidence
- Evidence limitations
- Conceptual procedure-related risks
- What may happen after an abnormal screening finding
- Patient-facing interpretation and common misconceptions

### Not Included

- Generic upper-endoscopy indications
- Detailed endoscopy preparation, fasting, sedation, or anesthesia protocols
- Technical endoscope operation
- Diagnostic endoscopy
- Detailed biopsy strategy or mapping
- Histopathology
- Dysplasia grading
- Serum pepsinogen methodology
- High-incidence population screening programs
- HDGC-specific surveillance
- Detailed screening harms and false-result analysis
- Screening intervals or universal age thresholds
- EMR, ESD, endoscopic resection, or gastric-cancer treatment

# Clinical Knowledge Blocks

## Knowledge Block 1 — What Is Endoscopic Screening for Gastric Cancer?

### Patient Explanation

Upper endoscopy is a procedure in which a thin, flexible tube with a camera is passed through the mouth so that the healthcare team can examine the esophagus, stomach, and the beginning of the small intestine.

When it is used for screening, the purpose is to look for gastric cancer or abnormal areas that could represent precancerous disease before symptoms develop.

### Clinical Importance

Endoscopic screening is a specific application of upper endoscopy. The reason for doing it is different from using endoscopy to investigate symptoms or a known abnormality.

### Key Concepts

- Upper endoscopy
- Screening
- Asymptomatic person
- Early detection

## Knowledge Block 2 — How Is Screening Endoscopy Different From Diagnostic Endoscopy?

### Patient Explanation

Screening endoscopy is performed because a person is in a group for whom gastric-cancer screening is being considered, even when the person does not have symptoms suggesting cancer.

Diagnostic endoscopy is performed because there is already a clinical reason to investigate a problem, such as symptoms or another abnormal finding.

The procedure may look similar, but the clinical purpose is different.

### Clinical Importance

Keeping screening and diagnosis separate helps prevent delays in appropriate diagnostic evaluation.

### Key Concepts

- Screening
- Diagnostic evaluation
- Symptoms
- Clinical indication

## Knowledge Block 3 — What Does the Endoscope Examine?

### Patient Explanation

The endoscope allows the clinician to directly inspect the lining of the upper digestive tract, including the stomach.

During gastric-cancer screening, particular attention is given to the stomach lining and to areas that look different from the surrounding tissue.

### Clinical Importance

Direct visualization is one reason endoscopy is an important gastric-cancer screening method.

### Key Concepts

- Gastric mucosa
- Direct visualization
- Upper gastrointestinal tract

## Knowledge Block 4 — What Does the Clinician Look For?

### Patient Explanation

The clinician looks for abnormal areas of the stomach lining. These may include irregular or suspicious areas, ulcers, masses, or other changes that require closer assessment.

Some abnormalities may represent cancer, while others may be benign or precancerous.

### Clinical Importance

An abnormal appearance is a reason for further assessment, not automatically a diagnosis of cancer.

### Key Concepts

- Abnormal mucosa
- Suspicious lesion
- Precursor abnormality
- Gastric cancer

## Knowledge Block 5 — Can Screening Endoscopy Find Cancer Before Symptoms Appear?

### Patient Explanation

Yes. Screening is intended to find cancer or precancerous abnormalities in people who do not have symptoms.

Finding gastric cancer earlier may provide an opportunity for earlier treatment.

### Clinical Importance

Early detection is the central rationale for screening.

### Key Concepts

- Early detection
- Asymptomatic disease
- Screening benefit

## Knowledge Block 6 — Can Screening Endoscopy Find Precancerous Abnormalities?

### Patient Explanation

Endoscopy can identify visible abnormalities that may represent precancerous lesions or other conditions associated with gastric-cancer risk.

An abnormal area may need tissue sampling so that it can be examined more closely.

### Clinical Importance

Screening may identify abnormalities before invasive cancer is established, but the significance of a finding generally requires appropriate clinical and pathologic assessment.

### Key Concepts

- Precancerous lesion
- Tissue sampling
- Pathology

## Knowledge Block 7 — What Happens if an Abnormal Area Is Found?

### Patient Explanation

If the clinician sees an abnormal area, additional evaluation may be needed.

A biopsy may be taken so that the tissue can be examined by a pathologist. The result then helps determine what the abnormality represents and what should happen next.

### Clinical Importance

Screening is a first step in a pathway. An abnormal screening finding is not, by itself, a final diagnosis.

### Key Concepts

- Abnormal screening finding
- Biopsy
- Pathology
- Diagnostic evaluation

## Knowledge Block 8 — Why Might a Biopsy Be Taken?

### Patient Explanation

A biopsy is a small tissue sample taken from an area that needs further assessment.

The tissue is examined under a microscope to help determine whether the finding is cancer, a precancerous change, or another type of abnormality.

### Clinical Importance

Biopsy is the bridge between a visual screening finding and tissue-based diagnosis.

Detailed biopsy strategy is covered separately.

### Key Concepts

- Biopsy
- Histopathology
- Tissue diagnosis

## Knowledge Block 9 — How Effective Is Endoscopic Screening?

### Patient Explanation

Endoscopy is an important method for detecting gastric cancer. It appears more sensitive than radiographic photofluorography for detecting gastric cancer.

Observational studies from high-incidence Asian settings have generally suggested lower gastric-cancer mortality among people who underwent endoscopic screening. However, most of this evidence is nonrandomized, so the size of any mortality benefit is not proven to be the same in every population.

### Clinical Importance

The evidence is encouraging but context-dependent. It should not be presented as proof that screening endoscopy reduces mortality equally in all countries.

### Key Concepts

- Sensitivity
- Observational evidence
- Mortality
- High-incidence populations

## Knowledge Block 10 — How Does Endoscopy Compare With Other Screening Approaches?

### Patient Explanation

Other gastric-cancer screening approaches have also been studied, including radiographic screening and serum pepsinogen testing.

Endoscopy provides direct visualization of the stomach lining and appears more sensitive than radiographic photofluorography for detecting gastric cancer.

Detailed serum pepsinogen screening is covered separately.

### Clinical Importance

The choice of screening approach depends on the population, clinical context, healthcare system, and available evidence.

### Key Concepts

- Endoscopy
- Radiographic screening
- Serum pepsinogen
- Modality selection

## Knowledge Block 11 — Why Does the Evidence Differ Between Countries and Populations?

### Patient Explanation

Gastric cancer is much more common in some regions than others.

Much of the evidence supporting endoscopic screening comes from East Asian countries with high gastric-cancer incidence. Results from those settings may not apply in exactly the same way to lower-incidence populations.

### Clinical Importance

Population risk affects the potential balance between screening benefits, harms, and resource use.

### Key Concepts

- Geographic variation
- High-incidence regions
- Low-incidence populations
- Generalizability

## Knowledge Block 12 — What Are the Limitations of Endoscopic Screening?

### Patient Explanation

Endoscopy can miss abnormalities, and an abnormal finding does not necessarily mean cancer.

The evidence for a reduction in gastric-cancer mortality is not definitive across all populations. Screening may also lead to additional tests or procedures.

### Clinical Importance

A screening test should be understood as helpful but imperfect.

### Key Concepts

- False-negative findings
- Additional evaluation
- Evidence uncertainty
- Screening limitations

## Knowledge Block 13 — What Are the Possible Risks of Screening Endoscopy?

### Patient Explanation

Endoscopic screening is a medical procedure and is not completely risk-free.

Serious complications are uncommon but can include bleeding, perforation, aspiration, or cardiopulmonary complications.

The overall balance between potential benefit and harm depends on the clinical setting and the person being screened.

### Clinical Importance

Patients should understand that screening decisions involve both potential benefits and potential harms.

### Key Concepts

- Procedural risk
- Bleeding
- Perforation
- Aspiration
- Benefit–harm balance

## Knowledge Block 14 — Does a Normal Screening Endoscopy Guarantee That Cancer Is Not Present?

### Patient Explanation

No.

A normal examination is reassuring, but no screening test can guarantee that every abnormality has been detected or that cancer can never develop later.

The appropriate follow-up depends on the person's underlying risk and the clinical context.

### Clinical Importance

Avoids false reassurance and emphasizes the distinction between screening and certainty.

### Key Concepts

- Negative screening
- False-negative result
- Residual risk
- Follow-up

## Knowledge Block 15 — What Happens After an Abnormal Screening Endoscopy?

### Patient Explanation

An abnormal screening finding may lead to diagnostic evaluation, biopsy, and pathology.

The next step depends on what was seen and what the tissue examination shows.

Detailed diagnostic endoscopy and biopsy strategy are separate clinical topics.

### Clinical Importance

This establishes the correct transition from screening to diagnosis without duplicating downstream packages.

### Key Concepts

- Diagnostic pathway
- Biopsy
- Pathology
- Follow-up

## Knowledge Block 16 — What Should Patients Understand Before Choosing Screening Endoscopy?

### Patient Explanation

Before screening, it is important to understand:

- why screening is being considered;
- what the endoscopy can and cannot detect;
- that an abnormal finding may require biopsy and further tests;
- that a normal result does not guarantee lifelong absence of cancer;
- that the procedure has potential risks;
- that detailed screening recommendations can differ by population and risk group.

### Clinical Importance

This supports informed, evidence-based discussion with the healthcare team.

### Key Concepts

- Informed decision-making
- Risk
- Benefit
- Limitations
- Clinical context

# Common Misconceptions

### Myth 1

**“A screening endoscopy diagnoses cancer immediately.”**

**Fact:** Endoscopy can identify suspicious areas, but biopsy and pathology may be needed to establish what an abnormal finding represents.

### Myth 2

**“If a biopsy is taken, I definitely have cancer.”**

**Fact:** A biopsy is used to investigate an abnormal area. It does not by itself mean that cancer is present.

### Myth 3

**“A normal endoscopy means I can never develop gastric cancer.”**

**Fact:** A normal examination does not guarantee that cancer can never develop or that every abnormality was detected.

### Myth 4

**“Endoscopy is proven to save lives in every population.”**

**Fact:** Observational studies, particularly from East Asia, suggest benefit, but the evidence is not definitive for every population.

### Myth 5

**“Everyone should have a screening endoscopy every year.”**

**Fact:** There is no universal screening interval that applies to everyone.

### Myth 6

**“Screening endoscopy and diagnostic endoscopy are the same thing.”**

**Fact:** The basic procedure may be similar, but the clinical purpose is different.

### Myth 7

**“HDGC surveillance is the same as ordinary gastric-cancer screening.”**

**Fact:** Hereditary diffuse gastric cancer requires a specialized surveillance framework and is handled separately.

# Key Messages

- Upper endoscopy can be used to screen for gastric cancer in selected populations.
- Screening endoscopy is different from diagnostic endoscopy.
- The stomach lining is directly examined for abnormal areas.
- Abnormal findings may require biopsy and pathology.
- Endoscopy appears more sensitive than radiographic photofluorography for detecting gastric cancer.
- Observational evidence from high-incidence Asian settings suggests possible mortality benefit, but evidence is not definitive across all populations.
- Endoscopy is not risk-free.
- A normal screening endoscopy does not guarantee that gastric cancer can never develop.
- Detailed biopsy, diagnostic endoscopy, screening harms, high-incidence population screening, and treatment are separate topics.

# Knowledge Graph

## Prerequisite PP

- PP-0170 — Gastric Cancer Screening in High-Risk Individuals

## Related PP

- PP-0159 — Endoscopic Surveillance in HDGC
- PP-0169 — Gastric Adenomas and Cancer Risk
- PP-0172 — Serum Pepsinogen Screening
- PP-0173 — Screening in High-Incidence Populations
- PP-0174 — Screening Harms and False Results
- PP-0176 — Endoscopic Diagnosis of Gastric Cancer
- PP-0177 — Endoscopic Biopsy Strategy
- PP-0178 — Histopathologic Classification

## Next / Downstream

- PP-0174 — Screening Harms and False Results
- PP-0175 — Gastric Cancer Diagnostic Work-up
- PP-0176 — Endoscopic Diagnosis of Gastric Cancer
- PP-0177 — Endoscopic Biopsy Strategy
- PP-0178 — Histopathologic Classification
- PP-0192 — Endoscopic Resection for Early Gastric Cancer
- PP-0193 — Endoscopic Mucosal Resection (EMR)
- PP-0194 — Endoscopic Submucosal Dissection (ESD)

# Revision History

| Version | Date | Summary |
|---|---|---|
| 1.0.0 | 2026-08-09 | Initial Gold Release |
