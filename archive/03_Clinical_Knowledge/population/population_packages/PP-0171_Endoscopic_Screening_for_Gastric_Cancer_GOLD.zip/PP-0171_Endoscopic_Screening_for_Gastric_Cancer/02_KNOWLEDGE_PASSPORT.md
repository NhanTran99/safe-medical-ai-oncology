# Knowledge Passport

## Identity

| Field | Value |
|---|---|
| Knowledge Passport ID | KP-PP-0171 |
| Population Package ID | PP-0171 |
| Clinical Knowledge Object | CKO-PP-0171 |
| Title | Endoscopic Screening for Gastric Cancer |
| Version | 1.0.0 |
| Status | Approved |

## Knowledge Classification

| Field | Value |
|---|---|
| Clinical Domain | Risk & Prevention |
| Clinical Domain Code | RP |
| Educational Category | Gastric Cancer Screening |
| Educational Level | Introductory |
| Clinical Complexity | Intermediate |
| Patient Journey Stage | Before Diagnosis |
| Knowledge Granularity | Atomic |
| Intended Audience | General public, patients for whom screening is being considered, caregivers |

## Intended Runtime Usage

### Primary Runtime Role

Explain how upper endoscopy is used as a gastric-cancer screening modality.

### Secondary Runtime Roles

- Explain what screening endoscopy examines.
- Explain why abnormal findings may require biopsy.
- Explain screening versus diagnostic endoscopy.
- Communicate evidence strength and limitations.
- Support informed discussion with healthcare professionals.
- Connect screening to downstream diagnostic and pathology packages.

### Typical Trigger Questions

- What is an endoscopy for stomach cancer screening?
- What happens during screening endoscopy?
- What does the doctor look for?
- Can endoscopy find stomach cancer early?
- Will I need a biopsy?
- Is screening endoscopy accurate?
- What are the risks of screening endoscopy?
- Is screening endoscopy the same as diagnostic endoscopy?
- Does a normal endoscopy mean I cannot get stomach cancer?

## Retrieval / Runtime Relevance

**Very High**

Reason: PP-0171 is the dedicated modality package immediately downstream of PP-0170 and is the principal entry point for patient questions about endoscopic gastric-cancer screening.

## Knowledge Graph

### Prerequisite

- PP-0170 — Gastric Cancer Screening in High-Risk Individuals

### Related

- PP-0159 — Endoscopic Surveillance in HDGC
- PP-0172 — Serum Pepsinogen Screening
- PP-0173 — Screening in High-Incidence Populations
- PP-0174 — Screening Harms and False Results
- PP-0176 — Endoscopic Diagnosis of Gastric Cancer
- PP-0177 — Endoscopic Biopsy Strategy
- PP-0178 — Histopathologic Classification

### Next / Downstream

- PP-0174 — Screening Harms and False Results
- PP-0175 — Gastric Cancer Diagnostic Work-up
- PP-0176 — Endoscopic Diagnosis of Gastric Cancer
- PP-0177 — Endoscopic Biopsy Strategy
- PP-0178 — Histopathologic Classification
- PP-0192 — Endoscopic Resection for Early Gastric Cancer
- PP-0193 — EMR
- PP-0194 — ESD

## Clinical Scope

### Core

- Screening-purpose upper endoscopy
- Direct examination of the stomach
- Abnormal findings and possible biopsy
- Early cancer and precursor detection
- Screening versus diagnostic endoscopy
- Effectiveness evidence
- Evidence limitations
- Conceptual procedural risks

### Supporting

- High-incidence Asian evidence context
- High-level comparison with radiographic screening
- High-level reference to serum pepsinogen
- Transition from screening to diagnostic evaluation

### Explicitly Excluded

- Generic EGD indications
- Detailed EGD preparation
- Sedation/anesthesia protocols
- Technical endoscope operation
- Diagnostic endoscopy
- Detailed biopsy strategy
- Histopathology
- Serum pepsinogen methodology
- High-incidence population screening programs
- HDGC-specific surveillance
- Detailed screening harms/false-result analysis
- Screening intervals
- Universal age thresholds
- Endoscopic resection and treatment

### Delegated-to PP

- PP-0159 — HDGC endoscopic surveillance
- PP-0170 — high-risk screening eligibility
- PP-0172 — serum pepsinogen
- PP-0173 — high-incidence population screening
- PP-0174 — screening harms and false results
- PP-0175 — diagnostic work-up
- PP-0176 — diagnostic endoscopy
- PP-0177 — biopsy strategy
- PP-0178+ — pathology
- PP-0192–0194 — endoscopic resection / EMR / ESD

## Authoritative Sources

1. NCI — Stomach (Gastric) Cancer Screening PDQ
2. NCI — Screening for Stomach Cancer
3. NCI — Genetics of Gastric Cancer PDQ
4. NCCN Clinical Practice Guidelines in Oncology — Gastric Cancer, Version 2.2026
5. American Cancer Society — Stomach Cancer

## Evidence Classification

### Level I — Direct

- NCI Screening PDQ
- NCI Screening for Stomach Cancer
- NCCN Gastric Cancer v2.2026

### Supporting

- NCI Genetics of Gastric Cancer PDQ
- ACS
- ESMO/ASCO Global Curriculum 2023
- Approved adjacent PP artifacts

## Governance Metadata

| Field | Value |
|---|---|
| Clinical Governance | Enabled |
| Evidence Traceability | Complete |
| Scope Boundary | Defined |
| Adjacent PP Boundary Review | Complete |
| Knowledge Graph | Complete |
| Runtime Ready | Yes |
| Repository Ready | Yes |

## Version Control

| Item | Value |
|---|---|
| Current Version | 1.0.0 |
| Major | 1 |
| Minor | 0 |
| Patch | 0 |

## Change History

| Version | Date | Description |
|---|---|---|
| 1.0.0 | 2026-08-09 | Initial Gold Release |

## Final Status

**APPROVED**
