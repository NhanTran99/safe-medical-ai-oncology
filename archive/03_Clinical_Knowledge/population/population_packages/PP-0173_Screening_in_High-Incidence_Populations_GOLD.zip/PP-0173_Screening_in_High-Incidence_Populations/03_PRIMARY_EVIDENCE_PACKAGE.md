# Primary Evidence Package

## Identity

| Field | Value |
|---|---|
| Evidence Package ID | EP-PP-0173 |
| Population Package ID | PP-0173 |
| Title | Screening in High-Incidence Populations |
| Clinical Domain | Risk & Prevention |
| Version | 1.0.0 |
| Status | Approved |

## Clinical Question

> **Why is gastric-cancer screening approached differently in high-incidence populations, and what does the available evidence show about population-based screening in these settings?**

## Educational Intent

Explain the population-level rationale for gastric-cancer screening in high-incidence settings, using Japan, South Korea, and China as the principal evidence context, while clearly separating population strategy from individual high-risk eligibility and from the detailed operation of individual screening modalities.

# Scope

## Included

- High-incidence populations
- Geographic incidence variation
- Population-based screening rationale
- Japan's organized screening experience
- South Korea and China endoscopic screening evidence
- Endoscopy, photofluorography, and serum pepsinogen at population level
- Observational mortality evidence
- Generalizability limitations
- Participation and implementation context
- Early-detection rationale
- Population-level benefit–harm context

## Excluded

- Individual high-risk eligibility
- Detailed endoscopy
- Detailed serum pepsinogen
- H. pylori prevention/treatment
- Precursor-disease management
- Universal age thresholds
- Universal screening intervals
- Universal modality algorithms
- Current country-specific screening prescriptions
- Detailed false-result/harm analysis
- Overdiagnosis/overtreatment
- Detailed cost-effectiveness
- Diagnostic work-up
- Biopsy/pathology
- Treatment

# Primary Evidence Sources

| Priority | Source | Purpose |
|---|---|---|
| 1 | NCI — Stomach (Gastric) Cancer Screening PDQ | Direct evidence on population screening, Japan, Asian endoscopic screening, mortality evidence, generalizability |
| 2 | NCI — Stomach (Gastric) Cancer Prevention PDQ | Population risk and gastric-cancer prevention context |
| 3 | NCCN Gastric Cancer Version 2.2026 | Current clinical framework and geographic/risk context |
| 4 | Approved adjacent PP artifacts | Scope continuity and delegation |

# Supporting Sources

- PP Registry
- Gold Population Package specification
- Approved Discussion Batch reference
- Approved adjacent Population Packages

# Evidence Hierarchy

## Level I — Direct Screening Evidence

### NCI Stomach (Gastric) Cancer Screening PDQ

This is the principal evidence source for PP-0173.

The NCI states that:

- gastric-cancer screening has been studied and implemented particularly in high-risk/high-incidence settings;
- evidence from high-risk areas may not apply to low-risk areas;
- Japan has had population-based screening using barium-meal photofluorography since the 1960s;
- endoscopy appears more sensitive than photofluorography;
- Asian observational studies from Japan, South Korea, and China generally associate endoscopic screening with lower gastric-cancer mortality;
- the cited meta-analysis included 10 nonrandomized studies;
- pooled RR for gastric-cancer mortality associated with endoscopic screening was 0.60 (95% CI 0.49–0.73);
- no randomized trial has established mortality benefit;
- even in very high-risk settings, positive predictive value can be low.

## Supporting Population Context

### NCI Stomach (Gastric) Cancer Prevention PDQ

Provides broader gastric-cancer prevention and risk context, including epidemiologic and risk-factor background.

### NCCN Gastric Cancer Version 2.2026

Provides current gastric-cancer clinical framework and geographic incidence context. The supplied NCCN material describes marked geographic variation, with particularly high incidence in Northeast Asia and other regions.

# Evidence Matrix

| Clinical Claim | Supporting Evidence |
|---|---|
| Gastric-cancer incidence varies substantially by population/geography. | NCI Screening PDQ; NCCN Gastric Cancer v2.2026 |
| Gastric cancer is particularly common in East Asia. | NCI Screening PDQ |
| Japan has had a national population-based screening program using barium-meal photofluorography since the 1960s. | NCI Screening PDQ |
| Participation in the cited Japanese photofluorography program was approximately 10–20%. | NCI Screening PDQ |
| Endoscopy appears more sensitive than photofluorography for gastric-cancer detection. | NCI Screening PDQ |
| Ten Asian endoscopic screening studies were identified from Japan, South Korea, and China. | NCI Screening PDQ |
| The cited endoscopic studies were nonrandomized. | NCI Screening PDQ |
| Pooled RR for gastric-cancer mortality was 0.60 (95% CI 0.49–0.73). | NCI Screening PDQ |
| Evidence for mortality reduction remains inadequate because randomized evidence is lacking. | NCI Screening PDQ |
| Evidence from high-risk areas may not apply to low-risk populations. | NCI Screening PDQ |
| Even very high-risk screening programs can have low PPV. | NCI Screening PDQ |
| The Japanese Wakayama program had PPV 0.85% and cancer detection rate 0.28%. | NCI Screening PDQ |
| No mortality reduction was observed in the cited Wakayama comparison over seven years. | NCI Screening PDQ |

# Evidence Notes

## 1. Population Incidence Is Central

The clinical rationale is:

**Higher baseline incidence**

→ more cancers potentially present in the screened population

→ greater opportunity for screening to detect disease

→ potentially different benefit–harm balance from low-incidence populations.

The source evidence supports the population-level distinction but does not establish a universal incidence threshold at which screening must begin.

## 2. Japan as an Exemplar

Japan provides the longest and most detailed population-screening experience in the supplied materials.

The NCI describes a national barium-meal photofluorography program ongoing since the 1960s, with participation rates in the cited evidence of approximately 10–20%.

This should be presented as an exemplar, not a universal template.

## 3. Endoscopic Screening Evidence

The NCI-cited meta-analysis included 10 nonrandomized studies from Japan, South Korea, and China.

The pooled RR for gastric-cancer mortality associated with endoscopic screening was:

**0.60 (95% CI 0.49–0.73).**

All but one study had individual RR estimates of 0.72 or lower, but there was significant heterogeneity across studies.

The evidence is encouraging but observational.

## 4. High Incidence Does Not Guarantee Program Success

The Wakayama program included 17,647 men aged 40–60 years.

Combined serum pepsinogen and barium digital radiography produced:

- PPV: 0.85%
- positive rate for serum pepsinogen: 19.5%
- positive rate for radiography: 22.5%
- cancer detection rate: 0.28%

No reduction in gastric-cancer mortality was observed over seven years compared with an age-matched surrounding population.

This is an important counterweight to the assumption that high incidence automatically makes any screening program effective.

## 5. Generalizability

The NCI explicitly notes that studies from high-risk areas may not be applicable to low-risk areas such as the United States.

Therefore:

**Evidence context ≠ universal policy.**

The package should preserve this distinction.

## 6. Historical Screening Outside East Asia

The NCI also describes a Costa Rica photofluorography pilot and a Venezuelan radiographic screening study.

The Costa Rica study had important biases and concluded that the cost of routine photofluorography would be too high for the country.

The Venezuelan study showed no detectable reduction in gastric-cancer mortality.

These examples reinforce that screening results cannot simply be exported from one population to another.

# Clinical Claims Summary

The evidence supports the following messages:

- High-incidence populations provide the strongest practical evidence base for organized gastric-cancer screening.
- Japan has a long history of population-based screening.
- Japan, South Korea, and China provide important observational evidence for endoscopic screening.
- Endoscopy appears more sensitive than photofluorography.
- Asian observational studies generally associate endoscopic screening with lower gastric-cancer mortality.
- The evidence is nonrandomized and therefore does not establish causality.
- High incidence strengthens screening rationale but does not guarantee mortality benefit from a particular program.
- Screening evidence from high-incidence populations may not generalize to low-incidence populations.
- Participation and follow-up capacity are part of population-screening effectiveness.
- Population strategy should not be confused with individual high-risk eligibility or detailed modality interpretation.

# Evidence Consistency Review

The supplied evidence is internally consistent:

1. Gastric-cancer incidence varies substantially between populations.
2. Screening experience is concentrated in high-risk/high-incidence settings.
3. East Asian observational evidence supports a possible mortality benefit from endoscopic screening.
4. The evidence is nonrandomized.
5. Very high-risk programs can still have low PPV and limited observed mortality benefit.
6. Evidence from high-incidence populations should not automatically be applied to low-incidence populations.

No contradiction affecting the approved PP-0173 scope was identified.

# Evidence Gaps

The supplied materials do not establish:

- a universal incidence threshold for population screening;
- a universal screening age;
- a universal screening interval;
- a universal screening modality;
- a universal algorithm combining endoscopy, radiography, and serum pepsinogen;
- randomized proof that population screening reduces gastric-cancer mortality;
- direct transferability of East Asian screening outcomes to low-incidence populations;
- universal cost-effectiveness across countries;
- a universal participation target.

These gaps are intentionally preserved.

# Out-of-Scope Topics / Delegation

| Topic | Delegated To |
|---|---|
| Individual high-risk eligibility | PP-0170 |
| Endoscopic screening | PP-0171 |
| Serum pepsinogen | PP-0172 |
| H. pylori prevention | PP-0160 / PP-0161 |
| Atrophic gastritis | PP-0165 |
| Intestinal metaplasia | PP-0166 |
| Gastric adenomas | PP-0169 |
| Screening harms and false results | PP-0174 |
| Diagnostic work-up | PP-0175+ |
| Endoscopic diagnosis | PP-0176 |
| Biopsy strategy | PP-0177 |
| Histopathology | PP-0178+ |
| Treatment | Downstream treatment packages |
| Detailed health economics | Future dedicated package if explicitly defined |

# Future Update Triggers

Review this package when:

- NCI updates its gastric-cancer screening evidence.
- Randomized evidence evaluates population-based gastric-cancer screening mortality.
- New high-quality evidence clarifies screening effectiveness in low-incidence populations.
- New evidence establishes population-specific thresholds or intervals.
- Major screening programs change their evidence-based strategy.
- PP Registry changes ownership of population screening topics.

# Evidence Package Decision

**APPROVED**

The evidence package supports the approved scope of:

> **PP-0173 — Screening in High-Incidence Populations**

The package intentionally avoids universal screening thresholds, country-specific prescriptions, and unsupported mortality claims.

# Source Traceability

| Source | Relevant Content |
|---|---|
| NCI — Stomach (Gastric) Cancer Screening PDQ | Population screening, Japan, Asian endoscopic evidence, mortality evidence, PPV, generalizability |
| NCI — Stomach (Gastric) Cancer Prevention PDQ | Gastric-cancer risk/prevention context |
| NCCN Gastric Cancer Version 2.2026 | Current gastric-cancer framework and geographic incidence context |
| PP Registry | Package identity and neighboring ownership |
| Approved adjacent PP artifacts | Scope continuity and boundary delegation |

# Boundary Verification

**Core = high-incidence gastric-cancer populations, geographic incidence variation, population-based screening rationale, organized screening, East Asian evidence context, Japan as an exemplar, South Korea and China as major evidence settings, endoscopy/photofluorography/serum pepsinogen at population-program level, observational mortality evidence, evidence limitations, generalizability to low-incidence populations, participation and early-detection rationale; Supporting = immigrant/high-incidence background context, precursor-risk context, historical screening outside East Asia, and conceptual implementation/resource context; Explicitly Excluded = individual high-risk eligibility, detailed endoscopy, detailed serum pepsinogen, H. pylori testing/eradication, detailed precursor-disease management, universal age thresholds, universal screening intervals, universal modality algorithms, current country-specific screening prescriptions, detailed false-positive/false-negative analysis, detailed screening harms, overdiagnosis/overtreatment, detailed cost-effectiveness, diagnosis, biopsy, pathology, and treatment; Delegated-to PP = PP-0160, PP-0161, PP-0165, PP-0166, PP-0169, PP-0170, PP-0171, PP-0172, PP-0174, PP-0175+, PP-0176, PP-0177, PP-0178+, and downstream treatment packages.**

# Final Evidence Status

**PASS — Evidence traceability complete.**
