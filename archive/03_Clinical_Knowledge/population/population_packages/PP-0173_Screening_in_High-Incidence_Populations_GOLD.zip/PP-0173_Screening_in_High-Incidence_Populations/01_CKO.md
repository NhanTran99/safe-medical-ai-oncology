# Clinical Knowledge Object (CKO)

## Metadata

| Field | Value |
|---|---|
| CKO ID | CKO-PP-0173 |
| PP ID | PP-0173 |
| Title | Screening in High-Incidence Populations |
| Clinical Domain | Risk & Prevention |
| Population Wave | Wave 1 |
| Version | 1.0.0 |
| Audience | General public, patients, caregivers |
| Reading Level | Plain language |
| Status | Gold / Approved |
| Last Updated | 2026-08-09 |

## Educational Objectives

After reading this Population Package, the reader should be able to:

- Understand what a high-incidence population means in the context of gastric cancer.
- Understand why geographic differences in gastric-cancer incidence matter for screening.
- Understand why population-based screening has been developed or studied particularly in East Asia.
- Understand Japan as an important example of organized gastric-cancer screening.
- Understand the roles of endoscopy, barium-meal photofluorography, and serum pepsinogen at a population level.
- Understand what observational evidence from Japan, South Korea, and China suggests about endoscopic screening.
- Understand why encouraging observational evidence does not equal randomized proof of mortality benefit.
- Understand why screening evidence from high-incidence populations cannot automatically be transferred to low-incidence populations.
- Understand why screening participation and the ability to provide follow-up matter at population level.
- Understand the distinction between population-level screening policy and an individual's decision about screening.

# Scope

## Included

- Meaning of high-incidence gastric-cancer populations
- Geographic variation in gastric-cancer incidence
- Why baseline incidence affects the rationale for screening
- Population-based and organized screening
- East Asia as the principal evidence setting
- Japan as an organized-screening exemplar
- South Korea and China as major evidence settings for endoscopic screening
- High-level population role of endoscopy
- Historical population role of barium-meal photofluorography
- High-level population role of serum pepsinogen
- Observational evidence associated with endoscopic screening
- Limitations of the mortality evidence
- Generalizability from high-incidence to low-incidence populations
- Population participation and implementation context
- Conceptual relationship between screening and early detection
- Population-level benefit–harm context

## Not Included

- Individual high-risk eligibility
- Detailed endoscopic technique
- Detailed serum-pepsinogen biology or cutoff interpretation
- H. pylori testing or eradication
- Detailed management of atrophic gastritis, intestinal metaplasia, or gastric adenomas
- Universal screening age thresholds
- Universal screening intervals
- Universal modality-selection algorithms
- Country-specific current screening prescriptions
- Detailed false-positive/false-negative analysis
- Detailed screening harms
- Overdiagnosis or overtreatment analysis
- Detailed cost-effectiveness analysis
- Diagnostic work-up
- Biopsy or pathology
- Gastric-cancer treatment

# Clinical Knowledge Blocks

## Knowledge Block 1 — What Is a High-Incidence Population?

### Patient Explanation

A high-incidence population is a population in which gastric cancer occurs much more often than it does in low-incidence populations.

Gastric-cancer incidence varies substantially between regions. The disease is particularly common in parts of East Asia, and high-incidence settings have provided much of the practical experience with population-based gastric-cancer screening.

### Clinical Importance

The underlying frequency of a disease affects how much benefit a population may obtain from screening.

### Key Concepts

- High incidence
- Low incidence
- Population risk
- Geographic variation

## Knowledge Block 2 — Why Does Incidence Matter for Screening?

### Patient Explanation

When a cancer is common in a population, there are more cancers to potentially detect through screening. This can make the potential benefit of a screening program greater.

When a cancer is uncommon, fewer cancers are found through screening, so false-positive results, unnecessary investigations, and other burdens may become more important.

### Clinical Importance

Screening decisions are therefore population-dependent rather than based only on whether a test exists.

### Key Concepts

- Baseline incidence
- Screening yield
- Benefit–harm balance
- Population strategy

## Knowledge Block 3 — Why Is East Asia Important?

### Patient Explanation

East Asia has some of the world's highest gastric-cancer incidence rates. Japan, South Korea, and China have therefore contributed substantially to the evidence and experience surrounding population-based gastric-cancer screening.

### Clinical Importance

The strongest evidence for organized endoscopic screening in the supplied materials comes from these high-incidence Asian settings.

### Key Concepts

- East Asia
- Japan
- South Korea
- China

## Knowledge Block 4 — What Has Japan Done?

### Patient Explanation

Japan has had a national population-based gastric-cancer screening program using barium-meal photofluorography since the 1960s.

The NCI evidence notes that participation in the cited program was only about 10% to 20%. Endoscopic screening has also been studied extensively in Japan.

### Clinical Importance

Japan is an important example of long-term organized gastric-cancer screening, but its experience should not automatically be treated as a universal model for every country.

### Key Concepts

- Population-based screening
- Organized screening
- Photofluorography
- Japan

## Knowledge Block 5 — What Do We Know From South Korea and China?

### Patient Explanation

Studies from South Korea, China, and Japan form an important part of the evidence on endoscopic gastric-cancer screening.

The NCI-cited meta-analysis included 10 nonrandomized studies conducted in these countries between 1989 and 2014.

### Clinical Importance

These studies provide substantial observational evidence but do not provide randomized proof that screening itself caused lower mortality.

### Key Concepts

- South Korea
- China
- Japan
- Observational evidence

## Knowledge Block 6 — Which Screening Methods Have Been Used?

### Patient Explanation

Several approaches have been studied or used in high-incidence populations, including:

- endoscopy;
- barium-meal photofluorography;
- serum pepsinogen.

These approaches are not interchangeable, and their use depends on the population and screening program.

### Clinical Importance

PP-0173 explains these methods only at population-program level. Detailed explanations belong to their dedicated packages.

### Key Concepts

- Endoscopy
- Photofluorography
- Serum pepsinogen
- Screening modality

## Knowledge Block 7 — What Is the Role of Endoscopy?

### Patient Explanation

Endoscopy appears to be more sensitive than photofluorography for detecting gastric cancer.

In high-incidence Asian settings, endoscopic screening has been associated with lower gastric-cancer mortality in observational studies.

### Clinical Importance

This supports the importance of endoscopy in high-incidence screening programs while preserving the distinction between observational association and proof of causation.

### Key Concepts

- Endoscopic screening
- Sensitivity
- Mortality association
- High-incidence setting

## Knowledge Block 8 — What Was the Role of Barium Photofluorography?

### Patient Explanation

Barium-meal photofluorography was used in Japan's national population-based screening program for many years.

It is an important historical example of how a population-level screening program can be organized.

### Clinical Importance

The package does not teach the technical details of radiographic screening.

### Key Concepts

- Barium meal
- Photofluorography
- Historical screening

## Knowledge Block 9 — What Is the Population-Level Role of Serum Pepsinogen?

### Patient Explanation

Serum pepsinogen has also been studied as a screening or risk-stratification tool in high-risk populations.

Its detailed meaning, limitations, and interpretation are covered in PP-0172.

### Clinical Importance

At population level, serum pepsinogen is one example of how a blood-based marker may be incorporated into a screening strategy.

### Key Concepts

- Serum pepsinogen
- Population screening
- Risk stratification

## Knowledge Block 10 — What Does the Asian Endoscopic Evidence Show?

### Patient Explanation

A meta-analysis summarized by the NCI identified 10 nonrandomized studies from Japan, South Korea, and China.

The pooled risk ratio for gastric-cancer mortality associated with endoscopic screening was 0.60 (95% CI 0.49–0.73).

### Clinical Importance

The result is encouraging, but because the studies were nonrandomized, it does not prove that screening itself caused the lower mortality.

### Key Concepts

- Meta-analysis
- Risk ratio
- Nonrandomized studies
- Mortality

## Knowledge Block 11 — Does This Prove That Screening Saves Lives?

### Patient Explanation

No.

The observational studies generally point toward lower gastric-cancer mortality with endoscopic screening, but the NCI classifies the evidence for mortality reduction as inadequate because randomized trials have not established the effect.

### Clinical Importance

This prevents a population-level association from being presented as definitive causal evidence.

### Key Concepts

- Evidence strength
- Causal inference
- Mortality benefit
- Randomized evidence

## Knowledge Block 12 — Why Can High-Incidence Evidence Not Be Applied Everywhere?

### Patient Explanation

A screening program that may be reasonable where gastric cancer is common may not have the same balance of benefit and harm where gastric cancer is uncommon.

The number of cancers that can potentially be detected, the expected screening yield, and the burden of false-positive or follow-up procedures can all differ between populations.

### Clinical Importance

The NCI specifically cautions that evidence from high-risk areas may not be applicable to low-risk populations such as the United States.

### Key Concepts

- Generalizability
- Low-incidence population
- Screening yield
- Benefit–harm balance

## Knowledge Block 13 — Does High Incidence Guarantee a Successful Screening Program?

### Patient Explanation

No.

Even in a very high-risk setting, screening tests can have a low positive predictive value.

In a Japanese program of 17,647 men aged 40 to 60 years, combined serum pepsinogen and barium digital radiography had a positive predictive value of 0.85% and a cancer detection rate of 0.28%. No reduction in gastric-cancer mortality was observed over the seven-year period compared with an age-matched surrounding population.

### Clinical Importance

High disease incidence strengthens the rationale for screening but does not prove that a particular screening program will reduce mortality.

### Key Concepts

- Positive predictive value
- Cancer detection
- Screening effectiveness
- Program evaluation

## Knowledge Block 14 — Why Does Participation Matter?

### Patient Explanation

A population screening program can only reach people who participate.

The Japanese photofluorography program described by the NCI had participation rates in the range of 10% to 20% in the cited evidence.

### Clinical Importance

Screening effectiveness at population level depends not only on the test but also on whether people participate and can receive appropriate follow-up.

### Key Concepts

- Participation
- Program reach
- Follow-up

## Knowledge Block 15 — Why Does Early Detection Matter?

### Patient Explanation

Screening aims to find cancer earlier, when it may be more treatable.

The rationale for population screening therefore includes the possibility of shifting detection toward earlier disease.

### Clinical Importance

This package explains the population-level rationale only. Treatment of early gastric cancer belongs to downstream clinical packages.

### Key Concepts

- Early detection
- Earlier stage
- Screening rationale

## Knowledge Block 16 — Can a Screening Strategy Be Appropriate in One Country but Not Another?

### Patient Explanation

Yes.

Countries can have very different gastric-cancer incidence rates. A strategy developed in a high-incidence setting may not have the same expected benefit in a low-incidence setting.

This is why screening policy must be considered in the context of the population rather than copied solely from another country.

### Clinical Importance

This is one of the central messages of PP-0173.

### Key Concepts

- Population context
- Screening policy
- Generalizability
- Local incidence

# Common Misconceptions

### Myth 1

**“If gastric cancer is common, everyone must be screened.”**

**Fact:** High incidence strengthens the rationale for population screening, but it does not by itself establish that every person should be screened.

### Myth 2

**“Japan's screening program proves that screening works everywhere.”**

**Fact:** Japan provides important evidence, but results from high-incidence populations may not directly apply to low-incidence populations.

### Myth 3

**“Endoscopy has been proven to reduce gastric-cancer mortality.”**

**Fact:** Observational Asian studies generally show an association with lower mortality, but the studies were nonrandomized and randomized proof of mortality reduction is lacking.

### Myth 4

**“High incidence means screening tests will always have a high positive predictive value.”**

**Fact:** Even in a very high-risk Japanese program, the combined positive predictive value reported by the NCI was only 0.85%.

### Myth 5

**“A population screening program is just a test.”**

**Fact:** It also requires participation, follow-up, and sufficient capacity to evaluate abnormal results.

### Myth 6

**“The same screening interval should be used in every country.”**

**Fact:** Screening schedules are population- and program-dependent; this package does not establish a universal interval.

### Myth 7

**“If screening is useful in Japan, it should automatically be used in every low-incidence country.”**

**Fact:** The NCI specifically notes that evidence from high-risk areas may not apply to low-risk populations.

# Key Messages

- Gastric-cancer incidence varies greatly between populations.
- High-incidence populations provide much of the practical evidence for population-based gastric-cancer screening.
- Japan has a long history of organized population screening.
- Japan, South Korea, and China provide important evidence on endoscopic screening.
- Endoscopy appears more sensitive than photofluorography for detecting gastric cancer.
- Observational Asian studies generally associate endoscopic screening with lower gastric-cancer mortality.
- The evidence is predominantly nonrandomized, so causality is not established.
- High incidence strengthens the rationale for screening but does not guarantee that a particular program will reduce mortality.
- Screening evidence from high-incidence populations cannot automatically be transferred to low-incidence populations.
- Population participation and follow-up capacity matter.
- Individual high-risk screening and detailed screening modalities are handled by adjacent Population Packages.

# Knowledge Graph

## Prerequisite PPs

- PP-0170 — Gastric Cancer Screening in High-Risk Individuals
- PP-0171 — Endoscopic Screening for Gastric Cancer
- PP-0172 — Serum Pepsinogen Screening

## Supporting / Related PPs

- PP-0160 — H. pylori and Gastric Cancer Prevention
- PP-0161 — H. pylori Eradication for Gastric Cancer Prevention
- PP-0165 — Atrophic Gastritis and Gastric Cancer
- PP-0166 — Intestinal Metaplasia and Gastric Cancer
- PP-0169 — Gastric Adenomas and Cancer Risk

## Next / Downstream

- PP-0174 — Screening Harms and False Results
- PP-0175 — Gastric Cancer Diagnostic Work-up
- PP-0176 — Endoscopic Diagnosis of Gastric Cancer
- PP-0177 — Endoscopic Biopsy Strategy
- PP-0178+ — Histopathology
- Downstream treatment packages

# Revision History

| Version | Date | Summary |
|---|---|---|
| 1.0.0 | 2026-08-09 | Initial Gold Release |
