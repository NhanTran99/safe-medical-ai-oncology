# Knowledge Passport

## Identity

| Field | Value |
|---|---|
| Knowledge Passport ID | KP-PP-0173 |
| Population Package ID | PP-0173 |
| CKO | CKO-PP-0173 |
| Title | Screening in High-Incidence Populations |
| Version | 1.0.0 |
| Status | Approved |

## Knowledge Classification

| Field | Value |
|---|---|
| Clinical Domain | Risk & Prevention |
| Educational Category | Gastric Cancer Screening |
| Educational Level | Intermediate |
| Clinical Complexity | Intermediate |
| Patient Journey Stage | Before Diagnosis |
| Knowledge Granularity | Atomic population-context package |
| Intended Audience | General public, patients, caregivers |

## Patient Journey Classification

**Primary stage:** Risk awareness / Screening consideration

**Downstream transition:** Abnormal screening result → PP-0175+ diagnostic work-up

## Intended Runtime Usage

### Primary Runtime Role

Explain why gastric-cancer screening strategies differ between high-incidence and low-incidence populations.

### Secondary Runtime Roles

- Explain organized population-based screening.
- Provide Japan, South Korea, and China as evidence context.
- Explain the population-level role of endoscopy, photofluorography, and serum pepsinogen.
- Explain the strength and limitations of observational mortality evidence.
- Explain generalizability limitations.
- Distinguish population-level screening from individual high-risk screening.

## Retrieval / Runtime Relevance

**Very High**

Reason: PP-0173 is the dedicated population-context layer between individual screening eligibility/modalities and screening harms/diagnostic follow-up.

## Clinical Scope

### Core

- High-incidence gastric-cancer populations
- Geographic incidence variation
- Population-based screening rationale
- Organized screening
- East Asian evidence context
- Japan as a screening exemplar
- South Korea and China as evidence settings
- Endoscopy at population level
- Historical photofluorography
- Serum pepsinogen at population level
- Observational mortality evidence
- Evidence limitations
- Generalizability to low-incidence populations
- Participation and program reach
- Early-detection rationale

### Supporting

- Immigrant/high-incidence background as contextual bridge
- Precursor-risk context
- Historical screening outside East Asia
- Conceptual resource/implementation context

### Explicitly Excluded

- Individual high-risk eligibility
- Detailed endoscopy
- Detailed serum pepsinogen
- H. pylori diagnosis/eradication
- Detailed precursor-disease management
- Universal age thresholds
- Universal screening intervals
- Universal modality algorithms
- Country-specific current screening prescriptions
- Detailed screening harms and false-result analysis
- Overdiagnosis/overtreatment
- Detailed cost-effectiveness
- Diagnosis, biopsy, pathology, treatment

### Delegated-to PP

- PP-0160 — H. pylori and Gastric Cancer Prevention
- PP-0161 — H. pylori Eradication for Gastric Cancer Prevention
- PP-0165 — Atrophic Gastritis and Gastric Cancer
- PP-0166 — Intestinal Metaplasia and Gastric Cancer
- PP-0169 — Gastric Adenomas and Cancer Risk
- PP-0170 — Gastric Cancer Screening in High-Risk Individuals
- PP-0171 — Endoscopic Screening for Gastric Cancer
- PP-0172 — Serum Pepsinogen Screening
- PP-0174 — Screening Harms and False Results
- PP-0175+ — Gastric Cancer Diagnostic Work-up and downstream diagnosis
- Downstream treatment packages

## Authoritative Sources

1. NCI — Stomach (Gastric) Cancer Screening PDQ
2. NCI — Stomach (Gastric) Cancer Prevention PDQ
3. NCCN Gastric Cancer Version 2.2026
4. Approved adjacent Population Packages
5. PP Registry / Project governance

## Evidence Classification

### Level I — Direct Screening Evidence

- NCI Stomach (Gastric) Cancer Screening PDQ

### Supporting

- NCI Stomach (Gastric) Cancer Prevention PDQ
- NCCN Gastric Cancer v2.2026
- Approved adjacent Population Packages

## Governance Metadata

| Field | Value |
|---|---|
| Clinical Governance | Enabled |
| Evidence Traceability | Complete |
| Scope Boundary | Defined |
| Adjacent PP Boundary Review | Complete |
| Knowledge Graph | Complete |
| Runtime Ready | Yes |
| Repository Ready | Yes |

## Version Control

| Item | Value |
|---|---|
| Current Version | 1.0.0 |
| Major | 1 |
| Minor | 0 |
| Patch | 0 |

## Change History

| Version | Date | Description |
|---|---|---|
| 1.0.0 | 2026-08-09 | Initial Gold Release |

## Final Status

**APPROVED**
