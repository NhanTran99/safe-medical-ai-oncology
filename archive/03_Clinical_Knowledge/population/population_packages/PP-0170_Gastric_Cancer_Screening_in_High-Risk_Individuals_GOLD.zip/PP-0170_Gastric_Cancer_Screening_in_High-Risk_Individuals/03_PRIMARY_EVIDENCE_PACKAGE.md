# Primary Evidence Package

---

# Identity

| Field | Value |
|-------|-------|
| Evidence Package ID | EP-PP-0170 |
| Population Package ID | PP-0170 |
| Title | Gastric Cancer Screening in High-Risk Individuals |
| Clinical Domain | Risk & Prevention |
| Version | 1.0.0 |
| Status | Approved |

---

# Clinical Question

**Primary Educational Question**

> **Who may be considered at higher risk for gastric cancer, and why might screening be considered?**

---

# Educational Intent

Provide patients and caregivers with an evidence-based explanation of risk-stratified gastric cancer screening.

The package explains:

- what screening is;
- what higher risk means;
- which risk contexts may lead to consideration of screening or surveillance;
- why screening is not universal;
- why screening benefits and harms must be considered together;
- how screening differs from surveillance and diagnostic evaluation;
- why a positive or abnormal screening result does not itself establish a diagnosis.

The package intentionally stops before detailed screening modalities, diagnostic procedures, hereditary testing, or individualized screening prescriptions.

---

# Scope

## Included

- Gastric cancer screening concept
- Higher-risk populations
- Family history
- Hereditary gastric cancer risk at a high level
- Atrophic gastritis
- Intestinal metaplasia
- Pernicious anemia
- Gastric adenomas / adenomatous polyps
- Previous stomach surgery
- Geographic and immigrant background
- Screening versus surveillance
- Screening versus diagnostic evaluation
- Why screening is not routine in all populations
- Evidence limitations
- Benefit–harm balance
- High-level screening approaches
- Abnormal screening result as a transition to diagnostic evaluation

---

## Excluded

- Endoscopic screening technique
- Serum pepsinogen assay methodology or decision thresholds
- Detailed high-incidence population screening programs
- Detailed HDGC endoscopic surveillance
- Genetic-testing criteria
- Genetic counseling
- Cascade testing
- Detailed management of risk conditions
- Diagnostic work-up
- Endoscopic biopsy technique
- Detailed false-positive/false-negative analysis
- Detailed screening harms
- Individualized absolute-risk calculation
- Universal screening age or interval
- Individualized screening prescription
- Gastric cancer treatment

---

# Primary Evidence Sources

| Priority | Source | Purpose |
|----------|--------|---------|
| 1 | NCI — Stomach (Gastric) Cancer Screening PDQ | Core screening evidence, high-risk groups, screening modalities, evidence limitations |
| 2 | NCI — Genetics of Gastric Cancer PDQ | Family history, hereditary risk, geographic/migrant risk, hereditary surveillance context |
| 3 | NCI — Stomach (Gastric) Cancer Prevention PDQ | Elevated-risk groups and gastric cancer risk-factor framework |
| 4 | NCCN Gastric Cancer Version 2.2026 | Current gastric cancer clinical framework and international-risk context |
| 5 | American Cancer Society — Stomach Cancer | Patient-facing screening explanation and high-risk screening context |

---

# Supporting Sources

- ESMO/ASCO Global Curriculum, Edition 2023
- Approved adjacent Population Packages
- PP Registry and locked project governance

---

# Evidence Hierarchy

## Level I

### NCI Screening PDQ

Directly supports:

- screening definition/context;
- high-risk populations;
- lack of routine screening in the United States;
- screening modalities studied;
- limitations of screening evidence;
- clinical considerations for high-risk groups.

### NCI Genetics of Gastric Cancer PDQ

Directly supports:

- family history as a risk factor;
- hereditary gastric cancer risk;
- geographic variation;
- migrant effects;
- hereditary surveillance context.

### NCI Prevention PDQ

Directly supports:

- elevated-risk populations;
- precursor conditions;
- environmental and genetic risk factors.

### NCCN Gastric Cancer

Supports current clinical context, gastric cancer epidemiology/risk framework, and the need for risk- and context-sensitive clinical management.

### ACS

Supports patient-facing explanation of increased-risk screening and the concept that screening may be considered when benefits may outweigh risks.

---

# Evidence Matrix

| Clinical Claim | Primary Supporting Source |
|---|---|
| Gastric cancer screening is intended for people without symptoms and seeks earlier detection of cancer or precancerous abnormalities. | NCI Screening PDQ; ACS |
| Routine gastric cancer screening is not performed in the United States. | NCI Screening PDQ; ACS |
| Some groups may have elevated gastric cancer risk, including people with atrophic gastritis, pernicious anemia, gastric adenomas/polyps, certain hereditary syndromes, close family history, previous stomach surgery, and immigrant backgrounds from high-incidence countries. | NCI Screening PDQ; NCI Prevention PDQ; ACS |
| Family history is associated with increased gastric cancer risk, although estimates may be influenced by shared environmental, dietary, and H. pylori factors. | NCI Genetics PDQ |
| Gastric cancer incidence varies substantially between regions. | NCI Genetics PDQ; NCCN Gastric Cancer |
| Migrant background can contribute to gastric cancer risk context. | NCI Genetics PDQ |
| Some hereditary gastric cancer conditions require specialized surveillance or risk-reduction consideration rather than general-population screening. | NCI Genetics PDQ; ACS |
| Endoscopy, serum pepsinogen, and radiographic approaches have been studied for gastric cancer screening. | NCI Screening PDQ |
| There is no universal evidence base supporting one screening strategy for every high-risk person. | NCI Screening PDQ; NCI Genetics PDQ |
| Screening can have harms and limitations, and detecting more abnormalities does not by itself establish mortality benefit. | NCI Screening PDQ; ACS |
| An abnormal screening result requires appropriate diagnostic evaluation rather than being treated as a cancer diagnosis by itself. | NCI Screening PDQ; ACS |

---

# Evidence Notes

## 1. High-Risk Groups

NCI identifies potential higher-risk groups including older patients with atrophic gastritis or pernicious anemia, people with sporadic gastric adenomas, familial adenomatous polyposis, hereditary nonpolyposis colon cancer, and immigrant populations from countries with high gastric carcinoma rates.

NCI Prevention PDQ similarly identifies precursor conditions, family history, hereditary conditions, and other risk factors.

## 2. Family History

NCI Genetics PDQ reports increased risk among individuals with a first-degree relative with gastric cancer, while noting possible confounding from shared environment, diet, H. pylori infection, recall bias, and differing study populations.

Therefore family history should be presented as a risk factor, not as an automatic screening prescription.

## 3. Hereditary Risk

NCI Genetics PDQ states that gastric cancer surveillance guidance in the United States is established for selected pathogenic-variant carriers, while routine screening is not generally performed for people with family history alone when no hereditary pathogenic variant has been identified.

This supports a distinction between:

**risk recognition → syndrome-specific management**

and

**general high-risk screening.**

## 4. Screening Evidence

NCI reports that screening approaches have included endoscopy, serum pepsinogen, and radiographic methods. Evidence for mortality benefit is limited and varies by setting.

Serum pepsinogen has important limitations, including absence of standard abnormal cutoffs and interference from H. pylori eradication and proton-pump inhibitor use. Detailed pepsinogen content is therefore delegated to PP-0172.

## 5. Population Context

Gastric cancer incidence varies substantially geographically. NCI describes migrant effects and substantial population differences in incidence.

The high-incidence population screening framework is intentionally delegated to PP-0173.

---

# Clinical Claims Summary

The evidence supports the following educational messages:

- Gastric cancer screening is a strategy for people without symptoms.
- Screening is not the same as diagnostic evaluation.
- Some people have higher gastric cancer risk than the general population.
- High-risk contexts include selected precursor gastric conditions, family history, hereditary syndromes, previous stomach surgery, and certain geographic or immigrant backgrounds.
- High-risk status does not mean that cancer is already present.
- High-risk status does not automatically determine one universal screening plan.
- Routine screening is not performed in every country or population.
- Screening benefits must be weighed against false results, additional procedures, overdiagnosis, and other potential harms.
- Detailed screening modality selection belongs to dedicated downstream Population Packages.
- An abnormal screening result requires appropriate diagnostic follow-up.

---

# Evidence Consistency Review

The supplied NCI, ACS, NCCN, and ESMO/ASCO materials are consistent on the central educational framework:

1. gastric cancer risk is heterogeneous;
2. screening value depends on population risk and clinical context;
3. routine population screening is not universal;
4. selected high-risk populations may warrant consideration of screening or surveillance;
5. evidence and benefit–harm balance remain important;
6. hereditary risk requires specialized assessment.

No clinically meaningful contradiction was identified for the core educational scope.

Where evidence is incomplete or context-dependent, the package deliberately uses qualified language such as:

- “may be considered”;
- “selected high-risk groups”;
- “depends on clinical context”;
- “evidence is limited.”

---

# Evidence Gaps

The supplied evidence does not support:

- one universal screening age for all high-risk individuals;
- one universal screening interval;
- one universally preferred screening modality for all high-risk individuals;
- a universal mortality benefit across all screening populations;
- an individualized gastric cancer screening prescription based only on the presence of one risk factor;
- a universal screening algorithm for people with family history but no identified hereditary pathogenic variant.

These gaps are intentionally preserved rather than filled with unsupported general knowledge.

---

# Future Update Triggers

Review this package when:

- NCI substantially revises gastric cancer screening evidence.
- NCCN changes gastric cancer screening or high-risk assessment recommendations.
- Major international gastric cancer screening guidelines are updated.
- Evidence establishes or refutes mortality benefit in additional high-risk populations.
- New validated screening modalities materially change the risk–benefit framework.
- Hereditary gastric cancer surveillance recommendations materially change.
- The PP Registry changes ownership of screening modalities or high-risk populations.

---

# Evidence Package Decision

**APPROVED**

The evidence package provides traceable support for the approved educational scope of:

> **PP-0170 — Gastric Cancer Screening in High-Risk Individuals**

The package intentionally avoids unsupported universal screening thresholds, intervals, or individualized screening prescriptions.

---

# Source Traceability

| Source | Relevant Content |
|--------|------------------|
| NCI — Stomach (Gastric) Cancer Screening PDQ | Screening definition; high-risk groups; screening approaches; limitations; clinical considerations |
| NCI — Genetics of Gastric Cancer PDQ | Family history; hereditary risk; migrant effects; regional variation; hereditary surveillance |
| NCI — Stomach (Gastric) Cancer Prevention PDQ | Elevated-risk populations; precursor conditions; risk-factor framework |
| NCCN Gastric Cancer Version 2.2026 | Current gastric cancer clinical framework and risk/population context |
| ACS — Stomach Cancer | Patient-facing high-risk screening explanation; risk–benefit framing |
| ESMO/ASCO Global Curriculum 2023 | General oncology principles for risk assessment and screening/prevention communication |

---

# Boundary Verification

The evidence package was checked against the adjacent PP architecture.

### PP-0165–PP-0169

These packages establish the underlying risk conditions.

### PP-0170

Owns the **high-risk screening framework** and integrates risk conditions into screening consideration.

### PP-0171

Owns detailed endoscopic screening.

### PP-0172

Owns serum pepsinogen screening.

### PP-0173

Owns screening in high-incidence populations.

### PP-0174

Owns detailed screening harms and false results.

### PP-0175–PP-0177

Own diagnostic follow-through after an abnormal screening finding.

The boundary is therefore clinically coherent and non-duplicative.

---

# Final Evidence Status

**PASS — Evidence traceability complete.**

All major clinical claims are supported by the supplied authoritative source materials, and evidence gaps are explicitly preserved where the source set does not support a universal recommendation.
