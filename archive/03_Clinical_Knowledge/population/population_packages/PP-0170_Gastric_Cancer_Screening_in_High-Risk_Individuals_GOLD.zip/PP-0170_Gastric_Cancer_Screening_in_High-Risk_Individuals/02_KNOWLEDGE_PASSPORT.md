# Knowledge Passport

---

# Identity

| Field | Value |
|-------|-------|
| Knowledge Passport ID | KP-PP-0170 |
| Population Package ID | PP-0170 |
| Clinical Knowledge Object | CKO-PP-0170 |
| Title | Gastric Cancer Screening in High-Risk Individuals |
| Clinical Domain | Risk & Prevention |
| Clinical Domain Code | RP |
| Population Batch | Population Wave 1 |
| Population Wave | Wave 1 |
| Version | 1.0.0 |
| Status | Approved |

---

# Knowledge Classification

| Field | Value |
|-------|-------|
| Knowledge Type | Clinical Risk and Prevention Knowledge |
| Educational Category | Gastric Cancer Screening |
| Educational Level | Introductory |
| Clinical Complexity | Intermediate |
| Intended Audience | General public, patients at increased risk of gastric cancer, caregivers |
| Reading Level | Plain Language |
| Knowledge Granularity | Atomic (Single Educational Question) |
| Knowledge Scope | High-risk gastric cancer screening framework |

---

# Patient Journey Classification

| Stage | Applicable |
|---------|------------|
| Before Diagnosis | ✓ |
| During Diagnosis | |
| Treatment Decision | |
| Active Treatment | |
| Follow-up | |
| Survivorship | |
| Palliative Care | |

**Reason:**

This package addresses risk assessment and screening before a gastric cancer diagnosis is established. It also provides the conceptual transition from screening to diagnostic evaluation when an abnormal result is found.

---

# Intended Runtime Usage

## Primary Runtime Role

- Explain who may be at increased risk for gastric cancer and why screening may be considered.

## Secondary Runtime Role

- Risk communication
- Screening education
- Shared decision-making support
- Patient preparation for discussions with healthcare professionals
- Prevention and early-detection education
- Knowledge graph integration

## Typical Trigger Questions

- Who is at high risk for stomach cancer?
- Do I need stomach cancer screening?
- Does family history mean I need screening?
- Does intestinal metaplasia increase my need for screening?
- Does a gastric adenoma mean I need screening?
- Does being from a country with high stomach cancer rates matter?
- Is stomach cancer screening recommended for everyone?
- What is the difference between screening and surveillance?
- What happens if a screening test is abnormal?

---

# Retrieval Priority

**Very High**

**Reason:**

High-risk screening is a key decision point connecting gastric cancer risk conditions to dedicated screening modalities and downstream diagnostic evaluation.

---

# Knowledge Graph

## Prerequisite Population Packages

- PP-0011 — Risk Factors
- PP-0154 — Gastric Cancer Genetic Risk Assessment
- PP-0155 — Family History and Gastric Cancer Risk
- PP-0165 — Atrophic Gastritis and Gastric Cancer
- PP-0166 — Intestinal Metaplasia and Gastric Cancer
- PP-0167 — Pernicious Anemia and Gastric Cancer
- PP-0169 — Gastric Adenomas and Cancer Risk

## Related Population Packages

- PP-0159 — Endoscopic Surveillance in HDGC
- PP-0160 — H. pylori and Gastric Cancer Prevention
- PP-0161 — H. pylori Eradication for Gastric Cancer Prevention
- PP-0171 — Endoscopic Screening for Gastric Cancer
- PP-0172 — Serum Pepsinogen Screening
- PP-0173 — Screening in High-Incidence Populations
- PP-0174 — Screening Harms and False Results

## Downstream

PP-0170
→ PP-0171 Endoscopic Screening
→ PP-0172 Serum Pepsinogen Screening
→ PP-0173 Screening in High-Incidence Populations
→ PP-0174 Screening Harms and False Results
→ PP-0175 Gastric Cancer Diagnostic Work-up
→ PP-0176 Endoscopic Diagnosis
→ PP-0177 Endoscopic Biopsy Strategy

---

# Clinical Scope

## Included

- High-risk gastric cancer screening concept
- Risk-stratified screening
- Family history
- Hereditary risk at a high level
- Precursor gastric conditions
- Gastric adenomas
- Previous stomach surgery
- Geographic and immigrant population context
- Screening versus surveillance
- Screening versus diagnosis
- Evidence limitations
- Benefit–harm balance

## Explicitly Excluded

- Detailed endoscopic screening technique
- Serum pepsinogen methodology and thresholds
- Population-level high-incidence screening programs
- Detailed HDGC surveillance protocols
- Hereditary genetic-testing criteria
- Genetic counseling and cascade testing
- Detailed management of atrophic gastritis, intestinal metaplasia, pernicious anemia, or gastric adenomas
- Diagnostic work-up and biopsy technique
- Detailed screening harms and false-result analysis
- Individualized absolute-risk calculation
- Individualized screening prescription

These topics are covered by dedicated Population Packages.

---

# Authoritative Sources

## Primary Sources

1. National Cancer Institute (NCI) — Stomach (Gastric) Cancer Screening PDQ
2. National Cancer Institute (NCI) — Genetics of Gastric Cancer PDQ
3. National Cancer Institute (NCI) — Stomach (Gastric) Cancer Prevention PDQ
4. American Cancer Society (ACS) — Stomach Cancer
5. NCCN Clinical Practice Guidelines in Oncology — Gastric Cancer, Version 2.2026

## Supporting Sources

- ESMO/ASCO Recommendations for a Global Curriculum in Medical Oncology, Edition 2023
- Adjacent approved Population Packages and PP Registry

---

# Evidence Classification

## Evidence Model

Authoritative Educational Synthesis

## Evidence Hierarchy

### Level I

- NCI Screening PDQ
- NCI Genetics PDQ
- NCI Prevention PDQ
- NCCN Gastric Cancer
- ACS patient education

### Supporting

- ESMO/ASCO Global Curriculum
- Approved project governance and adjacent PP artifacts

---

# Governance Metadata

| Field | Value |
|-------|-------|
| Clinical Governance | Enabled |
| Evidence Traceability | Complete |
| Scope Boundary | Defined |
| Adjacent PP Boundary Review | Complete |
| Knowledge Graph | Complete |
| Runtime Ready | Yes |
| Repository Ready | Yes |

---

# Version Control

| Item | Value |
|-------|-------|
| Current Version | 1.0.0 |
| Major Version | 1 |
| Minor Version | 0 |
| Patch Version | 0 |

---

# Change History

| Version | Date | Description |
|---------|------|-------------|
| 1.0.0 | 2026-08-09 | Initial Gold Release Knowledge Passport |

---

# Final Status

**APPROVED**

This Knowledge Passport is the official governance metadata for **PP-0170 — Gastric Cancer Screening in High-Risk Individuals** and is compliant with the locked Gold Population Package Specification v1.0.
