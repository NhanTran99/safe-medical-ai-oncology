# Clinical Knowledge Object (CKO)

---

## Metadata

| Field | Value |
|-------|-------|
| CKO ID | CKO-PP-0170 |
| Population Package ID | PP-0170 |
| Title | Gastric Cancer Screening in High-Risk Individuals |
| Clinical Domain | Risk & Prevention |
| Population Wave | Wave 1 |
| Version | 1.0.0 |
| Audience | General public, patients at increased risk of gastric cancer, caregivers |
| Reading Level | Plain language |
| Last Updated | 2026-08-09 |

---

# Educational Objectives

After reading this Population Package, the reader should be able to:

- Understand what gastric cancer screening is.
- Understand the difference between screening, surveillance, and diagnostic evaluation.
- Understand what it means to be at higher risk for gastric cancer.
- Recognize major risk contexts that may lead to consideration of screening or surveillance.
- Understand why family history and hereditary risk can matter.
- Recognize the relevance of precursor gastric conditions and gastric adenomas.
- Understand why geographic and population background can influence gastric cancer risk.
- Understand why screening is not recommended routinely for everyone in every country.
- Understand that screening benefits and harms must be considered together.
- Understand that an abnormal screening result does not by itself establish a diagnosis of cancer.

---

# Scope

## Included

- Definition and purpose of gastric cancer screening
- Average-risk versus higher-risk populations
- Major high-risk domains
- Family history
- Hereditary gastric cancer risk at a high level
- Atrophic gastritis, intestinal metaplasia, pernicious anemia, and gastric adenomas as risk contexts
- Geographic and immigrant-background risk
- Screening versus surveillance
- Screening versus diagnostic evaluation
- Why screening is not universal
- Evidence limitations and uncertainty
- High-level introduction to screening approaches
- Conceptual benefit–harm balance
- What an abnormal screening result may lead to
- Patient-facing interpretation and common misconceptions

---

# Knowledge Block 1 — What Is Gastric Cancer Screening?

## Patient Explanation

**Gastric cancer screening** means looking for gastric cancer or precancerous abnormalities in people who do not have symptoms suggesting the disease.

The purpose of screening is to identify disease earlier, when it may be easier to treat.

Screening is different from diagnostic testing. If a person has symptoms or another abnormal finding that needs investigation, the evaluation is no longer simply a screening process.

---

## Clinical Importance

Screening is a population or risk-stratified strategy, not a substitute for diagnostic evaluation.

---

## Key Concepts

- Screening
- Early detection
- Asymptomatic population
- Diagnostic evaluation

---

# Knowledge Block 2 — What Does “High Risk” Mean?

## Patient Explanation

A person is considered **higher risk** when their chance of developing gastric cancer is greater than that of a reference population.

Higher risk does not mean that a person already has gastric cancer, and it does not mean that cancer will definitely develop.

Risk may be influenced by inherited factors, family history, gastric conditions, previous gastric surgery, geographic background, and other environmental or population factors.

---

## Clinical Importance

Risk assessment helps determine whether screening or surveillance may be worth considering.

---

## Key Concepts

- Relative risk
- Risk factors
- High-risk population
- Risk assessment

---

# Knowledge Block 3 — Who May Be Considered at Higher Risk?

## Patient Explanation

The supplied evidence identifies several groups that may have increased gastric cancer risk, including people with:

- atrophic gastritis or pernicious anemia;
- gastric adenomas or other potentially precancerous gastric polyps;
- certain inherited cancer syndromes;
- close family members with gastric cancer;
- previous stomach surgery;
- an immigrant or population background associated with countries where gastric cancer is more common.

Not every person in one of these groups will need the same screening approach.

---

## Clinical Importance

High-risk status is a clinical context rather than a universal screening prescription.

---

## Key Concepts

- Risk domains
- Individualized assessment
- Clinical context

---

# Knowledge Block 4 — Why Does Family History Matter?

## Patient Explanation

Having close relatives with gastric cancer can increase a person's risk.

The size of this increase varies between studies and populations. Shared factors such as H. pylori infection, diet, environment, and hereditary factors may all contribute.

A family history is therefore important information for clinicians when assessing gastric cancer risk.

---

## Clinical Importance

Family history can contribute to identifying people who may need more individualized risk assessment.

---

## Key Concepts

- First-degree relatives
- Familial risk
- Hereditary versus shared environmental risk

---

# Knowledge Block 5 — How Can Hereditary Conditions Affect Screening?

## Patient Explanation

Some inherited cancer syndromes can substantially increase gastric cancer risk.

Examples include hereditary diffuse gastric cancer associated with pathogenic variants such as **CDH1** or **CTNNA1**, as well as selected polyposis or Lynch syndrome contexts.

People with hereditary risk may need specialized surveillance or risk-reduction discussions rather than the same screening approach used for the general population.

---

## Clinical Importance

Hereditary risk requires syndrome-specific clinical management.

---

## Key Concepts

- Hereditary cancer syndrome
- Genetic risk
- Specialized surveillance
- Risk reduction

---

# Knowledge Block 6 — How Can Gastric Conditions Affect Screening Considerations?

## Patient Explanation

Certain gastric conditions are associated with increased gastric cancer risk.

These include:

- chronic atrophic gastritis;
- intestinal metaplasia;
- pernicious anemia;
- gastric adenomas or adenomatous polyps.

These conditions do not mean that cancer is inevitable. They indicate a higher-risk clinical context in which screening or follow-up may be considered.

---

## Clinical Importance

The underlying condition should be understood before deciding whether and how screening is appropriate.

---

## Key Concepts

- Precursor condition
- Increased risk
- Risk stratification

---

# Knowledge Block 7 — Why Can Geographic or Immigrant Background Matter?

## Patient Explanation

Gastric cancer is much more common in some regions of the world than in others.

People who move from a country with a high rate of gastric cancer to a lower-risk country may retain an elevated risk, particularly in the first generation.

For this reason, a person's country of birth or population background can be part of gastric cancer risk assessment.

---

## Clinical Importance

Geographic background can influence whether a person belongs to a population in which screening is more strongly considered.

---

## Key Concepts

- Geographic variation
- High-incidence regions
- Immigrant population
- Population risk

---

# Knowledge Block 8 — Is Screening Recommended for Everyone?

## Patient Explanation

No.

In the United States, routine gastric cancer screening is not recommended for the general population because gastric cancer is relatively uncommon and the overall balance of benefits and harms has not supported routine population screening.

Some countries with much higher gastric cancer incidence use population screening approaches.

---

## Clinical Importance

The value of screening depends on the underlying disease burden, population risk, screening performance, and potential harms.

---

## Key Concepts

- Average risk
- High risk
- Population incidence
- Benefit–harm balance

---

# Knowledge Block 9 — Screening vs Surveillance vs Diagnosis

## Patient Explanation

These terms are related but are not identical.

**Screening** looks for cancer or precancer in people without symptoms.

**Surveillance** means planned monitoring of people who are already known to have an increased-risk condition or hereditary risk.

**Diagnostic evaluation** investigates symptoms or an abnormal finding to determine whether cancer or another disease is present.

A person with symptoms should not simply wait for a screening test.

---

## Clinical Importance

Keeping these concepts separate prevents delays in appropriate diagnostic evaluation.

---

## Key Concepts

- Screening
- Surveillance
- Diagnosis
- Symptoms

---

# Knowledge Block 10 — What Screening Approaches Have Been Studied?

## Patient Explanation

Different approaches to gastric cancer screening have been studied, including:

- upper endoscopy;
- serum pepsinogen testing;
- radiographic screening in some settings.

The appropriate approach depends on the population, clinical context, local practice, and available evidence.

This package introduces these approaches only at a high level.

---

## Clinical Importance

Specific screening modalities require separate educational packages.

---

## Key Concepts

- Endoscopic screening
- Serum pepsinogen
- Radiographic screening
- Modality selection

---

# Knowledge Block 11 — Why Is Screening Not Automatically Beneficial?

## Patient Explanation

A screening program can find abnormalities without necessarily being proven to reduce deaths from cancer.

Screening can also lead to additional tests, procedures, false-positive or false-negative results, and detection of abnormalities that might never have caused harm.

For gastric cancer, the evidence for mortality benefit is not equally strong across populations and screening approaches.

---

## Clinical Importance

Screening decisions should consider both potential benefits and potential harms.

---

## Key Concepts

- Mortality benefit
- False results
- Overdiagnosis
- Procedural harms
- Benefit–harm balance

---

# Knowledge Block 12 — What Happens if a Screening Test Is Abnormal?

## Patient Explanation

An abnormal screening result does not automatically mean that a person has gastric cancer.

It may mean that further evaluation is needed.

Depending on the situation, this may involve diagnostic endoscopy, biopsy, pathology, or other tests.

---

## Clinical Importance

Screening is a first step in a pathway, not a final diagnosis.

---

## Key Concepts

- Abnormal screening result
- Diagnostic evaluation
- Endoscopy
- Biopsy
- Pathology

---

# Knowledge Block 13 — Does Everyone With a Risk Factor Need the Same Screening Schedule?

## Patient Explanation

No.

There is no single screening schedule that applies to every person with a gastric cancer risk factor.

The appropriate approach depends on why the person is at increased risk, the country or population, the available evidence, and the person's overall clinical situation.

---

## Clinical Importance

Avoiding universal schedules prevents unsupported or inappropriate screening advice.

---

## Key Concepts

- Individualized screening
- Risk-specific management
- Clinical guidelines

---

# Common Misconceptions

### Myth 1

**“If I am high risk, I already have gastric cancer.”**

**Fact:**  
High risk means the chance of developing gastric cancer is higher than in a reference population. It does not mean cancer is already present.

### Myth 2

**“Everyone at high risk should have the same screening test.”**

**Fact:**  
Screening considerations depend on the underlying risk, population, country, and available evidence.

### Myth 3

**“Gastric cancer screening is recommended for everyone.”**

**Fact:**  
Routine population screening is not performed everywhere. In the United States, it is not routinely performed.

### Myth 4

**“A screening test diagnoses gastric cancer.”**

**Fact:**  
Screening looks for cancer or precancerous abnormalities. An abnormal result may require diagnostic evaluation.

### Myth 5

**“Finding more cancers automatically proves that screening saves lives.”**

**Fact:**  
Finding disease earlier does not by itself prove a reduction in mortality. Screening programs must be evaluated for meaningful benefits as well as harms.

### Myth 6

**“A risk factor means I must be screened.”**

**Fact:**  
A risk factor may prompt discussion of screening or surveillance, but it does not automatically determine a universal screening plan.

---

# Key Messages

- Gastric cancer screening looks for cancer or precancerous abnormalities in people without symptoms.
- High-risk status means a higher-than-reference risk, not a diagnosis of cancer.
- Family history, hereditary conditions, precursor gastric conditions, previous stomach surgery, and some geographic or immigrant backgrounds can contribute to higher risk.
- Not every high-risk person needs the same screening strategy.
- Routine gastric cancer screening is not recommended for the general population in the United States.
- Screening benefits and harms must be considered together.
- Screening is different from surveillance and diagnostic evaluation.
- An abnormal screening result requires appropriate follow-up rather than being treated as a diagnosis by itself.

---

# Knowledge Graph

## Prerequisite Population Packages

- PP-0011 — Risk Factors
- PP-0154 — Gastric Cancer Genetic Risk Assessment
- PP-0155 — Family History and Gastric Cancer Risk
- PP-0165 — Atrophic Gastritis and Gastric Cancer
- PP-0166 — Intestinal Metaplasia and Gastric Cancer
- PP-0167 — Pernicious Anemia and Gastric Cancer
- PP-0169 — Gastric Adenomas and Cancer Risk

## Related Population Packages

- PP-0159 — Endoscopic Surveillance in HDGC
- PP-0160 — H. pylori and Gastric Cancer Prevention
- PP-0161 — H. pylori Eradication for Gastric Cancer Prevention
- PP-0171 — Endoscopic Screening for Gastric Cancer
- PP-0172 — Serum Pepsinogen Screening
- PP-0173 — Screening in High-Incidence Populations
- PP-0174 — Screening Harms and False Results

## Next / Downstream

- PP-0171 — Endoscopic Screening for Gastric Cancer
- PP-0172 — Serum Pepsinogen Screening
- PP-0173 — Screening in High-Incidence Populations
- PP-0174 — Screening Harms and False Results
- PP-0175 — Gastric Cancer Diagnostic Work-up
- PP-0176 — Endoscopic Diagnosis
- PP-0177 — Endoscopic Biopsy Strategy

---

# Revision History

| Version | Date | Summary |
|---------|------|---------|
| 1.0.0 | 2026-08-09 | Initial Gold Release |
