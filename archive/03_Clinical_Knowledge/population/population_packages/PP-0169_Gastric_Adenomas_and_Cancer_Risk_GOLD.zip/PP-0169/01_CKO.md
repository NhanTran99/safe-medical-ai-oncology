# Clinical Knowledge Object (CKO)

---

## Metadata

| Field | Value |
|-------|-------|
| CKO ID | CKO-PP-0169 |
| Population Package ID | PP-0169 |
| Title | Gastric Adenomas and Cancer Risk |
| Clinical Domain | Risk & Prevention |
| Population Wave | Wave 1 |
| Version | 1.0.0 |
| Audience | General public, patients, caregivers |
| Reading Level | Plain language |
| Last Updated | 2026-08-09 |

---

# Educational Objectives

After reading this Population Package, the reader should be able to:

- Understand what a gastric adenoma is.
- Recognize that a gastric adenoma is not the same as gastric cancer.
- Understand why gastric adenomas can have malignant potential.
- Recognize that malignant potential is not identical for all gastric adenomas.
- Understand why histologic subtype and size are clinically important.
- Understand the conceptual role of dysplasia in assessing gastric polyp significance.
- Recognize the association between gastric adenomas and increased gastric-cancer risk.
- Understand that gastric adenomas may occur sporadically or in hereditary polyposis settings.
- Understand why an adenoma may require appropriate clinical evaluation.
- Feel more confident discussing a gastric adenoma and its cancer risk with the healthcare team.

---

# Scope

## Included

- Definition of gastric adenoma
- Gastric adenoma as a type of gastric polyp
- Malignant potential
- Histologic subtype as a determinant of risk
- Size as a determinant of risk
- Conceptual relationship with dysplasia
- Association with gastric-cancer risk
- Sporadic versus hereditary context
- Conceptual endoscopic/pathologic evaluation
- Common misconceptions
- Key messages

---

## Not Included

This Population Package does **not** explain:

- Detailed gastric-polyp taxonomy
- Detailed histopathologic classification
- Microscopic diagnostic criteria
- Detailed dysplasia grading
- Dysplasia treatment
- Endoscopy technique
- Biopsy technique
- Gastric adenoma removal
- Endoscopic mucosal resection (EMR)
- Endoscopic submucosal dissection (ESD)
- H. pylori testing or eradication
- Atrophic gastritis management
- Intestinal metaplasia classification or surveillance
- Hereditary cancer genetic testing or counseling
- Gastric-cancer screening algorithms
- Screening intervals
- Individualized absolute gastric-cancer risk calculation
- Gastric-cancer treatment

These topics are covered by separate Population Packages.

---

# Knowledge Block 1 — What Is a Gastric Adenoma?

## Patient Explanation

A **gastric adenoma** is a type of polyp that develops in the lining of the stomach.

Gastric polyps are not all the same. They can have different tissue types and different levels of potential concern. Gastric adenomas are important because they can have **malignant potential**, meaning that some may develop into cancer or may be associated with areas of more advanced abnormal change.

A gastric adenoma is **not the same thing as gastric cancer**.

---

## Clinical Importance

Gastric adenomas are a clinically important subset of gastric polyps because their potential to become malignant is higher than that of many other gastric polyp types.

The National Cancer Institute reports that gastric adenomas make up approximately 10% of gastric polyps.

---

## Key Concepts

- Gastric polyp
- Gastric adenoma
- Malignant potential
- Gastric cancer

---

# Knowledge Block 2 — Does a Gastric Adenoma Mean That a Person Already Has Stomach Cancer?

## Patient Explanation

**No.**

A gastric adenoma is not the same as established stomach cancer.

However, some gastric adenomas have the potential to become malignant, and some may contain or be associated with dysplastic changes. For this reason, a gastric adenoma should not simply be treated as an unimportant stomach polyp.

The significance of an adenoma depends on its characteristics, including its histologic subtype and size, and on what the pathology evaluation shows.

---

## Clinical Importance

The distinction between **increased risk** and **existing cancer** is essential for patient understanding.

Having a gastric adenoma does not mean that cancer is inevitable.

---

## Key Concepts

- Adenoma ≠ cancer
- Malignant potential
- Dysplasia
- Risk versus certainty

---

# Knowledge Block 3 — Why Can Gastric Adenomas Be Important for Cancer Risk?

## Patient Explanation

Some gastric adenomas can have malignant potential.

The National Cancer Institute identifies gastric adenomatous polyps among conditions associated with increased gastric-cancer risk. Patients with sporadic gastric adenomas are also recognized as an elevated-risk group in the NCI gastric-cancer screening and prevention materials.

This does not mean that every person with a gastric adenoma will develop stomach cancer. It means that the finding has enough clinical significance to warrant appropriate evaluation and interpretation.

---

## Clinical Importance

Gastric adenoma is therefore best understood as a **risk-associated gastric lesion**, not as a diagnosis of cancer.

---

## Key Concepts

- Gastric-cancer risk
- Precursor lesion
- Malignant potential
- Clinical evaluation

---

# Knowledge Block 4 — Do All Gastric Adenomas Have the Same Cancer Risk?

## Patient Explanation

**No.**

The malignant potential of a gastric adenoma can vary.

The National Cancer Institute states that malignant potential is determined by features including:

- histologic subtype; and
- size.

Some histologic subtypes have higher malignant potential than others.

---

## Clinical Importance

The word **adenoma** alone does not provide the complete picture of risk.

Doctors and pathologists consider the characteristics of the lesion when determining its clinical significance.

---

## Key Concepts

- Histologic subtype
- Size
- Risk variation
- Pathologic characterization

---

# Knowledge Block 5 — Why Does Histologic Subtype Matter?

## Patient Explanation

Gastric adenomas can have different histologic subtypes.

In the NCI evidence, **pyloric gland adenomas** and **intestinal-type gastric adenomas** are described as having the highest malignant potentials among the gastric adenoma subtypes discussed, while **foveolar-type gastric adenomas** have the lowest malignant potential.

This means that two lesions both called “gastric adenoma” may not carry exactly the same level of concern.

---

## Clinical Importance

Histologic subtype is one of the reasons pathology information is important when a gastric adenoma is identified.

Detailed microscopic classification belongs to dedicated pathology Population Packages.

---

## Key Concepts

- Histologic subtype
- Pyloric gland adenoma
- Intestinal-type adenoma
- Foveolar-type adenoma
- Malignant potential

---

# Knowledge Block 6 — Why Does the Size of a Gastric Adenoma Matter?

## Patient Explanation

The **size of a gastric adenoma** is another feature that can affect its malignant potential.

A larger lesion may have different clinical significance from a smaller lesion. Size is therefore considered together with the lesion's histologic characteristics and pathology findings.

Size alone does not determine whether a lesion is cancerous.

---

## Clinical Importance

Size is one component of risk assessment rather than a stand-alone diagnosis.

This Population Package intentionally does not provide universal size thresholds for treatment or surveillance.

---

## Key Concepts

- Lesion size
- Malignant potential
- Risk assessment
- Clinical context

---

# Knowledge Block 7 — Why Does Dysplasia Matter?

## Patient Explanation

**Dysplasia** refers to abnormal changes in cells and tissue that can be associated with progression toward cancer.

The NCI notes that, more generally, the malignant potential of gastric polyps is influenced by the degree of dysplasia when dysplasia is present.

Therefore, pathology findings can add important information beyond the simple statement that a gastric polyp is an adenoma.

---

## Clinical Importance

Dysplasia is an important risk-related concept, but detailed dysplasia grading and treatment are outside the scope of this Population Package.

---

## Key Concepts

- Dysplasia
- Abnormal cellular change
- Pathology
- Cancer risk

---

# Knowledge Block 8 — How Is a Gastric Adenoma Related to Other Precancerous Gastric Conditions?

## Patient Explanation

Gastric adenomas are one type of gastric lesion associated with gastric-cancer risk.

They should not be confused with other gastric conditions such as:

- atrophic gastritis;
- intestinal metaplasia;
- pernicious anemia; or
- dysplasia as a histologic finding.

Some of these conditions can occur in related gastric-risk pathways, but they are not interchangeable diagnoses.

---

## Clinical Importance

Keeping these concepts separate helps patients understand why different findings in the stomach can have different meanings and different clinical management pathways.

The detailed relationship between chronic gastritis, atrophy, intestinal metaplasia, dysplasia, and gastric cancer is covered in dedicated Population Packages.

---

## Key Concepts

- Gastric adenoma
- Atrophic gastritis
- Intestinal metaplasia
- Dysplasia
- Gastric-cancer risk

---

# Knowledge Block 9 — Can Gastric Adenomas Occur Sporadically?

## Patient Explanation

Yes.

The NCI notes that isolated gastric polyps are usually **sporadic**, meaning that they occur without an identified hereditary cancer syndrome.

Therefore, finding a gastric adenoma does not by itself mean that a person has a hereditary cancer condition.

---

## Clinical Importance

Most gastric-polyp findings should not automatically be interpreted as evidence of inherited cancer risk.

The need for hereditary assessment depends on the broader clinical and family context.

---

## Key Concepts

- Sporadic lesion
- Hereditary syndrome
- Family history
- Clinical context

---

# Knowledge Block 10 — Can Gastric Adenomas Occur in Hereditary Conditions?

## Patient Explanation

Yes.

Gastric polyps can occur in hereditary polyposis and cancer syndromes.

For example, the NCI describes gastric adenomas and other gastric polyps in the context of **familial adenomatous polyposis (FAP)** and **gastric adenocarcinoma and proximal polyposis of the stomach (GAPPS)**.

This is different from saying that every gastric adenoma is caused by an inherited condition.

---

## Clinical Importance

A hereditary syndrome is considered from the overall pattern of gastric findings, family history, and other clinical features—not from the presence of a single adenoma alone.

Detailed hereditary risk assessment and genetic testing are outside this Population Package.

---

## Key Concepts

- FAP
- GAPPS
- Hereditary polyposis
- Sporadic adenoma
- Genetic risk assessment

---

# Knowledge Block 11 — How Is a Gastric Adenoma Identified and Evaluated?

## Patient Explanation

Gastric polyps may be identified during **upper endoscopy**.

When a gastric polyp is found, its clinical significance may depend on tissue and pathology assessment, because the appearance of a polyp alone does not establish its histologic subtype or malignant potential.

The clinical team may therefore use endoscopy and pathology information together.

---

## Clinical Importance

This package introduces the evaluation concept only.

It does not provide instructions for performing endoscopy or biopsy, nor does it define an adenoma-treatment algorithm.

---

## Key Concepts

- Upper endoscopy
- Tissue sampling
- Pathology
- Histologic subtype
- Clinical evaluation

---

# Knowledge Block 12 — Does a Gastric Adenoma Mean That Cancer Is Inevitable?

## Patient Explanation

**No.**

A gastric adenoma can be associated with increased cancer risk and can have malignant potential, but this does not mean that every adenoma will become cancer.

Risk varies according to features of the lesion, including histologic subtype and size, and according to pathology findings.

The safest way to understand the finding is:

> **A gastric adenoma can be clinically important because some adenomas have malignant potential, but an adenoma is not the same as cancer and does not make cancer inevitable.**

---

## Clinical Importance

This distinction prevents both unnecessary alarm and false reassurance.

---

## Key Concepts

- Increased risk
- Malignant potential
- Not inevitable
- Individual lesion characteristics

---

# Common Misconceptions

## Myth 1

**“A gastric adenoma means I already have stomach cancer.”**

### Fact

A gastric adenoma is not the same as established gastric cancer.

---

## Myth 2

**“All gastric adenomas have the same cancer risk.”**

### Fact

Malignant potential varies by features such as histologic subtype and size.

---

## Myth 3

**“A small adenoma can never be important.”**

### Fact

Size is one of the features considered when assessing malignant potential, but size alone does not determine the full clinical significance.

---

## Myth 4

**“If I have a gastric adenoma, I will definitely develop stomach cancer.”**

### Fact

A gastric adenoma can be associated with increased cancer risk, but cancer is not inevitable.

---

## Myth 5

**“A gastric adenoma is the same thing as intestinal metaplasia.”**

### Fact

They are different gastric conditions and should not be treated as interchangeable diagnoses.

---

## Myth 6

**“Finding a gastric adenoma automatically means I have a hereditary cancer syndrome.”**

### Fact

Gastric polyps can occur sporadically. Hereditary assessment depends on the wider clinical and family context.

---

# Key Messages

- A gastric adenoma is a type of gastric polyp.
- A gastric adenoma is **not the same as gastric cancer**.
- Some gastric adenomas have malignant potential.
- Malignant potential varies among adenomas.
- Histologic subtype and size are important features.
- Dysplasia, when present, can add to the clinical significance of a gastric polyp.
- Sporadic gastric adenomas are recognized as a gastric-cancer risk condition.
- Gastric adenomas can also occur in hereditary polyposis settings.
- Appropriate endoscopic and pathology evaluation helps characterize a gastric adenoma.
- A gastric adenoma increases clinical concern but does not mean that cancer is inevitable.

---

# Knowledge Graph

## Prerequisite Population Packages

- PP-0002 — Benign vs Malignant Tumors
- PP-0005 — How Cancer Develops
- PP-0165 — Atrophic Gastritis and Gastric Cancer
- PP-0166 — Intestinal Metaplasia and Gastric Cancer

---

## Related Population Packages

| PP | Relationship |
|----|--------------|
| PP-0167 | Pernicious Anemia and Gastric Cancer |
| PP-0168 | EBV-associated Gastric Cancer + EBV Testing in Gastric Cancer |
| PP-0170 | Gastric Cancer Screening in High-Risk Individuals |
| PP-0171 | Endoscopic Screening for Gastric Cancer |
| PP-0178 | Histopathologic Classification |
| Hereditary Gastric Cancer | Hereditary risk context |
| Dysplasia / precursor-lesion management | Detailed dysplasia interpretation and management |
| Endoscopy / Biopsy | Diagnostic procedures |

---

## Downstream / Delegated Topics

- Detailed histopathologic classification
- Dysplasia grading and management
- Endoscopic management of gastric lesions
- Gastric-cancer screening strategies
- Hereditary gastric-cancer risk assessment

---

# Revision History

| Version | Date | Summary |
|----------|------|---------|
| 1.0.0 | 2026-08-09 | Initial Gold Release |
