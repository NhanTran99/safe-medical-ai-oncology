# Knowledge Passport

---

# Identity

| Field | Value |
|-------|-------|
| Knowledge Passport ID | KP-PP-0169 |
| Population Package ID | PP-0169 |
| Clinical Knowledge Object | CKO-PP-0169 |
| Title | Gastric Adenomas and Cancer Risk |
| Clinical Domain | Risk & Prevention |
| Clinical Domain Code | RP |
| Population Batch | Risk & Prevention |
| Population Wave | Wave 1 |
| Version | 1.0.0 |
| Status | Approved |

---

# Knowledge Classification

| Field | Value |
|-------|-------|
| Knowledge Type | Foundational Medical Knowledge |
| Educational Category | Gastric Cancer Risk & Prevention |
| Educational Level | Introductory |
| Clinical Complexity | Basic–Intermediate |
| Intended Audience | General public, patients, caregivers |
| Reading Level | Plain Language |
| Knowledge Granularity | Atomic (Single Educational Question) |
| Knowledge Scope | Gastric Adenomas and Cancer Risk |

---

# Patient Journey Classification

| Stage | Applicable |
|---------|------------|
| Before Diagnosis | ✓ |
| During Diagnosis | ✓ |
| Treatment Decision | |
| Active Treatment | |
| Follow-up | ✓ |
| Survivorship | ✓ |
| Palliative Care | |

**Reason:**

Gastric adenomas are lesions associated with gastric-cancer risk. Patients may encounter this concept when a gastric polyp is identified during endoscopy or when discussing gastric-cancer risk and precursor conditions. The package provides foundational understanding without entering lesion-specific treatment or surveillance algorithms.

---

# Intended Runtime Usage

## Primary Runtime Role

- Foundational education on gastric adenomas and their relationship to gastric-cancer risk.

---

## Secondary Runtime Role

- Gastric cancer risk education
- Patient counseling
- Interpretation of a newly identified gastric polyp at a conceptual level
- Health literacy support
- Shared decision-making support
- Knowledge graph integration

---

## Typical Trigger Questions

- What is a gastric adenoma?
- Is a gastric adenoma cancer?
- Can a gastric adenoma turn into stomach cancer?
- Are all gastric adenomas equally dangerous?
- Why does the size of a gastric adenoma matter?
- Why does the pathology report mention the type of adenoma?
- What does dysplasia mean in a gastric polyp?
- Does a gastric adenoma mean I have a hereditary cancer syndrome?
- Why might a gastric adenoma need further evaluation?
- Is a gastric adenoma the same as intestinal metaplasia?

---

# Retrieval Priority

**High**

**Reason:**

Gastric adenomas are an important gastric-cancer risk/precursor concept and form a distinct clinical node between broader gastric mucosal risk conditions and subsequent high-risk screening, pathology, and lesion-management concepts.

---

# Knowledge Graph

## Prerequisite Population Packages

- PP-0002 — Benign vs Malignant Tumors
- PP-0005 — How Cancer Develops
- PP-0165 — Atrophic Gastritis and Gastric Cancer
- PP-0166 — Intestinal Metaplasia and Gastric Cancer

---

## Related Population Packages

| PP | Relationship |
|----|--------------|
| PP-0167 | Pernicious Anemia and Gastric Cancer |
| PP-0168 | EBV-associated Gastric Cancer + EBV Testing in Gastric Cancer |
| PP-0170 | Gastric Cancer Screening in High-Risk Individuals |
| PP-0171 | Endoscopic Screening for Gastric Cancer |
| PP-0178 | Histopathologic Classification |
| Endoscopy | Diagnostic context |
| Biopsy | Tissue evaluation context |
| Hereditary Gastric Cancer | Hereditary-risk context |
| Dysplasia / precursor-lesion management | Detailed pathology/management context |

---

## Recommended Downstream Package

**PP-0170 — Gastric Cancer Screening in High-Risk Individuals**

This package provides the next conceptual layer after understanding that gastric adenomas can be associated with increased gastric-cancer risk. It should remain separate from PP-0169 because screening eligibility and screening strategy are distinct clinical questions.

---

# Clinical Scope

## Core

- Definition of gastric adenoma
- Gastric adenoma as a gastric polyp
- Distinction between adenoma and gastric cancer
- Malignant potential
- Variation in malignant potential
- Histologic subtype as a risk determinant
- Size as a risk determinant
- Conceptual role of dysplasia
- Association with gastric-cancer risk
- Sporadic versus hereditary context
- Conceptual endoscopic/pathologic evaluation
- Patient-facing interpretation of risk

---

## Supporting

- Other gastric polyp types for contextual comparison
- Atrophic gastritis and intestinal metaplasia as adjacent gastric-risk conditions
- H. pylori as broader gastric-cancer-risk context
- FAP/GAPPS as hereditary context
- Screening/follow-up context at a high level
- Pathology context at a high level

---

## Explicitly Excluded

- Detailed gastric-polyp taxonomy
- Detailed histopathologic classification
- Microscopic pathology criteria
- Detailed dysplasia grading
- Dysplasia treatment
- Endoscopy technique
- Biopsy technique
- Gastric adenoma removal
- EMR
- ESD
- H. pylori testing/eradication
- Atrophic-gastritis management
- Intestinal-metaplasia classification/surveillance
- Hereditary genetic testing/counseling
- Gastric-cancer screening algorithms
- Screening intervals
- Individualized absolute-risk calculation
- Gastric-cancer treatment

---

# Authoritative Sources

## Primary Sources

1. National Cancer Institute (NCI), **Genetics of Gastric Cancer (PDQ®) — Health Professional Version**
2. National Cancer Institute (NCI), **Stomach (Gastric) Cancer Screening (PDQ®) — Health Professional Version**
3. National Cancer Institute (NCI), **Stomach (Gastric) Cancer Prevention (PDQ®) — Health Professional Version**
4. National Cancer Institute (NCI), **Gastric Cancer Treatment (PDQ®) — Health Professional Version**
5. National Comprehensive Cancer Network (NCCN), **Gastric Cancer, Version 2.2026**

---

## Supporting Sources

- American Cancer Society, **Stomach Cancer**
- American Cancer Society, patient-facing stomach cancer materials
- ESMO/ASCO Global Curriculum 2023, for general oncology education framework

---

# Evidence Classification

## Evidence Model

Authoritative Educational Synthesis

---

## Evidence Hierarchy

### Level I

- NCI PDQ
- NCCN Clinical Practice Guidelines

### Supporting

- American Cancer Society
- ESMO/ASCO Global Curriculum

---

# Governance Metadata

| Field | Value |
|-------|-------|
| Clinical Governance | Enabled |
| Evidence Traceability | Complete |
| Scope Boundary | Defined |
| Adjacent Package Overlap Check | Complete |
| Knowledge Graph | Complete |
| Runtime Ready | Yes |
| Repository Ready | Yes |

---

# Version Control

| Item | Value |
|-------|-------|
| Current Version | 1.0.0 |
| Major Version | 1 |
| Minor Version | 0 |
| Patch Version | 0 |

---

# Change History

| Version | Date | Description |
|----------|------|-------------|
| 1.0.0 | 2026-08-09 | Initial Gold Release Knowledge Passport |

---

# Final Status

**APPROVED**

This Knowledge Passport is the official governance metadata for **PP-0169 — Gastric Adenomas and Cancer Risk** and is compliant with the locked Gold Population Package Specification v1.0.
