# Primary Evidence Package

---

# Identity

| Field | Value |
|-------|-------|
| Evidence Package ID | EP-PP-0169 |
| Population Package ID | PP-0169 |
| Title | Gastric Adenomas and Cancer Risk |
| Clinical Domain | Risk & Prevention |
| Version | 1.0.0 |
| Status | Approved |

---

# Clinical Question

**Primary Educational Question**

> **What are gastric adenomas, and how are they associated with gastric cancer risk?**

---

# Educational Intent

Provide patients and caregivers with an accurate, evidence-based explanation of **gastric adenomas** as a distinct type of gastric polyp that can have malignant potential and is associated with increased gastric-cancer risk.

The package emphasizes that:

- a gastric adenoma is not the same as gastric cancer;
- malignant potential varies between lesions;
- histologic subtype and size are important determinants of malignant potential;
- dysplasia can add clinical significance;
- sporadic gastric adenomas are recognized as a gastric-cancer risk condition;
- gastric adenomas can also occur in hereditary polyposis settings;
- clinical evaluation may require endoscopic and pathology information.

The package intentionally stops before detailed pathology, dysplasia management, endoscopic treatment, hereditary genetic assessment, and screening algorithms.

---

# Scope

## Included

- Definition and conceptual identity of gastric adenoma
- Gastric adenoma within the spectrum of gastric polyps
- Malignant potential
- Histologic subtype
- Size
- Dysplasia as a risk-related pathology concept
- Gastric-cancer risk association
- Sporadic versus hereditary context
- Conceptual endoscopic/pathologic evaluation
- Patient-facing interpretation
- Common misconceptions
- Key messages

---

## Excluded

- Detailed gastric-polyp taxonomy
- Detailed microscopic histopathology
- Dysplasia grading and treatment
- Endoscopy or biopsy technique
- Gastric adenoma resection
- EMR/ESD
- H. pylori testing and eradication
- Atrophic-gastritis management
- Intestinal-metaplasia classification and surveillance
- Hereditary genetic testing/counseling
- Gastric-cancer screening algorithms
- Screening intervals
- Individualized absolute-risk calculation
- Gastric-cancer treatment

---

# Primary Evidence Sources

| Priority | Source | Purpose |
|-----------|--------|---------|
| 1 | NCI — Genetics of Gastric Cancer (PDQ®) | Direct evidence on gastric polyps, adenomas, malignant potential, histologic subtype, size, dysplasia, and hereditary context |
| 2 | NCI — Stomach (Gastric) Cancer Screening (PDQ®) | Evidence that gastric adenomatous polyps and sporadic gastric adenomas are associated with elevated gastric-cancer risk |
| 3 | NCI — Stomach (Gastric) Cancer Prevention (PDQ®) | Risk/precursor-condition framework including gastric adenomatous polyps |
| 4 | NCI — Gastric Cancer Treatment (PDQ®) | Supporting recognition of gastric adenomatous polyps as a gastric-cancer risk factor |
| 5 | NCCN — Gastric Cancer Version 2.2026 | Current gastric-cancer clinical framework and adjacent pathology/endoscopic context |

---

# Supporting Sources

| Source | Purpose |
|--------|---------|
| American Cancer Society — Stomach Cancer | Patient-facing explanation of gastric anatomy, precancerous changes, and stomach cancer |
| American Cancer Society — hereditary gastric-cancer risk materials | Patient-facing context for FAP and GAPPS |
| ESMO/ASCO Global Curriculum 2023 | General oncology education framework for prevention, diagnosis, pathology, and multidisciplinary care |

---

# Evidence Hierarchy

## Level I — Direct / authoritative

### NCI Genetics of Gastric Cancer

The supplied NCI PDQ states that gastric adenomas make up approximately **10% of gastric polyps** and that their malignant potential is determined by **histologic subtype and size**. It identifies pyloric gland adenomas and intestinal-type gastric adenomas as having the highest malignant potentials among the subtypes discussed, while foveolar-type adenomas have the lowest malignant potential.

The same source states that gastric polyps may be sporadic or associated with hereditary cancer syndromes and that, in general, malignant potential of a gastric polyp is influenced by histology, size, and degree of dysplasia when present.

### NCI Screening and Prevention PDQs

The supplied NCI screening and prevention materials identify **gastric adenomatous polyps** as a gastric-cancer risk/precursor condition and identify patients with **sporadic gastric adenomas** among populations at elevated gastric-cancer risk.

### NCCN Gastric Cancer

The supplied NCCN Gastric Cancer Version 2.2026 is used primarily as a current clinical framework for gastric cancer, endoscopic/pathologic evaluation, and separation of early-lesion evaluation from downstream treatment.

---

# Evidence Matrix

| Clinical Claim | Primary Supporting Source | Evidence Interpretation |
|----------------|---------------------------|--------------------------|
| Gastric adenomas are a type of gastric polyp. | NCI Genetics of Gastric Cancer | Established |
| Gastric adenomas account for approximately 10% of gastric polyps. | NCI Genetics of Gastric Cancer | Established in the supplied source |
| Gastric adenomas can have malignant potential. | NCI Genetics of Gastric Cancer | Established |
| Malignant potential varies by histologic subtype. | NCI Genetics of Gastric Cancer | Established |
| Pyloric gland and intestinal-type adenomas have higher malignant potential than foveolar-type adenomas in the cited NCI discussion. | NCI Genetics of Gastric Cancer | Established |
| Size contributes to malignant potential. | NCI Genetics of Gastric Cancer | Established |
| Degree of dysplasia can influence the malignant potential of gastric polyps when dysplasia is present. | NCI Genetics of Gastric Cancer | Established |
| Gastric adenomatous polyps are associated with increased gastric-cancer risk. | NCI Screening + Prevention PDQ | Established |
| Sporadic gastric adenomas are recognized among elevated-risk groups for gastric cancer. | NCI Screening PDQ | Established |
| Gastric polyps may be sporadic or associated with hereditary cancer syndromes. | NCI Genetics of Gastric Cancer | Established |
| FAP/GAPPS can include gastric polyps/adenomas and increased gastric-cancer risk. | NCI Genetics + ACS | Established hereditary context |
| Endoscopy and pathology information are relevant to characterization of gastric lesions. | NCI + NCCN | Clinical-context claim |
| A gastric adenoma does not mean that cancer is inevitable. | Evidence synthesis from risk/potential language | Interpretation consistent with source evidence; avoids overclaim |

---

# Evidence Notes

## 1. Risk is not synonymous with certainty

The source materials support describing gastric adenomas as lesions with malignant potential and as a gastric-cancer risk condition. They do **not** support a statement that every gastric adenoma progresses to cancer.

Therefore patient-facing language uses:

- “may”
- “can”
- “malignant potential”
- “increased risk”

rather than:

- “will”
- “always”
- “inevitably.”

---

## 2. Histology and size are central risk modifiers

The NCI source explicitly states that malignant potential is determined by histologic subtype and size.

This supports inclusion of these concepts in the CKO while avoiding unsupported numeric thresholds or treatment cutoffs.

---

## 3. Dysplasia is included only as a conceptual modifier

The NCI source states that, in general, gastric-polyp malignant potential is influenced by degree of dysplasia when dysplasia is present.

The package therefore explains why dysplasia matters but does not define detailed dysplasia grading or management.

---

## 4. Hereditary context is supporting, not core

The NCI source distinguishes sporadic gastric polyps from polyps occurring in hereditary cancer/polyposis syndromes.

FAP and GAPPS are included only to establish that gastric adenomas/polyps can occur in hereditary settings.

Detailed hereditary risk assessment remains outside PP-0169.

---

## 5. Adjacent gastric precursor conditions are not interchangeable

Atrophic gastritis, intestinal metaplasia, dysplasia, and gastric adenoma are distinct clinical/pathologic concepts.

PP-0169 uses these only to establish conceptual boundaries and avoids duplicating their dedicated packages.

---

# Clinical Claims Summary

The evidence consistently supports the following educational messages:

- Gastric adenoma is a distinct type of gastric polyp.
- Gastric adenomas can have malignant potential.
- The malignant potential of a gastric adenoma varies according to histologic subtype and size.
- Pyloric gland and intestinal-type adenomas have higher malignant potential than foveolar-type adenomas in the NCI discussion.
- Dysplasia, when present, can increase the clinical significance of a gastric polyp.
- Gastric adenomatous polyps are recognized as a gastric-cancer risk/precursor condition.
- Sporadic gastric adenomas are recognized among elevated-risk groups.
- Gastric polyps can also occur in hereditary polyposis syndromes.
- A gastric adenoma is not the same as established gastric cancer.
- A gastric adenoma does not make gastric cancer inevitable.
- Endoscopic and pathology information may be needed to characterize a gastric lesion.

---

# Evidence Consistency Review

## Overall Consistency

No clinically meaningful disagreement was identified among the supplied authoritative sources regarding the central PP-0169 claims.

The strongest direct evidence comes from the NCI Genetics of Gastric Cancer PDQ, which specifically addresses gastric polyps and adenomas.

The NCI Screening and Prevention PDQs independently reinforce the association between gastric adenomatous polyps/sporadic gastric adenomas and gastric-cancer risk.

The ACS materials provide compatible patient-facing context, while NCCN provides the broader current gastric-cancer clinical framework.

---

## Source Roles

### NCI

**Primary evidence authority** for adenoma-specific risk characterization.

### NCCN

**Current clinical framework** for adjacent gastric lesion evaluation and overall gastric-cancer care architecture.

### ACS

**Patient education support** and plain-language contextualization.

### ESMO/ASCO

**General oncology education framework**, not the principal evidence source for adenoma-specific claims.

---

# Evidence Gaps

The supplied materials do not provide sufficient basis for this package to make:

- universal numerical cancer-risk estimates for an individual adenoma;
- universal size-based treatment thresholds;
- universal surveillance intervals;
- individualized risk prediction;
- detailed adenoma-treatment recommendations;
- detailed dysplasia-management recommendations;
- universal hereditary genetic-testing criteria based solely on a gastric adenoma.

These gaps are intentionally preserved rather than filled with unsupported general knowledge.

---

# Future Update Triggers

Review this package when:

- NCI substantially revises its gastric adenoma/gastric polyp risk statements.
- NCCN introduces or materially changes gastric adenoma/precursor-lesion guidance relevant to patient education.
- Major authoritative pathology classifications materially change the interpretation of gastric adenoma subtypes.
- Major evidence changes the estimated malignant potential of specific gastric adenoma subtypes.
- New authoritative guidance changes the clinical relationship between gastric adenomas, dysplasia, and gastric-cancer screening.
- Governance creates dedicated Population Packages that supersede or refine current delegated boundaries.

---

# Source Traceability

| Source | Relevant Content | Package Use |
|--------|------------------|-------------|
| NCI — Genetics of Gastric Cancer (PDQ®), pp. 4–6 | Gastric polyps, adenomas, malignant potential, subtype, size, dysplasia, sporadic/hereditary context | Core evidence |
| NCI — Genetics of Gastric Cancer (PDQ®), pp. 19–20 | Hereditary syndromes and high-risk gastric lesions | Supporting hereditary context |
| NCI — Stomach (Gastric) Cancer Screening (PDQ®), pp. 3–4 | Sporadic gastric adenomas and gastric adenomatous polyps as elevated-risk/precursor conditions | Core risk-context evidence |
| NCI — Stomach (Gastric) Cancer Prevention (PDQ®), p. 1 | Gastric adenomatous polyps as precursor/risk condition | Supporting risk evidence |
| NCI — Gastric Cancer Treatment (PDQ®), p. 2 | Gastric adenomatous polyps listed among gastric-cancer risk factors | Supporting consistency evidence |
| ACS — Stomach Cancer, pp. 5–7 | Gastric mucosa and general precancerous-change context | Patient education support |
| ACS — Stomach Cancer, pp. 25–26 | FAP/GAPPS and hereditary gastric-cancer context | Supporting hereditary context |
| NCCN Gastric Cancer Version 2.2026 | Current gastric-cancer workup/pathology/endoscopic framework | Clinical framework |

---

# Boundary Verification

## Core

- Gastric adenoma definition and identity
- Malignant potential
- Variation in malignant potential
- Histologic subtype
- Size
- Conceptual role of dysplasia
- Association with gastric-cancer risk
- Sporadic versus hereditary context at a high level
- Conceptual endoscopic/pathologic evaluation
- Patient-facing interpretation of risk

## Supporting

- Other gastric polyps for contextual comparison
- Atrophic gastritis and intestinal metaplasia as adjacent risk conditions
- H. pylori as broader gastric-cancer-risk context
- FAP/GAPPS as hereditary context
- High-level screening/follow-up context
- High-level pathology context

## Explicitly Excluded

- Detailed histopathology
- Detailed dysplasia grading/management
- Endoscopic/biopsy technique
- Adenoma removal
- EMR/ESD
- H. pylori testing/eradication
- Atrophic gastritis management
- Intestinal metaplasia surveillance
- Hereditary genetic testing/counseling
- Screening algorithms and intervals
- Individualized risk calculation
- Gastric-cancer treatment

## Delegated-to PP

- PP-0165 — Atrophic Gastritis and Gastric Cancer
- PP-0166 — Intestinal Metaplasia and Gastric Cancer
- PP-0167 — Pernicious Anemia and Gastric Cancer
- PP-0170 — Gastric Cancer Screening in High-Risk Individuals
- PP-0171 — Endoscopic Screening for Gastric Cancer
- PP-0178 — Histopathologic Classification
- Endoscopy / Biopsy
- Dysplasia / precursor-lesion management
- Hereditary Gastric Cancer
- Gastric Cancer Treatment

---

# Evidence Package Decision

**APPROVED**

The evidence package supports the approved PP-0169 scope with complete traceability to the supplied authoritative source set.

---

# Final Evidence Status

**PASS — Evidence traceability complete.**

Repository Status: **Ready**.
