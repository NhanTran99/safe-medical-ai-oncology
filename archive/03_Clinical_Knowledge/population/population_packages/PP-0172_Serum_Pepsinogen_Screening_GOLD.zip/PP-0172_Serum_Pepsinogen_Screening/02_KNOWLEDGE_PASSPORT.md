# Knowledge Passport

## Identity

| Field | Value |
|---|---|
| Knowledge Passport ID | KP-PP-0172 |
| Population Package ID | PP-0172 |
| Clinical Knowledge Object | CKO-PP-0172 |
| Title | Serum Pepsinogen Screening |
| Version | 1.0.0 |
| Status | Approved |

## Knowledge Classification

| Field | Value |
|---|---|
| Clinical Domain | Risk & Prevention |
| Clinical Domain Code | RP |
| Educational Category | Gastric Cancer Screening |
| Educational Level | Introductory |
| Clinical Complexity | Intermediate |
| Patient Journey Stage | Before Diagnosis |
| Knowledge Granularity | Atomic |
| Intended Audience | General public, patients for whom screening is being considered, caregivers |

## Intended Runtime Usage

### Primary Runtime Role

Explain serum pepsinogen as a blood-based gastric-cancer screening/risk-stratification biomarker.

### Secondary Runtime Roles

- Explain PGI, PGII, and PGI:PGII ratio.
- Explain why low pepsinogen suggests gastric atrophy.
- Explain the relationship with gastric-cancer risk.
- Explain study-specific screening performance without turning it into a universal cutoff.
- Explain H. pylori and PPI effects on interpretation.
- Explain why an abnormal result is not a cancer diagnosis.
- Explain why a normal result does not guarantee absence of cancer.
- Connect abnormal screening results to possible downstream evaluation.

## Retrieval / Runtime Relevance

**Very High**

Reason: PP-0172 is the dedicated serum-biomarker screening layer immediately following high-risk screening consideration and parallel to endoscopic screening.

## Clinical Scope

### Core

- Serum pepsinogen as a screening/risk-stratification biomarker
- PGI, PGII, and PGI:PGII ratio at conceptual level
- Low pepsinogen and gastric atrophy
- Gastric-cancer risk relationship
- Intestinal-type versus diffuse-type relevance
- Study-specific cutoffs/performance
- Lack of universal cutoffs
- H. pylori and PPI effects
- Positive/negative result interpretation
- Lack of demonstrated mortality benefit
- Downstream evaluation concept

### Supporting

- Atrophic gastritis context
- Intestinal metaplasia context
- H. pylori context
- Endoscopy as a possible downstream evaluation
- High-incidence Asian evidence context

### Explicitly Excluded

- Detailed atrophic-gastritis disease management
- Detailed intestinal-metaplasia classification/surveillance
- H. pylori testing/eradication
- PPI management
- Endoscopic screening technique
- High-incidence population screening programs
- Detailed screening harms/false-result analysis
- Universal pepsinogen algorithms
- Universal cutoffs
- Universal age thresholds
- Universal screening intervals
- Individualized endoscopy referral rules
- Laboratory assay methodology
- Gastric-cancer diagnosis/treatment

### Delegated-to PP

- PP-0160 — H. pylori and Gastric Cancer Prevention
- PP-0161 — H. pylori Eradication for Gastric Cancer Prevention
- PP-0165 — Atrophic Gastritis and Gastric Cancer
- PP-0166 — Intestinal Metaplasia and Gastric Cancer
- PP-0167 — Pernicious Anemia and Gastric Cancer
- PP-0170 — Gastric Cancer Screening in High-Risk Individuals
- PP-0171 — Endoscopic Screening for Gastric Cancer
- PP-0173 — Screening in High-Incidence Populations
- PP-0174 — Screening Harms and False Results
- PP-0175 — Gastric Cancer Diagnostic Work-up
- PP-0176 — Endoscopic Diagnosis of Gastric Cancer
- PP-0177 — Endoscopic Biopsy Strategy
- PP-0178+ — Histopathology
- Gastric-cancer treatment packages

## Authoritative Sources

1. NCI — Stomach (Gastric) Cancer Screening PDQ
2. NCI — Stomach (Gastric) Cancer Prevention PDQ
3. NCI — Genetics of Gastric Cancer PDQ
4. NCCN Clinical Practice Guidelines in Oncology — Gastric Cancer, Version 2.2026
5. American Cancer Society — Stomach Cancer
6. Approved adjacent Population Packages and PP Registry

## Evidence Classification

### Level I — Direct

- NCI Stomach (Gastric) Cancer Screening PDQ

### Supporting

- NCI Stomach (Gastric) Cancer Prevention PDQ
- NCI Genetics of Gastric Cancer PDQ
- NCCN Gastric Cancer v2.2026
- ACS Stomach Cancer
- Approved adjacent PP artifacts

## Governance Metadata

| Field | Value |
|---|---|
| Clinical Governance | Enabled |
| Evidence Traceability | Complete |
| Scope Boundary | Defined |
| Adjacent PP Boundary Review | Complete |
| Knowledge Graph | Complete |
| Runtime Ready | Yes |
| Repository Ready | Yes |

## Version Control

| Item | Value |
|---|---|
| Current Version | 1.0.0 |
| Major | 1 |
| Minor | 0 |
| Patch | 0 |

## Change History

| Version | Date | Description |
|---|---|---|
| 1.0.0 | 2026-08-09 | Initial Gold Release |

## Final Status

**APPROVED**
