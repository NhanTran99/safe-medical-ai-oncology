# Clinical Knowledge Object (CKO)

## Metadata

| Field | Value |
|---|---|
| CKO ID | CKO-PP-0172 |
| PP ID | PP-0172 |
| Title | Serum Pepsinogen Screening |
| Clinical Domain | Risk & Prevention |
| Population Wave | Wave 1 |
| Version | 1.0.0 |
| Audience | General public, patients for whom gastric-cancer screening is being considered, caregivers |
| Reading Level | Plain language |
| Status | Gold / Approved |
| Last Updated | 2026-08-09 |

## Educational Objectives

After reading this Population Package, the reader should be able to:

- Understand what serum pepsinogen is and why it has been studied for gastric-cancer screening.
- Understand the roles of pepsinogen I (PGI), pepsinogen II (PGII), and the PGI:PGII ratio at a conceptual level.
- Understand why low serum pepsinogen can indicate gastric atrophy.
- Understand why this makes pepsinogen relevant to gastric-cancer risk, particularly for presumed precursors of intestinal-type gastric cancer.
- Understand that serum pepsinogen is a screening/risk-stratification biomarker, not a direct diagnosis of gastric cancer.
- Understand why there is no universal pepsinogen cutoff.
- Understand that H. pylori eradication and proton-pump inhibitor use can change pepsinogen levels.
- Understand the limitations of available screening evidence, including the absence of demonstrated gastric-cancer mortality benefit.
- Understand what an abnormal result may lead to and why further clinical assessment may be needed.

# Scope

## Included

- Serum pepsinogen as a gastric-cancer screening/risk-stratification biomarker
- PGI and PGII at conceptual level
- PGI:PGII ratio at conceptual level
- Low pepsinogen and gastric atrophy
- Relationship between gastric atrophy and gastric-cancer risk
- Relevance to presumed precursors of intestinal-type gastric cancer
- Study-specific screening cutoffs and performance as an evidence example
- Lack of universal standard cutoffs
- Effects of H. pylori eradication on interpretation
- Effects of proton-pump inhibitor use on interpretation
- Positive and negative result concepts
- Lack of demonstrated mortality benefit
- High-level relationship with subsequent endoscopic or diagnostic evaluation
- Patient-facing limitations and misconceptions

## Not Included

- Detailed gastric physiology
- Detailed atrophic-gastritis pathogenesis or management
- H. pylori diagnosis or eradication treatment
- PPI management or medication-discontinuation instructions
- Detailed intestinal-metaplasia classification or surveillance
- Endoscopic screening technique
- Endoscopic biopsy strategy
- High-incidence population screening programs
- Detailed screening harms and false-result analysis
- Universal pepsinogen algorithms, age thresholds, or screening intervals
- Individualized endoscopy referral rules
- Laboratory assay methodology
- Gastric-cancer diagnosis or treatment

# Clinical Knowledge Blocks

## Knowledge Block 1 — What Is Serum Pepsinogen?

### Patient Explanation

Pepsinogen is a substance produced in the stomach. Small amounts enter the bloodstream, where they can be measured with a blood test.

Serum pepsinogen testing has been studied as a way to identify changes in the stomach lining that are associated with increased gastric-cancer risk.

### Clinical Importance

The test is best understood as a marker of gastric mucosal status and risk, not as a direct blood test for gastric cancer.

### Key Concepts

- Serum pepsinogen
- Blood test
- Gastric mucosa
- Risk marker

## Knowledge Block 2 — What Are PGI and PGII?

### Patient Explanation

Some screening studies measure two forms of pepsinogen called pepsinogen I (PGI) and pepsinogen II (PGII).

The relationship between these measurements, including the PGI:PGII ratio, has been studied as part of gastric-cancer risk screening.

### Clinical Importance

PGI, PGII, and their ratio are screening measurements rather than cancer diagnoses.

### Key Concepts

- PGI
- PGII
- PGI:PGII ratio

## Knowledge Block 3 — What Does a Low Pepsinogen Level Suggest?

### Patient Explanation

Low serum pepsinogen levels can indicate atrophic gastritis, a condition in which the stomach lining becomes thinner and loses some of its normal glands.

Because gastric atrophy is associated with increased gastric-cancer risk, low pepsinogen can identify a risk-associated gastric state.

### Clinical Importance

This is the biological bridge between the blood test and gastric-cancer risk.

### Key Concepts

- Low pepsinogen
- Gastric atrophy
- Atrophic gastritis
- Risk state

## Knowledge Block 4 — How Is Pepsinogen Related to Gastric-Cancer Risk?

### Patient Explanation

Serum pepsinogen does not directly show that cancer is present.

Instead, low levels can indicate gastric atrophy, which is associated with a higher risk of gastric cancer. This makes pepsinogen useful as a screening or risk-stratification marker in selected settings.

### Clinical Importance

The distinction between risk marker and diagnostic test is essential.

### Key Concepts

- Risk stratification
- Gastric atrophy
- Gastric-cancer risk
- Screening

## Knowledge Block 5 — Is Pepsinogen More Relevant to Some Types of Gastric Cancer?

### Patient Explanation

The biological rationale for serum pepsinogen is more closely related to presumed precursors of intestinal-type gastric cancer than to diffuse-type gastric cancer.

This means pepsinogen should not be described as a blood test that detects every form of gastric cancer equally.

### Clinical Importance

This is an important limitation of the biomarker.

### Key Concepts

- Intestinal-type gastric cancer
- Diffuse-type gastric cancer
- Precursor state
- Biomarker limitation

## Knowledge Block 6 — How Have PGI and the PGI:PGII Ratio Been Used in Studies?

### Patient Explanation

Researchers have studied combinations of PGI and the PGI:PGII ratio to identify people considered to be at increased risk.

One Japanese study used PGI below 70 ng/mL together with a PGI:PGII ratio below 3 as its study-specific screening criteria.

These values should not be treated as universal medical cutoffs.

### Clinical Importance

The study illustrates how pepsinogen has been evaluated, but it does not establish one cutoff for every population or laboratory.

### Key Concepts

- Study-specific cutoff
- PGI
- PGI:PGII ratio
- Screening study

## Knowledge Block 7 — What Did One Japanese Study Find?

### Patient Explanation

In one Japanese study of 5,113 people who were also screened by endoscopy, the study-specific pepsinogen criteria had a sensitivity of 84.6% and specificity of 73.5%. The positive predictive value was 0.81%, while the negative predictive value was 99.6%.

These numbers describe that particular study and should not be interpreted as universal performance values.

### Clinical Importance

This illustrates why screening-test performance depends on the population, thresholds, and clinical setting.

### Key Concepts

- Sensitivity
- Specificity
- Positive predictive value
- Negative predictive value

## Knowledge Block 8 — Is There a Universal Pepsinogen Cutoff?

### Patient Explanation

No universal cutoff has been established.

Different studies and populations may use different thresholds. The NCI evidence also notes that H. pylori eradication and proton-pump inhibitor use can change pepsinogen levels, making interpretation more difficult.

### Clinical Importance

A single number should not be presented as a universal rule for deciding who has gastric cancer or who must undergo endoscopy.

### Key Concepts

- No standard cutoff
- Interpretation
- Population differences
- Clinical context

## Knowledge Block 9 — Can H. pylori Treatment Change Pepsinogen Results?

### Patient Explanation

Yes.

Eradication of H. pylori can change serum pepsinogen levels. This can make a result more difficult to interpret if the person's H. pylori history is not considered.

### Clinical Importance

The test should be interpreted in clinical context rather than as an isolated number.

### Key Concepts

- H. pylori
- Eradication
- Pepsinogen interpretation

## Knowledge Block 10 — Can Proton-Pump Inhibitors Change Pepsinogen Results?

### Patient Explanation

Yes.

Proton-pump inhibitors (PPIs), medicines commonly used for acid-related digestive symptoms, can change pepsinogen levels.

This is another reason why a pepsinogen result should not be interpreted using a simple universal rule.

### Clinical Importance

Medication context can affect biomarker interpretation.

### Key Concepts

- Proton-pump inhibitor
- PPI
- Interpretation

## Knowledge Block 11 — What Does a Positive Pepsinogen Screening Result Mean?

### Patient Explanation

An abnormal pepsinogen result does not mean that a person has gastric cancer.

It suggests that the stomach may have changes associated with increased risk and that further assessment may be appropriate depending on the clinical setting.

### Clinical Importance

The result is a risk signal, not a tissue diagnosis.

### Key Concepts

- Abnormal result
- Risk signal
- Further evaluation

## Knowledge Block 12 — What Does a Negative Pepsinogen Result Mean?

### Patient Explanation

A negative result does not provide an absolute guarantee that gastric cancer is absent.

Pepsinogen is not a perfect cancer-detection test, and its biological usefulness is more closely related to gastric atrophy and presumed intestinal-type cancer precursors.

### Clinical Importance

Avoids false reassurance.

### Key Concepts

- Negative result
- Residual risk
- False-negative possibility

## Knowledge Block 13 — Does Serum Pepsinogen Screening Reduce Gastric-Cancer Mortality?

### Patient Explanation

This has not been established.

The NCI reports that there are no studies evaluating the effect of serum-pepsinogen screening on gastric-cancer mortality.

### Clinical Importance

The test can be discussed as a screening/risk-stratification approach without claiming proven survival benefit.

### Key Concepts

- Mortality
- Evidence limitation
- Screening benefit

## Knowledge Block 14 — Is Serum Pepsinogen a Replacement for Endoscopy?

### Patient Explanation

Not universally.

Serum pepsinogen is a blood-based risk/screening marker, while endoscopy directly examines the stomach. An abnormal pepsinogen result may lead to further assessment, potentially including endoscopy, depending on the screening setting.

### Clinical Importance

The two approaches answer different clinical questions and should not be treated as interchangeable in every situation.

### Key Concepts

- Blood-based screening
- Endoscopy
- Further evaluation

## Knowledge Block 15 — What Happens After an Abnormal Pepsinogen Result?

### Patient Explanation

The next step depends on the person's overall risk, the screening protocol, the laboratory result, and other clinical information.

Further evaluation may include endoscopic assessment or other appropriate investigation.

There is no single universal pathway that applies to every person with an abnormal pepsinogen result.

### Clinical Importance

This prevents the package from creating an unsupported universal referral algorithm.

### Key Concepts

- Follow-up
- Risk assessment
- Endoscopic evaluation
- Clinical context

## Knowledge Block 16 — What Are the Main Limitations of Serum Pepsinogen Screening?

### Patient Explanation

Important limitations include:

- no universal standard cutoff;
- results can be affected by H. pylori eradication and PPI use;
- the test is more closely related to gastric atrophy and presumed intestinal-type cancer precursors than diffuse-type disease;
- screening performance varies by population and threshold;
- mortality benefit has not been demonstrated.

### Clinical Importance

These limitations are part of the clinical meaning of the test and should be understood before interpreting a result.

### Key Concepts

- No standard cutoff
- Context-dependent interpretation
- Biological limitation
- Evidence uncertainty

# Common Misconceptions

### Myth 1

**“Low pepsinogen means I have gastric cancer.”**

**Fact:** Low pepsinogen can indicate gastric atrophy, which is associated with increased gastric-cancer risk. It does not diagnose cancer.

### Myth 2

**“PGI below 70 ng/mL means cancer.”**

**Fact:** That threshold was used in one Japanese study. It is not a universal diagnostic cutoff.

### Myth 3

**“A normal pepsinogen result completely rules out gastric cancer.”**

**Fact:** Serum pepsinogen is not a perfect cancer-detection test.

### Myth 4

**“Serum pepsinogen is a substitute for biopsy.”**

**Fact:** It is a blood-based screening/risk marker and does not provide tissue diagnosis.

### Myth 5

**“H. pylori treatment cannot affect pepsinogen.”**

**Fact:** H. pylori eradication can change pepsinogen levels and complicate interpretation.

### Myth 6

**“PPIs do not affect pepsinogen.”**

**Fact:** PPI use can change pepsinogen levels.

### Myth 7

**“Serum pepsinogen screening has been proven to save lives.”**

**Fact:** The NCI reports no studies evaluating its effect on gastric-cancer mortality.

### Myth 8

**“Pepsinogen detects every type of gastric cancer equally.”**

**Fact:** Its biological rationale is more closely related to atrophic changes and presumed precursors of intestinal-type gastric cancer than diffuse-type disease.

# Key Messages

- Serum pepsinogen is a blood-based screening/risk-stratification marker, not a direct diagnosis of gastric cancer.
- PGI, PGII, and the PGI:PGII ratio have been studied in gastric-cancer screening.
- Low pepsinogen can indicate gastric atrophy.
- Gastric atrophy is associated with increased gastric-cancer risk.
- The test is more closely related to presumed precursors of intestinal-type gastric cancer than diffuse-type disease.
- Study-specific cutoffs exist, but there is no universal standard cutoff.
- H. pylori eradication and PPI use can change pepsinogen levels.
- Screening performance varies with population and threshold.
- No mortality benefit from serum-pepsinogen screening has been demonstrated.
- An abnormal result may lead to further assessment, but there is no universal referral algorithm.

# Knowledge Graph

## Prerequisite PPs

- PP-0170 — Gastric Cancer Screening in High-Risk Individuals
- PP-0165 — Atrophic Gastritis and Gastric Cancer
- PP-0166 — Intestinal Metaplasia and Gastric Cancer

## Related PPs

- PP-0160 — H. pylori and Gastric Cancer Prevention
- PP-0161 — H. pylori Eradication for Gastric Cancer Prevention
- PP-0167 — Pernicious Anemia and Gastric Cancer
- PP-0171 — Endoscopic Screening for Gastric Cancer
- PP-0173 — Screening in High-Incidence Populations
- PP-0174 — Screening Harms and False Results

## Next / Downstream

- PP-0173 — Screening in High-Incidence Populations
- PP-0174 — Screening Harms and False Results
- PP-0175 — Gastric Cancer Diagnostic Work-up
- PP-0171 — Endoscopic Screening for Gastric Cancer, when endoscopic follow-up is the relevant screening modality

# Revision History

| Version | Date | Summary |
|---|---|---|
| 1.0.0 | 2026-08-09 | Initial Gold Release |
