# Primary Evidence Package

## Identity

| Field | Value |
|---|---|
| Evidence Package ID | EP-PP-0172 |
| Population Package ID | PP-0172 |
| Title | Serum Pepsinogen Screening |
| Clinical Domain | Risk & Prevention |
| Version | 1.0.0 |
| Status | Approved |

## Clinical Question

> **What is serum pepsinogen screening, what can it tell us about gastric-cancer risk, and what are its limitations?**

## Educational Intent

Explain serum pepsinogen as a blood-based screening/risk-stratification biomarker, including PGI/PGII and their ratio at an appropriate conceptual level, the relationship between low pepsinogen and gastric atrophy, study-specific screening performance, the absence of universal cutoffs, effects of H. pylori eradication and PPI use, the absence of demonstrated mortality benefit, and the transition to further clinical evaluation.

# Scope

## Included

- Serum pepsinogen screening
- PGI and PGII
- PGI:PGII ratio
- Low pepsinogen and gastric atrophy
- Gastric-cancer risk
- Intestinal-type versus diffuse-type relevance
- Study-specific cutoffs and performance
- Interpretation limitations
- H. pylori and PPI effects
- Positive/negative result concepts
- Mortality evidence
- Possible downstream evaluation

## Excluded

- Detailed atrophic-gastritis management
- Detailed intestinal-metaplasia classification
- H. pylori diagnosis/eradication
- PPI management
- Endoscopic technique
- High-incidence population screening programs
- Detailed harms/false-result analysis
- Universal screening algorithm
- Universal cutoffs, age thresholds, or intervals
- Individualized endoscopy referral
- Laboratory assay methodology
- Gastric-cancer diagnosis/treatment

# Primary Evidence Sources

| Priority | Source | Purpose |
|---|---|---|
| 1 | NCI — Stomach (Gastric) Cancer Screening PDQ | Direct evidence for serum pepsinogen, cutoffs, performance, limitations, and mortality evidence |
| 2 | NCI — Stomach (Gastric) Cancer Prevention PDQ | Gastric-risk and precursor context |
| 3 | NCI — Genetics of Gastric Cancer PDQ | Population/high-risk context |
| 4 | NCCN Gastric Cancer Version 2.2026 | Current clinical gastric-cancer framework |
| 5 | American Cancer Society — Stomach Cancer | Patient-facing risk/screening context |

# Supporting Sources

- NCI HDGC PDQ
- ESMO/ASCO Global Curriculum 2023
- Approved adjacent PP artifacts
- PP Registry

# Evidence Hierarchy

## Level I — Direct Screening Evidence

### NCI Stomach (Gastric) Cancer Screening PDQ

This is the principal source for PP-0172.

NCI states that serum pepsinogen has been proposed as a screening method, but there are no studies evaluating its effect on gastric-cancer mortality.

NCI also states:

- low serum pepsinogen indicates atrophic gastritis;
- it is therefore more applicable to presumed precursors of intestinal-type gastric cancer than diffuse-type disease;
- there are no standard cutoff values;
- H. pylori eradication and PPI use can alter pepsinogen levels and complicate interpretation.

NCI cites a Japanese study of 5,113 patients who were also screened by endoscopy. The study used PGI <70 ng/mL and PGI:PGII ratio <3 and reported sensitivity 84.6%, specificity 73.5%, PPV 0.81%, and NPV 99.6%.

These values are study-specific and must not be converted into universal clinical thresholds.

# Evidence Matrix

| Clinical Claim | Supporting Evidence |
|---|---|
| Serum pepsinogen has been proposed as a gastric-cancer screening method. | NCI Screening PDQ |
| Low serum pepsinogen indicates gastric atrophy. | NCI Screening PDQ |
| Pepsinogen is more applicable to presumed precursors of intestinal-type than diffuse-type gastric cancer. | NCI Screening PDQ |
| There are no standard abnormal pepsinogen cutoffs. | NCI Screening PDQ |
| H. pylori eradication can change pepsinogen levels. | NCI Screening PDQ |
| PPI use can change pepsinogen levels. | NCI Screening PDQ |
| One Japanese study used PGI <70 ng/mL and PGI:PGII ratio <3. | NCI Screening PDQ |
| That study reported sensitivity 84.6% and specificity 73.5%. | NCI Screening PDQ |
| That study reported PPV 0.81% and NPV 99.6%. | NCI Screening PDQ |
| No studies have evaluated the effect of serum-pepsinogen screening on gastric-cancer mortality. | NCI Screening PDQ |
| An abnormal serum result should not be treated as a cancer diagnosis. | Evidence interpretation and project architecture |
| A universal endoscopy referral rule is not established by the supplied evidence. | NCI Screening PDQ + project governance |

# Evidence Notes

## 1. Biological Meaning

The clinically important chain is:

**Serum pepsinogen**

→ **low level**

→ **suggests gastric atrophy**

→ **gastric atrophy associated with gastric-cancer risk**

→ **screening/risk stratification**

This is a risk-marker pathway, not a direct cancer-detection pathway.

## 2. Intestinal-Type Versus Diffuse-Type Disease

NCI specifically states that low pepsinogen is applicable to presumed precursors of intestinal-type gastric cancer rather than diffuse-type gastric cancer.

This limitation should remain visible in the patient-facing package.

## 3. Study-Specific Screening Thresholds

The NCI-cited Japanese study used:

- PGI <70 ng/mL
- PGI:PGII ratio <3

The reported performance was:

- sensitivity 84.6%;
- specificity 73.5%;
- PPV 0.81%;
- NPV 99.6%.

These are not universal values.

## 4. No Standard Cutoff

NCI explicitly states that there are no standard cutoff values of abnormality.

Therefore PP-0172 must not create a universal decision algorithm.

## 5. H. pylori and PPI Effects

NCI states that H. pylori eradication and PPI use change pepsinogen levels and make interpretation difficult.

The package therefore requires clinical-context interpretation.

## 6. Mortality Evidence

NCI reports no studies evaluating whether serum-pepsinogen screening changes gastric-cancer mortality.

This is a major evidence limitation and must not be omitted.

## 7. Relationship With Endoscopy

Serum pepsinogen and endoscopy are different screening approaches.

An abnormal pepsinogen result may lead to further evaluation, potentially including endoscopy, depending on the screening protocol and clinical setting.

PP-0171 owns endoscopic screening.

# Clinical Claims Summary

The evidence supports these messages:

- Serum pepsinogen is a blood-based screening/risk-stratification approach.
- It can provide information about gastric mucosal atrophy and associated cancer risk.
- It does not directly diagnose gastric cancer.
- PGI, PGII, and their ratio have been used in screening studies.
- Study-specific cutoffs can demonstrate useful screening performance, but no universal cutoff exists.
- H. pylori eradication and PPI use can affect interpretation.
- The biological rationale is stronger for presumed precursors of intestinal-type gastric cancer than diffuse-type disease.
- Mortality benefit has not been demonstrated.
- An abnormal result requires clinical context and may lead to further evaluation.

# Evidence Consistency Review

The supplied evidence is internally consistent:

1. Serum pepsinogen is a proposed screening method.
2. Its biological signal is linked to gastric atrophy.
3. Atrophy is associated with gastric-cancer risk.
4. The test is not a direct cancer diagnosis.
5. Cutoffs vary and no universal standard exists.
6. H. pylori eradication and PPIs affect interpretation.
7. Evidence does not demonstrate a mortality benefit.

No contradiction affecting the approved PP-0172 scope was identified.

# Evidence Gaps

The supplied materials do not establish:

- a universal PGI cutoff;
- a universal PGI:PGII ratio;
- a universal age threshold;
- a universal screening interval;
- a universal abnormal-result-to-endoscopy pathway;
- mortality reduction from serum-pepsinogen screening;
- universal applicability across low- and high-incidence populations;
- a universal combination algorithm with endoscopy or other tests.

These gaps are intentionally preserved.

# Out-of-Scope Topics / Delegation

| Topic | Delegated To |
|---|---|
| Atrophic gastritis as a disease/risk condition | PP-0165 |
| Intestinal metaplasia | PP-0166 |
| Pernicious anemia | PP-0167 |
| H. pylori prevention | PP-0160 |
| H. pylori eradication | PP-0161 |
| High-risk screening eligibility | PP-0170 |
| Endoscopic screening | PP-0171 |
| High-incidence population screening | PP-0173 |
| Screening harms and false results | PP-0174 |
| Diagnostic work-up | PP-0175 |
| Diagnostic endoscopy | PP-0176 |
| Biopsy strategy | PP-0177 |
| Histopathology | PP-0178+ |
| Gastric-cancer treatment | Treatment packages |

# Future Update Triggers

Review this package when:

- NCI updates its gastric-cancer screening evidence.
- New prospective or randomized evidence evaluates serum-pepsinogen screening.
- Validated population-specific thresholds become established.
- New evidence clarifies how H. pylori or PPI exposure should be handled.
- New evidence establishes a mortality benefit or changes the role of pepsinogen in screening.
- PP Registry changes ownership of screening or biomarker interpretation.

# Evidence Package Decision

**APPROVED**

The evidence package supports the approved scope of:

> **PP-0172 — Serum Pepsinogen Screening**

The package intentionally avoids universal thresholds, individualized referral algorithms, and unsupported mortality claims.

# Source Traceability

| Source | Relevant Content |
|---|---|
| NCI — Stomach (Gastric) Cancer Screening PDQ | Serum pepsinogen, PGI/PGII, study-specific cutoffs/performance, atrophic gastritis, intestinal-type relevance, H. pylori/PPI effects, mortality evidence |
| NCI — Stomach (Gastric) Cancer Prevention PDQ | Gastric precursor/risk context |
| NCI — Genetics of Gastric Cancer PDQ | Population/high-risk context |
| NCCN Gastric Cancer Version 2.2026 | Current gastric-cancer clinical framework |
| ACS — Stomach Cancer | Patient-facing screening/risk context |
| PP Registry | Current package identity and neighboring ownership |

# Boundary Verification

**Core =** serum pepsinogen as a gastric-cancer screening/risk-stratification biomarker, PGI/PGII and PGI:PGII ratio at conceptual level, low pepsinogen as a marker of gastric atrophy, relationship with gastric-cancer risk, intestinal-type versus diffuse-type relevance, study-specific screening performance, absence of universal cutoffs, H. pylori/PPI effects, positive/negative result interpretation, and absence of demonstrated mortality benefit; **Supporting =** atrophic-gastritis context, intestinal-metaplasia context, H. pylori context, endoscopy as a possible downstream evaluation, and high-incidence Asian evidence context; **Explicitly Excluded =** detailed atrophic-gastritis management, detailed intestinal-metaplasia classification/surveillance, H. pylori diagnosis/eradication, PPI management, endoscopic technique, high-incidence population screening programs, detailed screening harms/false-result analysis, universal pepsinogen algorithms, universal cutoffs/age thresholds/intervals, individualized endoscopy referral rules, laboratory assay methodology, gastric-cancer diagnosis and treatment; **Delegated-to PP =** PP-0160, PP-0161, PP-0165, PP-0166, PP-0167, PP-0170, PP-0171, PP-0173, PP-0174, PP-0175, PP-0176, PP-0177, PP-0178+, and gastric-cancer treatment packages.

# Final Evidence Status

**PASS — Evidence traceability complete.**
