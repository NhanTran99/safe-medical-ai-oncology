# Phase 6 — Controlled Case/Test Qualification v1.1

## Qualification classes

**A — Direct technical/system:** intrinsic software-contract tests.

**B — Controlled Phase 6 candidate:** technically runnable but requiring
requirement mapping, expected behavior, acceptance criterion and evidence
metadata.

**C — Human evaluator dependent:** requires operational evaluator package.

**D — Clinical-source dependent:** requires governed clinical source/case basis.

## Current disposition

| Domain | Disposition |
|---|---|
| VC-TECH | QUALIFICATION PROCEED |
| VC-SAFE technical enforcement | QUALIFICATION PROCEED |
| VC-SYS | QUALIFICATION PROCEED |
| VC-HUMAN | HOLD — evaluator package required |
| VC-CLIN gastric | DEFERRED — MISSING — REQUIRES SOURCE / CLINICAL INPUT |

## Non-blocking principle

Clinical-source incompleteness does not block a bounded technical/system
validation campaign or a Controlled Research Prototype.

It blocks only unsupported clinical validation claims.
