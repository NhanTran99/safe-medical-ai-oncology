# Phase 6 — Controlled Research Prototype / Phase 7 Evolution Strategy v1.1

## Approved strategic principle

The project does NOT need to wait for a complete gastric clinical case bank
before producing a usable webapp prototype.

The webapp may proceed as a:

# Controlled Research Prototype

It must NOT be represented as a clinically validated clinical decision-support
system or as clinical deployment authorization.

## Iterative pathway

`Technical/System Validation`
→ `Controlled Research Prototype`
→ `Expert/User Feedback`
→ `Governance-Accepted Hypothetical Cases`
→ `Real/De-identified Clinical Evidence where available`
→ `Refinement`
→ `Re-validation`
→ `Phase 7 Continuous Evolution`

## Evidence boundary

- Prototype availability is not clinical validation.
- Expert-created hypothetical cases are not real-world clinical evidence.
- Prototype feedback is not automatically validation evidence.
- Each later case/evidence item requires classification, provenance, version and
  governance treatment.

## Phase 7

Phase 7 may use expert/user feedback and newly governed cases to refine and
revalidate the system.

Phase 7 must not retroactively convert missing Phase 6 clinical validation
into a Phase 6 PASS.
