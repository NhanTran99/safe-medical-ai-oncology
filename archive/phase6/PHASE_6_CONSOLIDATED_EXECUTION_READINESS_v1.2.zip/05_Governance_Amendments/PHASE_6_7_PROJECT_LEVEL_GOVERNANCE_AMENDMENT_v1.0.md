# Phase 6 / Phase 7 — Project-Level Governance Amendment

**Status:** APPROVED FOR MANUAL / CONTROLLED AMENDMENT  
**Date:** 2026-08-14

## A. PROJECT_ROADMAP — Phase 6 section

Amend the Phase 6 objective/expected activities to distinguish technical,
system, safety, human-evaluation and clinical validation.

Add:

> Phase 6 may proceed with domain-level validation where sufficient source and
> execution basis exists. Full gastric case-level clinical validation may
> remain explicitly deferred when governed clinical source material is
> unavailable.

Add:

> A Controlled Research Prototype may be produced after the applicable
> technical/system readiness and GO gate. Prototype availability does not
> constitute clinical validation or clinical deployment authorization.

Add:

> Phase 7 provides the continuous refinement/re-validation pathway for expert
> and user feedback, governance-accepted hypothetical cases, and later
> real/de-identified clinical evidence.

## B. PROJECT_STATUS — current Phase 6 state

Replace the former Phase 6 "0%" / merely planned description with:

> **Phase 6 — Validation: IN PROGRESS**
>
> Architecture / Scope Gate: LOCKED  
> Decision B01–B21: LOCKED  
> Execution preparation: IN PROGRESS  
> Technical/system/safety qualification: IN PROGRESS  
> Gastric clinical validation: DEFERRED — MISSING — REQUIRES SOURCE / CLINICAL INPUT  
> Controlled Research Prototype: PERMITTED after applicable GO  
> Actual Phase 6 validation execution: NOT STARTED  
> Clinical deployment authorization: NOT GRANTED

Do not report the project as clinically validated.

## C. LONG_TERM_ROADMAP — Phase 6 / Phase 7

Refine Phase 6 from a single monolithic validation objective to:

- Technical/system validation
- Safety validation
- Human/user evaluation where operationally supported
- Clinical validation where governed clinical source basis exists
- Controlled Research Prototype pathway
- Validation evidence and acceptance
- Defect/risk disposition

Add explicit Phase 6 clinical limitation:

> Gastric case-level clinical validation may remain deferred until sufficient
> governed clinical source material is available.

Refine Phase 7 to:

- Continuous improvement
- Expert/user feedback
- Clinical scenario/case expansion
- Knowledge expansion
- Re-validation
- Governance evolution
- Regulatory adaptation

## D. Repository policy

No repository-wide cleanup is required at this stage. Active-phase living
documents may evolve locally. Final repository canonicalization remains a
final-project-closure activity.

## E. Claim boundary

The project must distinguish:

`Controlled Research Prototype`
≠ `Technically Validated`
≠ `Clinically Validated`
≠ `Clinically Safe for Deployment`
≠ `Deployment Authorized`
