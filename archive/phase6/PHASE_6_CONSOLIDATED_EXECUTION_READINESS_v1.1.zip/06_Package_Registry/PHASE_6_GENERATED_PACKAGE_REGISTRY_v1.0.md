# Phase 6 — Generated Package Registry / Deduplication Control v1.0

**Purpose:** prevent duplicate/conflicting Phase 6 working packages.

## Current canonical package

### P6-PKG-004
**`PHASE_6_CONSOLIDATED_EXECUTION_READINESS_v1.1.zip`**

Status: **CANONICAL CURRENT WORKING PACKAGE**

Contains:
- Execution Baseline v1.1
- Validation Case/Test Inventory v1.1
- Case/Test Qualification v1.1
- Controlled Research Prototype / Phase 7 Strategy v1.1
- Project-level Governance Amendment v1.0
- this package registry

## Historical / superseded packages

### P6-PKG-001
`PHASE_6_PRE_EXECUTION_QA_ASSEMBLY_WORKING_v1.0.zip`

Status: **HISTORICAL WORKING PACKAGE — SUPERSEDED**
Do not create a new copy unless explicitly required for historical traceability.

### P6-PKG-002
`PHASE_6_EXECUTION_BASELINE_AND_VALIDATION_CASE_TEST_INVENTORY_v1.0.zip`

Status: **HISTORICAL BASELINE PACKAGE — SUPERSEDED BY P6-PKG-004**
Preserve; do not treat as current canonical package.

### P6-PKG-003
`PHASE_6_CASE_QUALIFICATION_AND_ITERATIVE_DEPLOYMENT_STRATEGY_v1.0.zip`

Status: **HISTORICAL FOLLOW-UP PACKAGE — CONSOLIDATED INTO P6-PKG-004**
Preserve; do not treat as current canonical package.

## Rule going forward

Only one active consolidated Phase 6 execution-readiness ZIP shall exist:

**P6-PKG-004**

New artifacts should be added to the canonical package/version rather than
creating parallel ZIPs with overlapping contents.

Historical packages remain preserved for traceability but are not active.

## Next package

The next package should NOT be generated until the next material decision
requires a substantive artifact set (e.g. qualified case inventory,
operational evidence-capture package, or Pre-Execution QA result).
