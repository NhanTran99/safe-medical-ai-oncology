# Phase 6 — Controlled Validation Case / Test Inventory

**Status:** CONTROLLED PREPARATION INVENTORY — NOT YET EXECUTED

Inherited Phase 5 tests are mapped as candidate controlled Phase 6
technical/system/safety test units. Their PASS status is not Phase 6
validation evidence.

| Phase 6 ID | Domain | Existing test module | Tests | State |
|---|---|---|---:|---|
| VC-TECH-RET-01 | VC-TECH | `test_retrieval_models.py` | 8 | CANDIDATE |
| VC-TECH-RET-02 | VC-TECH | `test_retrieval_service.py` | 10 | CANDIDATE |
| VC-TECH-RET-03 | VC-TECH | `test_retrieval_filesystem_source.py` | 14 | CANDIDATE |
| VC-TECH-EVD-01 | VC-TECH | `test_evidence_models.py` | 13 | CANDIDATE |
| VC-TECH-EVD-02 | VC-TECH | `test_evidence_assembly.py` | 23 | CANDIDATE |
| VC-TECH-INT-01 | VC-TECH | `test_integration_models.py` | 14 | CANDIDATE |
| VC-TECH-INT-02 | VC-TECH | `test_integration.py` | 20 | CANDIDATE |
| VC-TECH-GEN-01 | VC-TECH | `test_generation_models.py` | 9 | CANDIDATE |
| VC-TECH-GEN-02 | VC-TECH | `test_generation.py` | 26 | CANDIDATE |
| VC-TECH-VAL-01 | VC-TECH | `test_validation_models.py` | 10 | CANDIDATE |
| VC-TECH-VAL-02 | VC-TECH | `test_validation.py` | 24 | CANDIDATE |
| VC-SAFE-01 | VC-SAFE | `test_safety_models.py` | 5 | CANDIDATE |
| VC-SAFE-02 | VC-SAFE | `test_safety_enforcement.py` | 27 | CANDIDATE |
| VC-SYS-01 | VC-SYS | `test_app.py` | 2 | CANDIDATE |
| VC-SYS-02 | VC-SYS | `test_config.py` | 3 | CANDIDATE |
| VC-SYS-03 | VC-SYS | `test_trace.py` | 3 | CANDIDATE |
| VC-SYS-04 | VC-SYS | `test_imports.py` | 5 | CANDIDATE |
| VC-HUMAN-* | VC-HUMAN | none operationally identified | — | MISSING — REQUIRES EVALUATOR PACKAGE |
| VC-CLIN-GC-* | VC-CLIN | no accepted case bank identified | — | MISSING — REQUIRES SOURCE / CLINICAL INPUT |

### Aggregate
- Static `test_*` functions discovered: **216**
- Pytest executed: **287**
- Pytest result: **287 PASS**

The difference is due to pytest parameterization/generated test cases.

### Required conversion before execution
Each selected Phase 6 test must receive:
- Case/Test ID
- validation layer
- requirement mapping
- objective
- controlled input/fixture version
- expected behavior
- acceptance criterion
- evidence requirement
- safety state where applicable
- provenance/version
- evaluator requirement
- execution status
- Run ID after execution

No gastric clinical case is created or synthesized.
