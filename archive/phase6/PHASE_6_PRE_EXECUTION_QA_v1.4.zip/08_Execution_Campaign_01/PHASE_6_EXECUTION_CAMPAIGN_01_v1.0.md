# Phase 6 — Execution Campaign 01
**Campaign ID:** `P6-EC-001`  
**Status:** CONTROLLED PRE-EXECUTION SELECTION — NOT EXECUTED

## Purpose
First bounded technical/system/safety validation campaign. This is **not a
clinical validation campaign** and excludes VC-CLIN gastric and VC-HUMAN.

## Selection principle
Two tests from each qualified non-safety test module, plus four safety
enforcement tests. This is representative coverage, not exhaustive coverage
of the 216 candidate test units.

## Selected tests
| # | Case/Test ID | Domain | Source module | Test |
|---:|---|---|---|---|
| 1 | `VC-SAFE-01` | VC-SAFE | `test_safety_enforcement.py` | `test_authorized_request_allows` |
| 2 | `VC-SAFE-02` | VC-SAFE | `test_safety_enforcement.py` | `test_warning_preserved` |
| 3 | `VC-SAFE-03` | VC-SAFE | `test_safety_enforcement.py` | `test_default_deny` |
| 4 | `VC-SAFE-04` | VC-SAFE | `test_safety_enforcement.py` | `test_prohibited_rejected` |
| 5 | `VC-SAFE-01` | VC-SAFE | `test_safety_models.py` | `test_risk_vocabulary_is_exact` |
| 6 | `VC-SAFE-02` | VC-SAFE | `test_safety_models.py` | `test_action_vocabulary_is_exact` |
| 7 | `VC-SYS-01` | VC-SYS | `test_app.py` | `test_health_endpoint_ok` |
| 8 | `VC-SYS-02` | VC-SYS | `test_app.py` | `test_health_endpoint_propagates_incoming_trace_id` |
| 9 | `VC-SYS-01` | VC-SYS | `test_config.py` | `test_settings_load_with_defaults` |
| 10 | `VC-SYS-02` | VC-SYS | `test_config.py` | `test_get_settings_is_cached` |
| 11 | `VC-SYS-01` | VC-SYS | `test_imports.py` | `test_package_has_version` |
| 12 | `VC-SYS-02` | VC-SYS | `test_imports.py` | `test_submodules_importable` |
| 13 | `VC-SYS-01` | VC-SYS | `test_trace.py` | `test_new_trace_id_is_unique` |
| 14 | `VC-SYS-02` | VC-SYS | `test_trace.py` | `test_set_and_get_trace_id` |
| 15 | `VC-TECH-EVD-01` | VC-TECH | `test_evidence_assembly.py` | `test_valid_retrieval_response_assembles_to_complete_rtep` |
| 16 | `VC-TECH-EVD-02` | VC-TECH | `test_evidence_assembly.py` | `test_evidence_content_and_metadata_are_preserved` |
| 17 | `VC-TECH-EVD-01` | VC-TECH | `test_evidence_models.py` | `test_rtep_assembly_outcome_vocabulary` |
| 18 | `VC-TECH-EVD-02` | VC-TECH | `test_evidence_models.py` | `test_rtep_assembly_outcome_is_distinct_from_retrieval_and_validation_outcome` |
| 19 | `VC-TECH-GEN-01` | VC-TECH | `test_generation.py` | `test_evidence_present_generation_succeeds` |
| 20 | `VC-TECH-GEN-02` | VC-TECH | `test_generation.py` | `test_provider_receives_authoritative_rtep_evidence` |
| 21 | `VC-TECH-GEN-01` | VC-TECH | `test_generation_models.py` | `test_generation_outcome_vocabulary` |
| 22 | `VC-TECH-GEN-02` | VC-TECH | `test_generation_models.py` | `test_generation_outcome_is_distinct_from_every_other_vocabulary` |
| 23 | `VC-TECH-INT-01` | VC-TECH | `test_integration.py` | `test_valid_rtep_produces_integrated_with_valid_context` |
| 24 | `VC-TECH-INT-02` | VC-TECH | `test_integration.py` | `test_integrated_context_preserves_request_and_navigation_and_constraints` |
| 25 | `VC-TECH-INT-01` | VC-TECH | `test_integration_models.py` | `test_runtime_integration_outcome_vocabulary` |
| 26 | `VC-TECH-INT-02` | VC-TECH | `test_integration_models.py` | `test_runtime_integration_outcome_is_distinct_from_other_vocabularies` |
| 27 | `VC-TECH-RET-01` | VC-TECH | `test_retrieval_filesystem_source.py` | `test_successful_retrieval_via_prefix_matched_directory` |
| 28 | `VC-TECH-RET-02` | VC-TECH | `test_retrieval_filesystem_source.py` | `test_successful_retrieval_via_exact_name_directory` |
| 29 | `VC-TECH-RET-01` | VC-TECH | `test_retrieval_models.py` | `test_artifact_type_vocabulary` |
| 30 | `VC-TECH-RET-02` | VC-TECH | `test_retrieval_models.py` | `test_artifact_type_sort_key_is_canonical_order` |
| 31 | `VC-TECH-RET-01` | VC-TECH | `test_retrieval_service.py` | `test_valid_navigation_retrieval_returns_all_artifacts_in_canonical_order` |
| 32 | `VC-TECH-RET-02` | VC-TECH | `test_retrieval_service.py` | `test_hierarchical_filtering_by_artifact_type` |
| 33 | `VC-TECH-VAL-01` | VC-TECH | `test_validation.py` | `test_valid_candidate_with_evidence_backed_rtep_is_valid` |
| 34 | `VC-TECH-VAL-02` | VC-TECH | `test_validation.py` | `test_valid_result_carries_traceability_from_candidate` |
| 35 | `VC-TECH-VAL-01` | VC-TECH | `test_validation_models.py` | `test_candidate_validation_outcome_vocabulary` |
| 36 | `VC-TECH-VAL-02` | VC-TECH | `test_validation_models.py` | `test_candidate_validation_outcome_is_disjoint_from_upstream_pipeline_outcomes` |
## Coverage
**36 selected / 216 candidate test functions.**

The remaining candidates remain available for later campaigns, targeted
regression, defect-triggered revalidation, or release verification.

## Execution status
All 36 are **SELECTED — NOT EXECUTED**.
