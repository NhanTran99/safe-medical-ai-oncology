# Phase 6 — P6-EC-001 Execution State Intake

**Purpose:** obtain the minimum run-side attestation required to freeze the
actual execution state.

## Already known

- Inherited Phase 5 implementation reference: `0f413c9`
- Current repository HEAD supplied by Project Coordinator:
  `23aa646ac2fe9755a58bdfdeece67b29a476ba88`
- Working tree at last supplied state: DIRTY
- Campaign: `P6-EC-001`
- Selected tests: 36

## Required from the actual execution machine

Run from the repository root immediately before the intended validation run:

```bash
git rev-parse HEAD
git status --short
python --version
python -c "import sys,platform; print(sys.executable); print(platform.platform())"
python -m pytest --version
```

Also provide the exact outputs of:

```bash
python -c "import sys; print(sys.version)"
```

## Baseline files/configuration

Provide or identify the exact versions/paths used for:
- knowledge baseline;
- evidence/RTEP baseline;
- safety configuration/policy;
- selected test package.

## Important

Do not run `P6-EC-001` yet.

The above is an intake/attestation step only.

Once supplied, the outputs will be reconciled into the execution baseline.
Only then will a Run ID be assigned and Pre-Execution QA rerun.
