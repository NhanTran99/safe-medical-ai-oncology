# Execution State Control Rule

The current repository HEAD and dirty working tree are **development state**,
not an execution authorization.

No repository-wide cleanup is required.

Before GO, the project must identify one reproducible execution state and record
its repository commit/state, runtime, knowledge/evidence/safety baselines and
test package identity.

After GO:
- execute only the authorized campaign;
- capture every result;
- preserve failures/deviations;
- do not overwrite evidence;
- do not backfill Phase 6 evidence from Phase 5 results.
