# Phase 6 — Controlled Evidence-Capture Package v1.0
**Status:** CONTROLLED TEMPLATE — NO EXECUTION EVIDENCE RECORDED  
**Campaign:** `P6-EC-001`

## Required record
Run ID | Campaign ID | Case/Test ID | Domain | Requirement ID | Repository
commit/state | Test package version/hash | Runtime/environment | Input/fixture
identity | Expected behavior | Acceptance criterion | Observed behavior | Result
| Evidence artifact | Provenance | Timestamp | Safety state/event where
applicable | Evaluator result where applicable

## Evidence integrity rule
Only actual controlled Phase 6 execution can populate this package.
The inherited **287 PASS** result must not be relabeled as Phase 6 evidence.

## Empty ledger
| Run ID | Case/Test ID | Expected | Observed | Result | Evidence Ref | Provenance | Timestamp |
|---|---|---|---|---|---|---|---|
| — | — | — | — | NOT EXECUTED | — | — | — |

## Failure/deviation rule
Retain raw/structured evidence, exact test identity, environment/version,
failure classification, safety significance, disposition and re-test linkage.
Do not overwrite a failed result with a later PASS.
