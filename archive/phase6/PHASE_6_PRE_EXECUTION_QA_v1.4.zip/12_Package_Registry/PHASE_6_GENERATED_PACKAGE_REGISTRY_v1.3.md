# Phase 6 — Generated Package Registry / Deduplication Control v1.3

## Current canonical package

### P6-PKG-007
**`PHASE_6_PRE_EXECUTION_QA_v1.4.zip`**

Status: **CANONICAL CURRENT WORKING PACKAGE**

Reason:
- P6-EC-001 Pre-Execution QA instantiated;
- exact execution-state intake instantiated;
- GO gate explicitly remains NO-GO pending required attestation.

## Historical packages

P6-PKG-001 → P6-PKG-006 remain historical/superseded and are preserved for
traceability.

## Active-package rule

Only **P6-PKG-007** is active for the current Pre-Execution QA gate.
Do not create parallel ZIPs containing the same current QA/readiness material.
