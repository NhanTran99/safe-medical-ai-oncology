# Phase 6 — Generated Package Registry / Deduplication Control v1.2

## Current canonical package
### P6-PKG-006
**`PHASE_6_CONSOLIDATED_EXECUTION_READINESS_v1.3.zip`**

Status: **CANONICAL CURRENT WORKING PACKAGE**

Reason: controlled Evidence-Capture Package and first bounded execution
campaign selection have been added.

## Historical packages
P6-PKG-001 → P6-PKG-005 are historical/superseded and retained for traceability.

## Active-package rule
Only **P6-PKG-006** is active. Do not create parallel ZIPs with overlapping
current execution-readiness contents.
