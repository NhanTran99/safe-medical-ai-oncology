# Phase 6 — Iterative Validation + Limited Web-App Strategy

## Strategic decision

Do not wait for a complete clinical case bank before producing a usable
prototype.

Instead use a **bounded iterative release strategy**:

`Technical/System Validation`
→ `Controlled Prototype`
→ `Limited Expert / User Evaluation`
→ `Case Acquisition`
→ `Refinement`
→ `Re-validation`
→ `Broader Validation`

## Release tiers

### Tier 0 — Internal validation
Scope:
- retrieval;
- evidence/RTEP integrity;
- generation contract;
- validation contract;
- safety enforcement mechanics;
- observability/configuration.

No clinical performance claim.

### Tier 1 — Controlled prototype / webapp
The webapp may be deployed for controlled use with explicit labeling:

- research/prototype;
- not clinically validated;
- not for autonomous diagnosis/treatment;
- clinical decisions remain with qualified users;
- known validation limitations visible.

The application must preserve traceability and evidence capture.

### Tier 2 — Expert-assisted evaluation
Use qualified experts to:
- review outputs;
- identify failure modes;
- propose or approve test scenarios;
- construct hypothetical/educational cases where appropriate;
- classify errors;
- identify missing requirements.

These expert-created hypothetical cases are **validation cases only after
governance acceptance and provenance/version recording**. They must not be
represented as real-world clinical evidence.

### Tier 3 — Real-world / real-case evidence
When permitted and appropriately governed, collect de-identified real clinical
cases or structured case reports and use them for controlled re-validation.

This is where actual clinical validation evidence begins to accumulate.

### Tier 4 — Continuous refinement
Feed validated findings into:
- requirement updates;
- safety rules;
- knowledge improvements;
- retrieval improvements;
- evaluator rubric refinement;
- regression suite expansion.

Every material change triggers appropriate re-validation.

## Claim boundary

Prototype deployment can occur before complete clinical validation.

The project must distinguish:

`Prototype Available`
≠ `Technically Validated`
≠ `Clinically Validated`
≠ `Clinically Safe for Deployment`
≠ `Deployment Authorized`

## Phase 7 relationship

Phase 7 should be treated as the **continuous refinement/evolution loop** for
new real-world feedback and expert-derived cases.

However, Phase 7 must NOT be used to retroactively claim that missing Phase 6
clinical validation was completed.

Phase 6 closes with explicit validation limitations.

## Recommended product strategy

Build the webapp now, but release it as a **controlled research prototype**,
not as a clinical decision-support deployment.

Use the prototype itself as a structured feedback collection mechanism, not as
an uncontrolled clinical experiment.

## Minimum guardrails for prototype use

- explicit prototype/non-clinical-use notice;
- human oversight;
- no autonomous treatment/diagnosis claims;
- trace/evidence provenance retained;
- safety behavior visible;
- feedback linked to version/run;
- ability to flag unsafe/incorrect output;
- no uncontrolled mixing of prototype feedback with formal validation evidence.
