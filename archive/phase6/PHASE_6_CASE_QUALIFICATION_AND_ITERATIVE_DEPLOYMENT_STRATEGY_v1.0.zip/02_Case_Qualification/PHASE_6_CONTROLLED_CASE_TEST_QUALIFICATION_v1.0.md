# Phase 6 — Controlled Case/Test Qualification

## Status
**WORKING — QUALIFICATION STARTED**

## Purpose

Convert inherited Phase 5 tests into a controlled Phase 6 candidate set without
misrepresenting regression tests as clinical validation.

## Qualification classes

### A — Directly executable technical/system tests
Tests whose input, expected behavior and acceptance criterion are intrinsic to
the software contract and do not require human clinical judgment.

Candidate families:
- retrieval model/service/filesystem behavior;
- RTEP/evidence model and assembly behavior;
- integration boundary;
- generation boundary;
- validation contract;
- safety enforcement mechanics;
- API/configuration/trace/import integrity.

### B — Executable only after Phase 6 control metadata is added
Tests technically runnable but requiring explicit Phase 6 requirement mapping,
expected behavior, evidence capture and execution manifest entry.

This is the main current class for inherited tests.

### C — Human-evaluator dependent
Requires operational evaluator instructions, assessment form, boundary
guidance and evidence submission.

Current status:
**MISSING — REQUIRES EVALUATOR PACKAGE**

### D — Clinical-source dependent
Requires actual governed clinical scenarios/cases with sufficient provenance
and expected behavior.

Current status:
**MISSING — REQUIRES SOURCE / CLINICAL INPUT**

This includes gastric case-level clinical decision and safety scenarios.

## Qualification rule

No inherited test becomes Phase 6 evidence merely because it passed in Phase 5.

A test becomes an executable Phase 6 case only after:

`Requirement → Input → Expected Behavior → Acceptance Criterion → Evidence Capture → Provenance/Version → Run ID`

## Current recommended disposition

| Domain | Qualification |
|---|---|
| VC-TECH | Proceed to controlled qualification |
| VC-SAFE technical enforcement | Proceed to controlled qualification |
| VC-SYS | Proceed to controlled qualification |
| VC-HUMAN | Hold pending evaluator package |
| VC-CLIN gastric | Deferred — MISSING — REQUIRES SOURCE / CLINICAL INPUT |

## Explicit non-blocking principle

The absence of gastric clinical cases does NOT block creation of a bounded
prototype web application or controlled technical/system validation.

It blocks only the claims and validation conclusions that require those cases.
