# Phase 6 — Evidence-Capture Package

**Status:** NOT READY — TEMPLATE / REQUIRED CONTROL

## Minimum record

| Field | Required |
|---|---|
| Run ID | YES |
| Case/Test ID | YES |
| Requirement ID | YES |
| Input / Scenario | YES |
| Expected Behavior | YES |
| Observed Behavior | YES |
| Runtime Evidence | YES where applicable |
| Safety Event / Decision | YES where applicable |
| Evaluator Result | YES where applicable |
| Provenance | YES |
| Repository Commit | YES |
| Knowledge Baseline | YES |
| Safety Policy/Configuration Version | YES |
| Timestamp | YES |
| Evidence Artifact Reference | YES |

## Boundary

A completed capture record is Phase 6 execution evidence only when it is
generated from an authorized controlled execution.

Existing Phase 5 test output must not be copied into this package and relabeled
as Phase 6 evidence.
