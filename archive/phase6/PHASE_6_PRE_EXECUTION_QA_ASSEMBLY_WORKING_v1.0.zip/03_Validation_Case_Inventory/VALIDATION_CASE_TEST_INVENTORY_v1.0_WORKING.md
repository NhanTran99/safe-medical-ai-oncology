# Phase 6 — Validation Case / Test Inventory

**Status:** WORKING — INHERITED TEST BASIS RECONCILED  
**Important:** Existing tests are not automatically Phase 6 validation evidence.

| Candidate ID | Domain | Existing basis | Intended Phase 6 use | Status |
|---|---|---|---|---|
| TECH-REG-001 | VC-TECH | retrieval model/service tests | technical contract/regression check | CANDIDATE |
| TECH-REG-002 | VC-TECH | filesystem retrieval tests | repository retrieval behavior | CANDIDATE |
| TECH-REG-003 | VC-TECH | RTEP/evidence tests | evidence assembly contract | CANDIDATE |
| TECH-REG-004 | VC-TECH | integration tests | runtime integration contract | CANDIDATE |
| TECH-REG-005 | VC-TECH | generation tests | generation boundary behavior | CANDIDATE |
| TECH-REG-006 | VC-TECH | validation tests | validation contract behavior | CANDIDATE |
| SAFE-REG-001 | VC-SAFE | safety model tests | safety vocabulary/model invariants | CANDIDATE |
| SAFE-REG-002 | VC-SAFE | safety enforcement tests | safety-before-retrieval / downstream gating | CANDIDATE |
| SYS-REG-001 | VC-SYS | API/config/trace tests | system boundary/observability checks | CANDIDATE |
| HUMAN-* | VC-HUMAN | no operational evaluator package identified | human evaluation | MISSING — REQUIRES EVALUATOR PACKAGE |
| CLIN-GC-* | VC-CLIN | no accepted case bank in supplied implementation/test packages | gastric clinical validation | MISSING — REQUIRES SOURCE / CLINICAL INPUT |

## Required Phase 6 transformation

Before any candidate inherited test is treated as an executable Phase 6 case,
it must receive:
- requirement mapping;
- explicit objective;
- controlled input/version;
- expected behavior;
- acceptance criterion;
- evidence requirement;
- provenance/version;
- execution identifier.

No gastric clinical case is to be invented or synthesized.
