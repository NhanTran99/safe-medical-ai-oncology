# PHASE 6 --- VALIDATION CASE, SCENARIO & DATASET ARCHITECTURE

**Document:** Phase 6 Validation Case, Scenario & Dataset Architecture\
**Phase:** Phase 6 --- Validation\
**Decision Batch:** 03\
**Version:** 1.0\
**Status:** APPROVED --- LOCKED\
**Approval basis:** V6-B03.1 → V6-B03.14 approved by Project
Coordinator\
**Date:** 2026-08-14

------------------------------------------------------------------------

# 1. Purpose

This document defines the approved architecture for selecting,
structuring, versioning, controlling, and tracing the validation cases,
clinical scenarios, datasets, and evaluation inputs used during Phase 6.

It operationalizes the Validation Architecture & Evidence Model without
prematurely fixing exact case counts, datasets, statistical power,
thresholds, or evaluator recruitment.

------------------------------------------------------------------------

# 2. Inherited Baseline

Phase 6 is:

**Phase 6 --- Validation**

The Architecture / Scope Gate is locked.

Batch 02 is locked and establishes:

-   validation requirement taxonomy;
-   validation evidence unit;
-   validation case structure;
-   end-to-end scenarios;
-   clinical patient-journey basis;
-   evidence fidelity validation;
-   safety behavioral validation;
-   human evaluation model;
-   finding/disposition lifecycle;
-   re-validation principles;
-   validation-record lifecycle;
-   bidirectional traceability.

Phase 5 remains:

**CLOSED / PASS**

Implementation baseline:

**Task #002 → Task #009**

Final implementation commit:

`0f413c9`

------------------------------------------------------------------------

# 3. Locked Decisions

## V6-B03.1 --- Validation Case Families

**LOCKED**

Validation cases shall be organized into five primary families:

-   `VC-TECH` --- Technical / Architecture
-   `VC-CLIN` --- Clinical Knowledge / Evidence
-   `VC-SAFE` --- Safety Behavioral
-   `VC-HUMAN` --- Human-Oversight / User
-   `VC-SYS` --- System Acceptance

Each case shall map to one or more applicable validation requirements.

------------------------------------------------------------------------

## V6-B03.2 --- Clinical Scenario Dimensions

**LOCKED**

Clinical scenarios shall be structured around:

``` text
Clinical State
+
User Intent
+
Clinical / Evidence Context
+
Safety Context
+
Expected System Boundary
```

This preserves the existing clinical navigation model rather than
creating an independent clinical taxonomy.

------------------------------------------------------------------------

## V6-B03.3 --- Scenario Coverage Model

**LOCKED**

Scenario coverage shall be evaluated across a multidimensional model:

``` text
Clinical State
        ×
User Intent
        ×
Evidence State
        ×
Safety State
        ×
Expected Action
```

Expected actions may include:

-   answer;
-   clarify;
-   redirect;
-   escalate;
-   reject;
-   safe fallback.

Exact scenario inventory remains deferred.

------------------------------------------------------------------------

## V6-B03.4 --- Technical Validation Set Architecture

**LOCKED**

Technical validation shall include:

-   unit/boundary behavior;
-   cross-boundary integration;
-   end-to-end behavior;
-   regression-sensitive cases.

Phase 5 regression evidence remains inherited technical evidence and
does not constitute the entirety of Phase 6 validation.

------------------------------------------------------------------------

## V6-B03.5 --- Clinical Evaluation Set Architecture

**LOCKED**

The clinical evaluation set shall evaluate:

-   clinical correctness;
-   evidence fidelity;
-   appropriate scope;
-   clinical-state navigation;
-   evidence-insufficiency behavior;
-   response appropriateness.

Case selection shall prioritize representative clinical scenarios rather
than simple case-count maximization.

------------------------------------------------------------------------

## V6-B03.6 --- Safety Challenge-Set Architecture

**LOCKED**

Safety validation shall contain dedicated challenge cases covering, as
applicable:

-   normal cases;
-   ambiguous cases;
-   insufficient-evidence cases;
-   unsafe/prohibited cases;
-   high-risk cases;
-   escalation-required cases;
-   emergency cases;
-   boundary-failure cases.

Expected behavior shall map to the locked Phase 5 safety actions.

------------------------------------------------------------------------

## V6-B03.7 --- Human-Evaluation Case Architecture

**LOCKED**

Human-evaluation cases shall support assessment of:

-   Clinical Accuracy;
-   Patient Safety;
-   Communication Quality;
-   boundary recognition;
-   uncertainty;
-   escalation.

Human evaluation shall assess whether users understand when human
intervention is required and whether the system could be misinterpreted
as unrestricted clinical authority.

------------------------------------------------------------------------

## V6-B03.8 --- Dataset / Source Provenance

**LOCKED**

Each validation dataset or case source shall retain provenance
sufficient to identify:

-   Dataset / Case ID;
-   Source;
-   Version;
-   Date / access context where applicable;
-   Purpose;
-   Validation Layer;
-   usage permission/restriction;
-   relationship to governed project materials.

Clinical source materials and validation datasets shall remain
conceptually distinct from knowledge products.

------------------------------------------------------------------------

## V6-B03.9 --- Versioning / Immutability

**LOCKED**

A validation dataset or controlled case set used for execution shall
have an identifiable version.

Executed validation records shall identify the exact dataset/case
version used.

Changes to a validation set shall produce a distinguishable version and
shall not silently alter the historical execution basis.

------------------------------------------------------------------------

## V6-B03.10 --- Leakage / Contamination Control

**LOCKED**

Phase 6 validation sets shall be protected against inappropriate
contamination through:

-   implementation tuning;
-   prompt/example tuning;
-   training/reference use;
-   other workflows that could compromise independent validation.

Validation-set independence shall be sufficient to support credible
validation evidence.

The detailed contamination protocol remains deferred.

------------------------------------------------------------------------

## V6-B03.11 --- Case ↔ Requirement Mapping

**LOCKED**

Every validation case shall map to its applicable validation
requirement(s):

``` text
Validation Case
      ↓
VR Requirement(s)
      ↓
Validation Layer
```

The reverse relationship shall also be maintained:

``` text
VR Requirement
      ↓
Covering Validation Cases
```

Important validation requirements shall not remain orphaned from
validation coverage.

------------------------------------------------------------------------

## V6-B03.12 --- Dataset ↔ Validation Record Mapping

**LOCKED**

Every validation execution record shall identify:

-   validation record;
-   dataset version;
-   case IDs;
-   relevant system/version context;
-   observed results.

The mapping shall support reproducibility and auditability.

------------------------------------------------------------------------

## V6-B03.13 --- Sampling Principle

**LOCKED**

Validation sampling shall combine:

-   representative coverage;
-   risk-based sampling;
-   boundary cases;
-   known difficult cases;
-   failure-oriented cases.

Random sampling may be used where appropriate but shall not be the sole
sampling principle.

Exact sample size and statistical methodology remain deferred.

------------------------------------------------------------------------

## V6-B03.14 --- Validation Set Acceptance Gate

**LOCKED**

A validation set may enter controlled execution only after:

1.  scope is defined;
2.  provenance is established;
3.  version is assigned;
4.  requirement mapping is complete;
5.  contamination risks are assessed;
6.  expected behavior is defined;
7.  required evidence is available;
8.  ownership/review is completed.

This establishes:

**Validation Set Readiness → Validation Execution**

------------------------------------------------------------------------

# 4. Validation Case Architecture

The controlled relationship is:

``` text
Validation Requirement
        ↓
Validation Case Family
        ↓
Validation Case
        ↓
Scenario / Input
        ↓
Expected Behavior
        ↓
Execution
        ↓
Observed Behavior
        ↓
Evidence
        ↓
Finding / Disposition
```

------------------------------------------------------------------------

# 5. Clinical Scenario Architecture

Clinical scenarios shall remain grounded in the existing clinical
navigation model.

The scenario design space is:

``` text
Clinical State
        ×
User Intent
        ×
Clinical / Evidence Context
        ×
Safety Context
        ×
Expected System Boundary
```

This allows Phase 6 to evaluate not only whether a response is correct,
but whether the system selected the appropriate behavior for the
clinical and safety context.

------------------------------------------------------------------------

# 6. Validation Dataset Architecture

The Phase 6 dataset architecture shall distinguish at least:

``` text
Technical Validation Set
Clinical Evaluation Set
Safety Challenge Set
Human Evaluation Set
System Acceptance Set
```

A dataset may support multiple validation layers only when its role,
version, provenance, and use remain explicitly controlled.

------------------------------------------------------------------------

# 7. Validation Set Readiness

Before controlled execution:

``` text
Candidate Validation Set
        ↓
Scope Review
        ↓
Provenance Review
        ↓
Version Assignment
        ↓
Requirement Mapping
        ↓
Contamination Assessment
        ↓
Expected-Behavior Review
        ↓
Ownership / Approval
        ↓
VALIDATION SET READY
```

A set that fails readiness shall not silently enter execution.

------------------------------------------------------------------------

# 8. Traceability Architecture

The required relationships are:

``` text
Requirement
   ↕
Validation Case
   ↕
Dataset / Scenario
   ↕
Validation Record
   ↕
Evidence
   ↕
Finding
   ↕
Risk
   ↕
Disposition
```

This is the minimum conceptual traceability chain for Phase 6
validation.

------------------------------------------------------------------------

# 9. Deferred Decisions

The following remain intentionally open:

-   exact case inventory;
-   exact dataset selection;
-   exact number of cases;
-   exact sample size;
-   statistical power;
-   evaluator recruitment;
-   final scoring thresholds;
-   detailed contamination protocol;
-   detailed dataset schema;
-   validation tooling.

These shall be resolved through subsequent Decision Batches.

------------------------------------------------------------------------

# 10. Required Materials for Subsequent Batches

Before detailed dataset or scenario execution design is locked, the
Strategist shall use the controlled project materials available for:

-   clinical navigation;
-   system evaluation;
-   safety;
-   medical governance;
-   output validation;
-   Phase 5 implementation/validation boundaries;
-   existing governed clinical knowledge and evidence where clinical
    cases require source grounding.

If essential project-specific validation materials are missing,
conflicting, or insufficient, the Strategist shall identify the gap and
request the specific material required rather than silently substituting
generic content.

------------------------------------------------------------------------

# 11. Next Decision Batch

## Decision Batch 04 --- Validation Metrics, Acceptance Criteria & Scoring Architecture

### Purpose

Define how validation results will be measured, scored, interpreted, and
accepted across the five Phase 6 validation layers.

### Proposed Must-Decide-Now Topics

1.  Validation result vocabulary.
2.  Layer-specific evaluation dimensions.
3.  Technical validation metrics.
4.  Clinical validation dimensions.
5.  Evidence-fidelity dimensions.
6.  Safety behavioral scoring model.
7.  Human-evaluation scoring dimensions.
8.  System-level acceptance model.
9.  Critical vs non-critical findings.
10. Blocking vs non-blocking criteria.
11. Minimum evidence for PASS.
12. PASS WITH CONTROLLED REMEDIATION conditions.
13. FAIL conditions.
14. Cross-layer aggregation principles.
15. Non-overclaim rules for final validation conclusions.

### Intentionally Deferred

-   exact numeric thresholds where project evidence has not yet
    established them;
-   statistical testing details;
-   exact evaluator scoring instruments;
-   final case-level scoring sheets.

------------------------------------------------------------------------

# 12. Decision Status

**V6-B03.1 → V6-B03.14: APPROVED → LOCKED**

**Phase 6 Validation Case / Scenario / Dataset Architecture: LOCKED**

**Validation Set Execution: NOT STARTED**

**Next Decision Batch: V6-B04 --- Validation Metrics, Acceptance
Criteria & Scoring Architecture**
