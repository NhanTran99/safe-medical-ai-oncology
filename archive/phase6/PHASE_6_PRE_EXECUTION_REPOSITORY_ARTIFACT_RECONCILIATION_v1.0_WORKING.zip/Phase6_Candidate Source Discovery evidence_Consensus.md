# Candidate **Phase 6** Source Inventory

This source-discovery sweep covers **case sources, safety instruments, and provenance-focused technical validation**, with gastric oncology prioritized over broader oncology and general medical methods. The current evidence base contains some usable oncology case materials and many methodological instruments, but **very few direct gastric case banks** in the supplied set  (Hernandez-Flores et al., 2025; Pinninti et al., 2026; Ferber et al., 2025; Chen et al., 2025; Alu & Oluwadare, 2026; Ajani et al., 2025).

## Search Scope

The supplied materials cluster into five practical discovery buckets: oncology case-like materials, safety/red-team challenge sets, evaluator frameworks, provenance/citation-grounding instruments, and gastric clinical references  (Hernandez-Flores et al., 2025; Chen et al., 2025; Asgari et al., 2025; Alu & Oluwadare, 2026; Association, 2020).

Only sources that **themselves contain cases, vignettes, questions, or released evaluation instances** qualify as CASE_SOURCE; guidelines and methodological frameworks do not  (Pinninti et al., 2026; Ahmed et al., 2026; Association, 2020; Alu & Oluwadare, 2026).

## Candidate Source Inventory

| ID | Material | Primary Type | Validation Family | Case/Scenario Present? | Gastric Relevance | Provenance | License | Sufficiency | Status |
|---|---|---|---|---|---|---|---|---|---|
| C1 | Assessment of Challenging Oncologic Cases | CASE_SOURCE | VC-CLIN, VC-HUMAN | Yes, 98 retrospective oncologic cases  (Hernandez-Flores et al., 2025)| ONCOLOGY ANALOG | Journal article; DOI/PMID NOT FOUND in supplied text | NOT FOUND | Moderate; cases exist but release/access unclear | CANDIDATE — DISCOVERY ONLY |
| C2 | AI vs MDT Prospective Concordance Study | CASE_SOURCE | VC-CLIN, VC-HUMAN, VC-SAFE | Yes, standardized de-identified vignettes from 106 real MDT cases  (Pinninti et al., 2026)| Includes esophagus, not explicit gastric  (Pinninti et al., 2026)| Journal article; supplementary vignette template available  (Pinninti et al., 2026)| NOT FOUND | Moderate; strong structure, release of case set not demonstrated | CANDIDATE — DISCOVERY ONLY |
| C3 | Autonomous AI Agent in Oncology | EVALUATOR_INSTRUMENT | VC-TECH, VC-CLIN, VC-HUMAN | Yes, but **researcher-generated simulated** GI-oncology cases  (Ferber et al., 2025)| UPPER-GI / GI oncology analog | Nature Cancer article | NOT FOUND | Useful methodology, not real clinical case source | POTENTIALLY USABLE — GOVERNANCE REVIEW REQUIRED |
| C4 | CARES | SAFETY_INSTRUMENT | VC-SAFE, VC-TECH | Yes, 18,000 prompts; research-generated safety material  (Chen et al., 2025)| GENERAL METHODOLOGICAL SOURCE | arXiv benchmark | NOT FOUND | High for safety stress-testing | CANDIDATE — DISCOVERY ONLY |
| C5 | Red-Teaming Medical AI | SAFETY_INSTRUMENT | VC-SAFE, VC-TECH | Yes, 160 adversarial prompts; research-generated  (Ekram, 2026)| GENERAL METHODOLOGICAL SOURCE | 2026 article/preprint-style source | NOT FOUND | Moderate; smaller but clinically targeted | CANDIDATE — DISCOVERY ONLY |
| C6 | Multi-Domain Red Teaming Framework | SAFETY_INSTRUMENT | VC-SAFE, VC-SYS, VC-HUMAN | Yes, 690 evaluated scenarios from 1,500 prepared  (Feier et al., 2026)| GENERAL METHODOLOGICAL SOURCE | 2026 article/preprint-style source | NOT FOUND | High for broad safety taxonomy | CANDIDATE — DISCOVERY ONLY |
| C7 | DAS Dynamic Red-Teaming | SAFETY_INSTRUMENT | VC-SAFE, VC-TECH, VC-SYS | Yes, dynamic mutated health test cases  (Pan et al., 2025)| GENERAL METHODOLOGICAL SOURCE | GitHub code link reported  (Pan et al., 2025)| NOT FOUND | High for robustness methodology | CANDIDATE — DISCOVERY ONLY |
| C8 | Summarization Safety Framework | EVALUATOR_INSTRUMENT | VC-SAFE, VC-HUMAN, VC-TECH | Uses ACI Bench plus clinician annotation framework  (Asgari et al., 2025)| GENERAL METHODOLOGICAL SOURCE | NPJ Digital Medicine article | NOT FOUND | High for error taxonomy and clinician review design | CANDIDATE — DISCOVERY ONLY |
| C9 | Source-Verified Clinical AI Framework | TECHNICAL_VALIDATION_INSTRUMENT | VC-TECH, VC-SYS | No released cases demonstrated  (Alu & Oluwadare, 2026)| GENERAL METHODOLOGICAL SOURCE | Frontiers article | Copyright noted only  (Alu & Oluwadare, 2026)| High for provenance architecture, not a benchmark | CANDIDATE — DISCOVERY ONLY |
| C10 | Citation-Enforced Prompting in RAG | TECHNICAL_VALIDATION_INSTRUMENT | VC-TECH | Uses MedQA USMLE benchmark N=500  (Pawlik & Deniziak, 2026)| GENERAL METHODOLOGICAL SOURCE | Applied Sciences article | NOT FOUND | High for grounding metrics | CANDIDATE — DISCOVERY ONLY |
| C11 | Provenance Gap / HEG-TKG | TECHNICAL_VALIDATION_INSTRUMENT | VC-TECH, VC-HUMAN, VC-SAFE | Yes, 36 clinician-validated scenarios, but rare-disease not oncology  (Ahmed et al., 2026)| GENERAL METHODOLOGICAL SOURCE | arXiv article | NOT FOUND | High for citation verification protocol | CANDIDATE — DISCOVERY ONLY |
| C12 | ClinicBot | TECHNICAL_VALIDATION_INSTRUMENT | VC-TECH, VC-SYS | No released case bank shown; real-patient diabetes questions mentioned  (Nananukul & Kejriwal, 2026)| GENERAL METHODOLOGICAL SOURCE | ACM proceedings | NOT FOUND | Moderate for refusal/grounding design | CANDIDATE — DISCOVERY ONLY |
| C13 | EvoMDT | TECHNICAL_VALIDATION_INSTRUMENT | VC-TECH, VC-CLIN, VC-HUMAN | Uses public QA benchmarks and real-world datasets, not shown as released gastric cases  (Liu et al., 2026)| ONCOLOGY ANALOG | NPJ Digital Medicine article | NOT FOUND | Moderate-high for MDT-style evaluation dimensions | CANDIDATE — DISCOVERY ONLY |
| C14 | ESMO Gastric Guideline 2022 | BACKGROUND_CLINICAL_REFERENCE | VC-CLIN | No | DIRECT GASTRIC RELEVANCE | Annals of Oncology guideline | NOT FOUND | High as source standard only | BACKGROUND ONLY |
| C15 | NCCN Gastric 2022 | BACKGROUND_CLINICAL_REFERENCE | VC-CLIN | No | DIRECT GASTRIC RELEVANCE | JNCCN guideline | NOT FOUND | High as source standard only | BACKGROUND ONLY |
| C16 | NCCN Gastric 2025 | BACKGROUND_CLINICAL_REFERENCE | VC-CLIN | No | DIRECT GASTRIC RELEVANCE | JNCCN guideline | NOT FOUND | High as updated source standard only | BACKGROUND ONLY |
| C17 | JGCA Guidelines 2018 | BACKGROUND_CLINICAL_REFERENCE | VC-CLIN | Contains clinical questions, **not case bank**  (Association, 2020)| DIRECT GASTRIC RELEVANCE | Gastric Cancer guideline | NOT FOUND | High as reference standard only | BACKGROUND ONLY |
| C18 | JGCA Margin Validation Study | BACKGROUND_CLINICAL_REFERENCE | VC-CLIN | No released case bank | DIRECT GASTRIC RELEVANCE | Annals of Surgical Oncology | NOT FOUND | Narrow disease-specific evidence reference | BACKGROUND ONLY |

**Figure 1:** Candidate materials classified by primary Phase 6 discovery role, gastric relevance, and discovery-stage governance status.

## Actual Case Sources

The strongest **actual case-containing** materials in the supplied set are the retrospective 98-case oncology comparison study and the prospective 106-case MDT vignette study, because both describe real oncology cases with case-level review rather than only abstract methodology  (Hernandez-Flores et al., 2025; Pinninti et al., 2026).

The 20-case GI-oncology agent paper contains realistic case journeys, but the cases were **generated by the researchers**, so it should not be represented as real clinical source evidence  (Ferber et al., 2025).

- **C1**: Real retrospective oncologic cases with comprehensive documentation, suitable as a discovery-stage case source  (Hernandez-Flores et al., 2025).
- **C2**: Real MDT cases reformatted into de-identified standardized vignettes, with safety and concordance review  (Pinninti et al., 2026).
- **C3**: **RESEARCH-GENERATED SAFETY / EVALUATION MATERIAL**, not a real clinical case source  (Ferber et al., 2025).

## Dataset / Benchmark Sources

Several materials are valuable as datasets or benchmark substrates, but most are **not gastric-specific** and many are methodological rather than directly reusable case banks. The strongest supplied benchmark-style resources emphasize safety prompts, clinician-validated scenarios, or public oncology QA evaluation rather than released gastric adenocarcinoma vignettes  (Chen et al., 2025; Ahmed et al., 2026; Liu et al., 2026).

| ID | Material | Why It Matters | Limits |
|---|---|---|---|
| D1 | CARES | 18,000 clinically specific prompts across harm levels and prompting styles  (Chen et al., 2025)| Research-generated safety material, not real oncology cases |
| D2 | DAS | Dynamic mutation framework exposes brittleness beyond static benchmark scores  (Pan et al., 2025)| General health, not gastric oncology |
| D3 | HEG-TKG scenarios | 36 clinician-validated scenarios with explicit citation-verification protocol  (Ahmed et al., 2026)| Rare neuromuscular diseases, not oncology |
| D4 | EvoMDT inputs | Evaluated on six public oncology QA benchmarks and four real-world datasets  (Liu et al., 2026)| Benchmark names and licenses not given here |
| D5 | MedQA-based RAG testbed | 500-item benchmark for grounding evaluation  (Pawlik & Deniziak, 2026)| General medical exam QA, not oncology |

**Figure 2:** Benchmark-style materials in the supplied set mostly support safety or technical validation, not direct gastric case acquisition.

## Evaluator Instruments

The clearest evaluator instruments are structured scoring systems that separate **clinical correctness, safety, hallucination, grounding, and human review** rather than relying on one aggregate metric. This is consistent across clinician-reviewed summarization, rare-disease citation verification, prospective oncology safety review, and multi-domain oncology/medical red-teaming  (Asgari et al., 2025; Ahmed et al., 2026; Pinninti et al., 2026; Feier et al., 2026; Liu et al., 2026).

- The summarization framework defines **hallucination and omission taxonomies** and distinguishes major from minor clinical errors  (Asgari et al., 2025).
- The HEG-TKG protocol scores verifiability, actionability, temporal precision, non-expert safety, and completeness  (Ahmed et al., 2026).
- The prospective MDT study uses a predefined **safe / safe with caution / not safe** framework independent of concordance  (Pinninti et al., 2026).

## Safety Instruments

The supplied safety literature is strong on **research-generated adversarial evaluation material**. None of these should be treated as real oncology patient cases, but they are suitable discovery-stage inputs for VC-SAFE design because they provide attack taxonomies, graded harm structures, and mutation-based stress testing  (Ekram, 2026; Chen et al., 2025; Feier et al., 2026; Pan et al., 2025).

The red-team sources emphasize different strengths: authority-impersonation failure analysis in clinical assistants, large-scale medical safety prompt coverage, broad multi-domain medical-LLM stress testing, and dynamic adversarial mutation that reveals major benchmarking gaps  (Ekram, 2026; Chen et al., 2025; Feier et al., 2026; Pan et al., 2025).

## Technical Validation Instruments

The most relevant technical instruments focus on **provenance, citation fidelity, grounding enforcement, and auditable traceability** rather than raw accuracy alone. This aligns well with VC-TECH and VC-SYS needs for evidence-linked oncology outputs  (Alu & Oluwadare, 2026; Pawlik & Deniziak, 2026; Nananukul & Kejriwal, 2026; Liu et al., 2026).

| ID | Material | Technical Contribution | Case Status |
|---|---|---|---|
| T1 | Source-Verified Clinical AI Framework | Provenance metadata, evidence grading, audit logging, claim-source linkage  (Alu & Oluwadare, 2026)| NOT A CASE SOURCE |
| T2 | Citation-Enforced Prompting | Unsupported Sentence Ratio and strict citation prompting on MedQA RAG  (Pawlik & Deniziak, 2026)| NOT A CASE SOURCE |
| T3 | Provenance Gap / HEG-TKG | Multi-model citation verification and 100% evidence verifiability in controlled comparison  (Ahmed et al., 2026)| Scenario-based, non-oncology |
| T4 | ClinicBot | Claim-level citation requirement, exact numeric matching, refusal when evidence is insufficient  (Nananukul & Kejriwal, 2026)| NOT A CASE SOURCE |
| T5 | EvoMDT | Traceable guideline-linked multi-agent oncology reasoning and clinician-rated appropriateness/usability  (Liu et al., 2026)| Benchmark/system paper |

**Figure 3:** Technical validation materials in the set mainly support provenance, citation fidelity, and traceability screening rather than direct case sourcing.

## Background Clinical References

The gastric guidelines are **BACKGROUND_CLINICAL_REFERENCE — NOT A CASE SOURCE**. ESMO applies formal evidence grading and living updates, NCCN highlights biomarker testing and advanced-disease management, and JGCA explicitly structures guideline clinical questions with evidence levels and recommendation strength, but none are shown here as released case banks  (Lordick et al., 2022; Ajani et al., 2022; Ajani et al., 2025; Association, 2020).

A disease-specific outcomes study can support source standards or adjudication anchors, but it remains a **background evidence reference**, not a validation case source  (Maspero et al., 2022).

## Conflicts / Contradictions

No explicit cross-source contradiction is stated in the supplied excerpts for a named material such as dataset contents, gastric-case inclusion, or license terms. However, several items remain unresolved because the excerpts do not establish public release, dataset composition, or reuse terms, so they require manual verification rather than inference  (Pinninti et al., 2026; Ferber et al., 2025; Pan et al., 2025).

## Provenance Audit

Many core bibliographic fields are present for journal, year, and authorship, but **DOI, PMID/PMCID, dataset ID, repository version, and license details are frequently absent** in the supplied text and therefore remain NOT FOUND. Provenance is strongest where a paper explicitly describes source attribution, audit logging, supplementary methods, or repository links  (Alu & Oluwadare, 2026; Pinninti et al., 2026; Pan et al., 2025).

## License / Reuse Audit

License and reuse terms are largely **not reported** in the excerpts for case and benchmark candidates, so direct-use versus derivative-use decisions cannot be cleared from the supplied evidence alone. One exception is the RAG systematic review, which is distributed under **CC BY**, but that applies to the review article, not automatically to any underlying datasets it discusses  (Amugongo et al., 2025).

## Gastric-Specific Gaps

The biggest gap is the lack of a **released gastric adenocarcinoma case bank** in the supplied materials. Gastric-specific evidence is strong for reference standards through NCCN, ESMO, JGCA, and a margin-validation study, but weak for direct case-source availability  (Ajani et al., 2025; Lordick et al., 2022; Association, 2020; Maspero et al., 2022).

A second gap is that most safety and provenance instruments are **general medical or non-gastric**. They are still useful as oncology or methodological analogs, but they should not be misrepresented as direct gastric validation material  (Chen et al., 2025; Ahmed et al., 2026; Nananukul & Kejriwal, 2026).

## Recommended Shortlist

- **A. Direct candidate case sources:** C1, C2  (Hernandez-Flores et al., 2025; Pinninti et al., 2026).
- **B. Dataset/benchmark sources:** C4, C7, C11, C13  (Chen et al., 2025; Pan et al., 2025; Ahmed et al., 2026; Liu et al., 2026).
- **C. Evaluator instruments:** C8, C11, C2  (Asgari et al., 2025; Ahmed et al., 2026; Pinninti et al., 2026).
- **D. Safety instruments:** C4, C5, C6, C7  (Chen et al., 2025; Ekram, 2026; Feier et al., 2026; Pan et al., 2025).
- **E. Technical validation instruments:** C9, C10, C11, C12, C13  (Alu & Oluwadare, 2026; Pawlik & Deniziak, 2026; Ahmed et al., 2026; Nananukul & Kejriwal, 2026; Liu et al., 2026).
- **F. Background references:** C14, C15, C16, C17, C18  (Lordick et al., 2022; Ajani et al., 2022; Ajani et al., 2025; Association, 2020; Maspero et al., 2022).

## Governance Status

Direct gastric case sourcing is **not yet satisfied** by the supplied set; current materials are discovery-stage inputs only. The most defensible near-term package is a combination of oncology analog case sources, safety instruments, provenance evaluators, and gastric clinical references, all held at **CANDIDATE — DISCOVERY ONLY** or **BACKGROUND ONLY** until manual provenance and license review is completed  (Alu & Oluwadare, 2026)<paper
 
_These search results were found and analyzed using Consensus, an AI-powered search engine for research. Try it at https://consensus.app. © 2026 Consensus NLP, Inc. Personal, non-commercial use only; redistribution requires copyright holders’ consent._
 
## References
 
Ahmed, M. S., Dusanic, M., Kirschner, M. N., Nyoungui, E., Zschüntzsch, J., Poech, L. G., & Röttger, R. (2026). The Provenance Gap in Clinical AI: Evidence-Traceable Temporal Knowledge Graphs for Rare Disease Reasoning. *ArXiv, abs/2604.17114*. https://doi.org/10.48550/arxiv.2604.17114
 
Ajani, J. A., D'Amico, T. A., Bentrem, D., Corvera, C., Das, P., Enzinger, P. C., Enzler, T., Gerdes, H., Gibson, M. K., Grierson, P., Gupta, G., Hofstetter, W., Ilson, D., Jalal, S., Kim, S. S., Kleinberg, L., Klempner, S., Lacy, J., Lee, B., . . . Stein, M. (2025). Gastric Cancer, Version 2.2025, NCCN Clinical Practice Guidelines In Oncology.. *Journal of the National Comprehensive Cancer Network : JNCCN, 23 5*, 169-191. https://doi.org/10.6004/jnccn.2025.0022
 
Ajani, J., D’amico, T., Bentrem, D., Chao, J., Cooke, D., Corvera, C., Das, P., Enzinger, P., Enzler, T., Fanta, P., Farjah, F., Gerdes, H., Gibson, M., Hochwald, S., Hofstetter, W., Ilson, D., Keswani, R., Kim, S. S., Kleinberg, L., . . . Pluchino, L. (2022). Gastric Cancer, Version 2.2022, NCCN Clinical Practice Guidelines in Oncology.. *Journal of the National Comprehensive Cancer Network : JNCCN, 20 2*, 167-192. https://doi.org/10.6004/jnccn.2022.0008
 
Alu, F., & Oluwadare, S. (2026). An auditable and source-verified framework for clinical AI decision support: integrating retrieval-augmented generation with data provenance. *Frontiers in Artificial Intelligence, 9*. https://doi.org/10.3389/frai.2026.1737532
 
Amugongo, L. M., Mascheroni, P., Brooks, S., Doering, S., & Seidel, J. (2025). Retrieval augmented generation for large language models in healthcare: A systematic review. *PLOS Digital Health, 4*. https://doi.org/10.1371/journal.pdig.0000877
 
Asgari, E., Brown, N., Dubois, M., Khalil, S., Balloch, J., Yeung, J. A., & Pimenta, D. (2025). A framework to assess clinical safety and hallucination rates of LLMs for medical text summarisation. *NPJ Digital Medicine, 8*. https://doi.org/10.1038/s41746-025-01670-7
 
Association, J. G. C. (2020). Japanese gastric cancer treatment guidelines 2018 (5th edition). *Gastric Cancer, 24*, 1 - 21. https://doi.org/10.1007/s10120-020-01042-y
 
Chen, S., Li, X., Zhang, M., Jiang, E. H., Zeng, Q., & Yu, C. (2025). CARES: Comprehensive Evaluation of Safety and Adversarial Robustness in Medical LLMs. *ArXiv, abs/2505.11413*. https://doi.org/10.48550/arxiv.2505.11413
 
Ekram, T. (2026). Red-Teaming Medical AI: Systematic Adversarial Evaluation of LLM Safety Guardrails in Clinical Contexts. https://doi.org/10.64898/2026.02.26.26347212
 
Feier, A.-M., Kocaman, V., Gul, Y., Korkmaz, A., Thomas, A. S., Zakharov, A., Gil, J., Butgul, M., & Talby, D. (2026). A Multi-Domain Red Teaming Framework for Safety, Robustness, and Fairness Evaluation of Medical Large Language Models. https://doi.org/10.48550/arxiv.2606.00027
 
Ferber, D., Nahhas, O. E. E., Wölflein, G., Wiest, I., Clusmann, J., Leßmann, M., Foersch, S., Lammert, J., Tschochohei, M., Jaeger, D., Salto-Tellez, M., Schultz, N., Truhn, D., & Kather, J. (2025). Development and validation of an autonomous artificial intelligence agent for clinical decision-making in oncology. *Nature Cancer, 6*, 1337 - 1349. https://doi.org/10.1038/s43018-025-00991-6
 
Hernandez-Flores, L. A., López-Martínez, J. B., Rosales-De-La-Rosa, J. J., Aillaud-De-Uriarte, D., Contreras-Garduño, S., & Cortés-González, R. (2025). Assessment of Challenging Oncologic Cases: A Comparative Analysis Between ChatGPT, Gemini, and a Multidisciplinary Tumor Board. *Journal of Surgical Oncology, 131*. https://doi.org/10.1002/jso.28121
 
Liu, Q., Hu, Z., Huang, T., Niu, Y., Zhang, X., S., Lin, C., Huat, G. K., Kwon, H. E., Gao, F., Sun, X., Ying, Z., & Qiang, G. (2026). EvoMDT: a self-evolving multi-agent system for structured clinical decision-making in multi-cancer. *NPJ Digital Medicine, 9*. https://doi.org/10.1038/s41746-025-02304-8
 
Lordick, F., Carneiro, F., Cascinu, S., Fleitas, T., Haustermans, K., Piessen, G., Vogel, A., & Smyth, E. (2022). Gastric cancer: ESMO Clinical Practice Guideline for diagnosis, treatment and follow-up.. *Annals of oncology : official journal of the European Society for Medical Oncology*. https://doi.org/10.1016/j.annonc.2022.07.004
 
Maspero, M., Sposito, C., Benedetti, A., Virdis, M., Di Bartolomeo, M., Milione, M., & Mazzaferro, V. (2022). Impact of Surgical Margins on Overall Survival after Gastrectomy for Gastric Cancer: A Validation of Japanese Gastric Cancer Association Guidelines on a Western Series. *Annals of Surgical Oncology, 29*, 3096 - 3108. https://doi.org/10.1245/s10434-021-11010-0
 
Nananukul, N., & Kejriwal, M. (2026). ClinicBot: A Guideline-Grounded Clinical Chatbot with Prioritized Evidence RAG and Verifiable Citations. *Proceedings of the ACM Conference on AI and Agentic Systems*. https://doi.org/10.1145/3786335.3813224
 
Pan, J., Jian, B., Hager, P., Zhang, Y., Liu, C., Jungmann, F., Li, H., You, C., Wu, J., Zhu, J., Liu, F., Liu, Y., Bubeck, N., Wachinger, C., Chen, C., Gong, Z., Cheng, O., Kaissis, G., Wiestler, B., & Rueckert, D. (2025). Addressing Benchmarking Gaps in Large Language Models for Health and Medicine with Dynamic Red-Teaming. https://doi.org/10.48550/arxiv.2508.00923
 
Pawlik, L., & Deniziak, S. (2026). Reducing Hallucinations in Medical AI Through Citation Enforced Prompting in RAG Systems. *Applied Sciences*. https://doi.org/10.3390/app16063013
 
Pinninti, R., Gullapalli, R., Mallavarapu, K. M., Singareddy, R., Nekkanti, S. S., Nikhil, P., Shukla, S., Hariharan, N., Gudipudi, D., Suseela, K., Koppula, V., Rao, T., & Rajappa, S. (2026). Comparing artificial intelligence and multidisciplinary tumor board decision making in real-world cancer care: a prospective blinded concordance study. *ESMO Real World Data and Digital Oncology, 11*. https://doi.org/10.1016/j.esmorw.2026.100688
 
