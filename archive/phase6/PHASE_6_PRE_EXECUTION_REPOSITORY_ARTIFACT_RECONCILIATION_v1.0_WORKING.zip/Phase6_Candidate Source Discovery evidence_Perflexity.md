<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

## 1. Search Scope

This discovery sweep targeted publicly documented materials that could serve as **candidate inputs** for Phase 6 validation of a Safe Medical AI Oncology system, with a gastric-oncology priority. Searches covered: (A) published clinical case/vignette sources; (B) oncology datasets/benchmarks with patient-level cases; (C) evaluator instruments and rubrics; (D) safety/red-team taxonomies and datasets; (E) technical validation frameworks for RAG/faithfulness/attribution; and (F) clinical reference sources (guidelines, society resources).[^1][^2][^3][^4][^5][^6][^7][^8][^9][^10][^11][^12][^13][^14][^15][^16][^17][^18][^19][^20][^21][^22][^23][^24][^25][^26][^27][^28][^29]

## 2. Candidate Source Inventory

| ID | Material | Primary Type | Validation Family | Case/Scenario Present? | Gastric Relevance | Provenance | License | Sufficiency | Status |
| :-- | :-- | :-- | :-- | :-- | :-- | :-- | :-- | :-- | :-- |
| S01 | MTBBench (NeurIPS 2025 D\&B) | DATASET_BENCHMARK | VC-TECH, VC-CLIN | Yes (oncology cases from HANCOCK \& MSK-CHORD) | ONCOLOGY ANALOG (no gastric) | arXiv:2511.20490; HF dataset; NeurIPS 2025 | CC BY 4.0 (HANCOCK subset); CC BY-NC-ND 4.0 (MSK-CHORD subset) | High for multimodal/longitudinal oncology QA | CANDIDATE — DISCOVERY ONLY |
| S02 | HANCOCK dataset (Head \& Neck Cancer) | DATASET_BENCHMARK | VC-TECH, VC-CLIN | Yes (763 patient records) | ONCOLOGY ANALOG (H\&N, not gastric) | Nature Communications 2025; https://hancock.research.fau.eu | Public (research use) | High for multimodal ML; not gastric | CANDIDATE — DISCOVERY ONLY |
| S03 | MSK-CHORD (clinicogenomic, 24,950 pts) | DATASET_BENCHMARK | VC-TECH, VC-CLIN | Yes (summary/structured patient data) | ONCOLOGY ANALOG (NSCLC, breast, CRC, prostate, pancreas) | MSK data catalog; Nature 2024 companion | CC BY-NC-ND 4.0 | High for clinicogenomic modeling; no gastric | CANDIDATE — DISCOVERY ONLY |
| S04 | LungCURE (1,000 real lung cancer cases) | DATASET_BENCHMARK | VC-TECH, VC-CLIN | Yes (1,000 clinician-labeled cases) | ONCOLOGY ANALOG (lung only) | arXiv:2604.06925; HF dataset | Not explicitly stated in snippets | High for TNM/treatment tasks; non-gastric | CANDIDATE — DISCOVERY ONLY |
| S05 | BioASQ-QA benchmark | DATASET_BENCHMARK | VC-TECH, VC-CLIN | Yes (biomedical QA items) | GENERAL METHODOLOGICAL SOURCE | PMC10042099; IEEE DataPort compilation | Varies by task/year (public) | Moderate for biomedical QA; not clinical vignettes | CANDIDATE — DISCOVERY ONLY |
| S06 | MedSafetyBench (1,800 harmful medical requests + safe responses) | SAFETY_INSTRUMENT | VC-SAFE | Yes (prompt–response pairs) | GENERAL METHODOLOGICAL SOURCE | arXiv:2403.03744; GitHub; HF mirror | Research-use (dataset of prompts/responses) | High for safety refusal evaluation | CANDIDATE — DISCOVERY ONLY |
| S07 | PatientSafetyBench (Microsoft) | SAFETY_INSTRUMENT | VC-SAFE | Yes (synthetic patient-style prompts) | GENERAL METHODOLOGICAL SOURCE | HF dataset; arXiv/EAACL 2026 paper | Not specified in snippets | Moderate–High for safety categories | CANDIDATE — DISCOVERY ONLY |
| S08 | TACOS taxonomy + annotated dataset | SAFETY_INSTRUMENT | VC-SAFE | Yes (taxonomy + annotated queries) | GENERAL METHODOLOGICAL SOURCE | arXiv:2509.22041; ACL 2025 Industry | Not specified in snippets | Moderate for safety taxonomy coverage | CANDIDATE — DISCOVERY ONLY |
| S09 | RedBench (29,362 adversarial samples) | SAFETY_INSTRUMENT | VC-SAFE | Yes (adversarial prompts with risk/domain labels) | GENERAL METHODOLOGICAL SOURCE | arXiv:2601.03699 | Not specified in snippets | High breadth; not medical-specific | CANDIDATE — DISCOVERY ONLY |
| S10 | MPIB (Medical Prompt Injection Benchmark) | SAFETY_INSTRUMENT | VC-SAFE | Yes (9,697 curated instances) | GENERAL METHODOLOGICAL SOURCE | arXiv:2602.06268 | Not specified in snippets | High for prompt-injection safety | CANDIDATE — DISCOVERY ONLY |
| S11 | Bio-GRACE (evidence-benefit diagnostic for biomedical RAG) | TECHNICAL_VALIDATION_INSTRUMENT | VC-TECH | No (framework + evaluation protocol) | GENERAL METHODOLOGICAL SOURCE | arXiv:2608.01409 | Not specified in snippets | High for evidence fidelity | CANDIDATE — DISCOVERY ONLY |
| S12 | Entity Attribution Failure (deceptive grounding) benchmark | TECHNICAL_VALIDATION_INSTRUMENT | VC-TECH | Yes (controlled factorial benchmark across 13 models) | GENERAL METHODOLOGICAL SOURCE | arXiv:2607.09349 | Not specified in snippets | High for attribution correctness | CANDIDATE — DISCOVERY ONLY |
| S13 | RAGAS / ARES / RAGChecker (tool suites) | TECHNICAL_VALIDATION_INSTRUMENT | VC-TECH | No (evaluation frameworks) | GENERAL METHODOLOGICAL SOURCE | Cited in Bio-GRACE paper | Varies by tool | High for faithfulness/relevance | CANDIDATE — DISCOVERY ONLY |
| S14 | AMEGA-LLM benchmark (guideline adherence) | EVALUATOR_INSTRUMENT | VC-CLIN, VC-TECH | Yes (20 cases with rubrics) | ONCOLOGY ANALOG (colon carcinoma case included) | GitHub: DATEXIS/AMEGA-benchmark | Not specified in snippets | Moderate for guideline adherence scoring | CANDIDATE — DISCOVERY ONLY |
| S15 | NCCN decision-tree–derived MedGUIDE (LLM-generated MCQs) | EVALUATOR_INSTRUMENT | VC-CLIN, VC-TECH | Yes (MCQs derived from 55 NCCN trees) | ONCOLOGY ANALOG (17 cancer types) | OpenReview PDF (Benchmarking Clinical Decision-Making in LLMs) | Not specified in snippets | Moderate for guideline-based QA | CANDIDATE — DISCOVERY ONLY |
| S16 | ACG Clinical Vignettes (Stomach/Gastric case reports) | CASE_SOURCE | VC-CLIN | Yes (published gastric vignettes) | DIRECT GASTRIC RELEVANCE | Am J Gastroenterol (multiple years; e.g., 2011, 2016, 2019, 2020) | Publisher copyright; abstracts free | Low–Moderate (single-case reports; not structured QA) | CANDIDATE — DISCOVERY ONLY |
| S17 | “Evidence bound clinical decision support with RAG” (Journal of Polytechnic) | TECHNICAL_VALIDATION_INSTRUMENT | VC-TECH | No (framework + evaluation protocol) | GENERAL METHODOLOGICAL SOURCE | Journal of Polytechnic (peer-reviewed) | Not specified in snippets | Moderate for evidence-bound RAG | CANDIDATE — DISCOVERY ONLY |
| S18 | NCCN / ESMO / ASCO / JGCA / TNCD gastric guidelines | BACKGROUND_CLINICAL_REFERENCE | VC-CLIN | NOT A CASE SOURCE (guidelines) | DIRECT GASTRIC RELEVANCE | Society publications (various years) | Society-specific (often restricted) | High as reference standard; not cases | BACKGROUND ONLY |

## 3. Actual Case Sources

- **S16 — ACG Clinical Vignettes (Stomach/Gastric)**: Multiple published gastric cancer vignettes exist (e.g., metastatic gastric adenocarcinoma presenting as Blumer’s shelf; gastric small cell carcinoma; rare gastric cancer forms).  These are **real published clinical case reports**, but they are narrative, single-case formats without structured QA or decision-point annotations.[^30][^31][^32][^33]
**Governance Status:** CANDIDATE — DISCOVERY ONLY; POTENTIALLY USABLE — GOVERNANCE REVIEW REQUIRED (for extraction/annotation).


## 4. Dataset / Benchmark Sources

- **S01 — MTBBench**: Oncology benchmark built from subsets of HANCOCK (head \& neck) and MSK-CHORD (multi-cancer clinicogenomic). Contains multimodal, longitudinal decision questions with clinician-validated ground truth.[^2][^5][^34][^35][^1]
**Gastric relevance:** ONCOLOGY ANALOG (no gastric-specific cases stated).
**License:** CC BY 4.0 (HANCOCK subset); CC BY-NC-ND 4.0 (MSK-CHORD subset).[^1]
**Status:** CANDIDATE — DISCOVERY ONLY.
- **S02 — HANCOCK**: 763 head \& neck cancer patients with multimodal data (clinical, pathology, blood, surgery reports, histology).[^17][^36][^37][^38][^39][^40][^41]
**Gastric relevance:** ONCOLOGY ANALOG.
**Status:** CANDIDATE — DISCOVERY ONLY.
- **S03 — MSK-CHORD**: ~24,950 patients across NSCLC, breast, colorectal, prostate, pancreatic cancers; clinicogenomic with NLP-derived annotations.[^19][^42][^43][^44][^45]
**Gastric relevance:** ONCOLOGY ANALOG (pancreatic included; gastric not listed).
**License:** CC BY-NC-ND 4.0.[^43][^45]
**Status:** CANDIDATE — DISCOVERY ONLY.
- **S04 — LungCURE**: 1,000 real-world lung cancer cases from >10 hospitals in China; tasks include TNM staging, treatment recommendation, end-to-end CDS.[^4][^25][^26][^29][^46][^47][^48]
**Gastric relevance:** ONCOLOGY ANALOG (lung only).
**Status:** CANDIDATE — DISCOVERY ONLY.
- **S05 — BioASQ-QA**: Biomedical QA benchmark with questions, gold answers, and supporting material.[^18][^20][^21]
**Gastric relevance:** GENERAL METHODOLOGICAL SOURCE.
**Status:** CANDIDATE — DISCOVERY ONLY.


## 5. Evaluator Instruments

- **S14 — AMEGA-LLM**: 20 cases with detailed rubrics for guideline adherence; includes an oncology/gastroenterology case (colon carcinoma).[^6]
**Gastric relevance:** ONCOLOGY ANALOG.
**Status:** CANDIDATE — DISCOVERY ONLY.
- **S15 — MedGUIDE (NCCN decision-tree–derived MCQs)**: Constructed from 55 NCCN decision trees across 17 cancer types; LLM-generated MCQs for diagnostic scenarios.[^49]
**Gastric relevance:** ONCOLOGY ANALOG (depends on tree coverage).
**Status:** CANDIDATE — DISCOVERY ONLY; REQUIRES MANUAL REVIEW (to confirm gastric coverage and licensing).


## 6. Safety Instruments

- **S06 — MedSafetyBench**: 1,800 harmful medical requests + safe responses (GPT-4 and Llama-2 generated).[^13][^24][^27][^50][^51][^52]
**Gastric relevance:** GENERAL METHODOLOGICAL SOURCE.
**Status:** CANDIDATE — DISCOVERY ONLY.
- **S07 — PatientSafetyBench**: Synthetic patient-style prompts across safety categories (e.g., harmful/dangerous medical advice, misdiagnosis).[^23][^28]
**Status:** CANDIDATE — DISCOVERY ONLY.
- **S08 — TACOS**: 21-class safety taxonomy for clinical agents; includes an annotated dataset.[^12][^22]
**Status:** CANDIDATE — DISCOVERY ONLY.
- **S09 — RedBench**: 29,362 adversarial prompts with risk category + domain labels.[^14]
**Status:** CANDIDATE — DISCOVERY ONLY.
- **S10 — MPIB**: 9,697 curated medical prompt-injection instances.[^8]
**Status:** CANDIDATE — DISCOVERY ONLY.


## 7. Technical Validation Instruments

- **S11 — Bio-GRACE**: Gold-reference–normalized diagnostic for evidence benefit in biomedical RAG.[^9]
**Status:** CANDIDATE — DISCOVERY ONLY.
- **S12 — Entity Attribution Failure (Deceptive Grounding)**: Controlled benchmark showing entity-attribution failures in clinical RAG; proposes entity-attribution verification.[^11]
**Status:** CANDIDATE — DISCOVERY ONLY.
- **S13 — RAGAS / ARES / RAGChecker**: Tool suites measuring relevance, faithfulness, correctness, and attribution.[^9]
**Status:** CANDIDATE — DISCOVERY ONLY.
- **S17 — Evidence-bound RAG framework (Journal of Polytechnic)**: Modular RAG with citation-aware prompting, abstention policy, and preregistered evaluation protocol.[^16]
**Status:** CANDIDATE — DISCOVERY ONLY.


## 8. Background Clinical References

- **S18 — NCCN / ESMO / ASCO / JGCA / TNCD gastric guidelines**: Authoritative treatment/staging references.[^49][^9]
**Classification:** BACKGROUND_CLINICAL_REFERENCE — NOT A CASE SOURCE.
**Status:** BACKGROUND ONLY.


## 9. Conflicts / Contradictions

- **MTBBench gastric coverage**: Snippets describe MTBBench as an oncology benchmark using HANCOCK (head \& neck) and MSK-CHORD (NSCLC, breast, CRC, prostate, pancreas).  No snippet states gastric cases are included. However, one snippet broadly calls MTBBench an “oncology” benchmark without specifying tumor types.[^5][^34][^35][^2][^1]
**CONFLICT DETECTED:** Whether MTBBench includes any gastric cases is unclear from snippets.
**Resolution:** REQUIRES MANUAL REVIEW via the MTBBench paper/supplement and dataset card. Do not record “gastric cases present” as fact.
- **MedGUIDE gastric coverage**: Described as built from 55 NCCN decision trees across 17 cancer types.  It is not specified which 17 types; gastric may or may not be included.[^49]
**CONFLICT DETECTED:** Gastric inclusion is unspecified.
**Resolution:** REQUIRES MANUAL REVIEW of the MedGUIDE source/supplement.


## 10. Provenance Audit

- **MTBBench**: arXiv:2511.20490 (2025); NeurIPS 2025 D\&B; Hugging Face dataset (EeshaanJain/MTBBench).[^34][^35][^2][^5][^1]
- **HANCOCK**: Nature Communications 2025; project site https://hancock.research.fau.eu; TCIA collection.[^36][^37][^38][^39][^17]
- **MSK-CHORD**: MSK data catalog entry (2025); Nature 2024 community post; cBioPortal access noted.[^42][^44][^45][^19][^43]
- **LungCURE**: arXiv:2604.06925 (2026); Hugging Face dataset (Fine2378/LungCURE).[^25][^26][^29][^46][^47][^48][^4]
- **BioASQ-QA**: PMC10042099 (2023); IEEE DataPort compilation; BioASQ participant datasets page.[^20][^21][^18]
- **MedSafetyBench**: arXiv:2403.03744; GitHub (AI4LIFE-GROUP); HF mirrors.[^24][^27][^50][^51][^52][^13]
- **PatientSafetyBench**: HF dataset (microsoft/PatientSafetyBench); EAACL 2026 Industry paper.[^28][^23]
- **TACOS**: arXiv:2509.22041; ACL 2025 Industry PDF.[^22][^12]
- **RedBench**: arXiv:2601.03699.[^14]
- **MPIB**: arXiv:2602.06268.[^8]
- **Bio-GRACE**: arXiv:2608.01409.[^9]
- **Entity Attribution Failure**: arXiv:2607.09349.[^11]
- **AMEGA-LLM**: GitHub (DATEXIS/AMEGA-benchmark).[^6]
- **MedGUIDE**: OpenReview PDF (Benchmarking Clinical Decision-Making in LLMs).[^49]
- **ACG Gastric Vignettes**: American Journal of Gastroenterol (2011, 2016, 2019, 2020 issues).[^31][^32][^33][^30]
- **Evidence-bound RAG**: Journal of Polytechnic (peer-reviewed).[^16]
- **Guidelines (NCCN/ESMO/ASCO/JGCA/TNCD)**: Society publications (various years).[^9][^49]


## 11. License / Reuse Audit

- **MTBBench subsets**: CC BY 4.0 (HANCOCK); CC BY-NC-ND 4.0 (MSK-CHORD).[^1]
- **MSK-CHORD**: CC BY-NC-ND 4.0; commercial use requires permission.[^45][^43]
- **HANCOCK**: Public research access via project site; specific license not detailed in snippets.[^39][^36]
- **LungCURE**: License not explicitly stated in snippets.[^29][^25]
- **BioASQ**: Varies by task/year; generally public benchmark use.[^21][^18]
- **MedSafetyBench / PatientSafetyBench / TACOS / RedBench / MPIB**: Licenses not specified in snippets; likely research-use but require primary-source verification.[^27][^51][^52][^12][^13][^22][^23][^24][^28][^8][^14]
- **Bio-GRACE / Entity Attribution / RAGAS / ARES / RAGChecker**: Licenses not specified in snippets.[^11][^9]
- **AMEGA-LLB / MedGUIDE**: Licenses not specified in snippets.[^6][^49]
- **ACG Vignettes**: Publisher copyright; abstracts free; full text access may require subscription.[^32][^33][^30][^31]
- **Guidelines**: Society-specific; often restricted redistribution.[^9][^49]

**Reuse classification (provisional):**

- **DIRECT USE** (as-is benchmarks): MTBBench, HANCOCK, MSK-CHORD, LungCURE, BioASQ, MedSafetyBench, PatientSafetyBench, TACOS, RedBench, MPIB — subject to license confirmation.
- **DERIVATIVE USE** (case extraction/annotation): ACG gastric vignettes (requires publisher permissions for systematic reuse).
- **METHODOLOGICAL REFERENCE**: Bio-GRACE, Entity Attribution Failure, RAGAS/ARES/RAGChecker, AMEGA-LLM, MedGUIDE, Evidence-bound RAG framework.


## 12. Gastric-Specific Gaps

- No **gastric adenocarcinoma–specific, structured case banks** (with decision points, annotations, and ground-truth actions) were identified in the searched snippets.[^26][^35][^2][^4][^5][^17][^19][^25][^29][^34][^36][^43][^1][^6]
- Existing oncology benchmarks (MTBBench, LungCURE, MSK-CHORD subsets) are **non-gastric** or do not state gastric inclusion.[^35][^2][^5][^19][^25][^26][^29][^34][^43][^1]
- Published gastric case reports exist but are **narrative and unstructured** for validation QA.[^33][^30][^31][^32]
- Guideline sources (NCCN/ESMO/ASCO/JGCA/TNCD) are **background references**, not case sources.[^49][^9]


## 13. Recommended Shortlist

**A. Direct candidate case sources**

- **S16 — ACG Gastric Clinical Vignettes** (for manual curation into structured scenarios; governance review required).[^30][^31][^32][^33]

**B. Dataset/benchmark sources**

- **S01 — MTBBench** (oncology multimodal/longitudinal QA; verify gastric coverage).[^2][^5][^34][^35][^1]
- **S04 — LungCURE** (real-world oncology cases; TNM/treatment tasks; non-gastric).[^46][^4][^25][^26][^29]
- **S02 — HANCOCK** and **S03 — MSK-CHORD** (underlying patient-data sources for MTBBench; non-gastric).[^17][^19][^36][^39][^43]

**C. Evaluator instruments**

- **S14 — AMEGA-LLM** (guideline-adherence rubrics; includes GI/oncology case).[^6]
- **S15 — MedGUIDE** (NCCN-derived MCQs; verify gastric coverage).[^49]

**D. Safety instruments**

- **S06 — MedSafetyBench**, **S07 — PatientSafetyBench**, **S08 — TACOS**, **S10 — MPIB**, **S09 — RedBench** (broad safety/red-team coverage).[^51][^52][^12][^13][^22][^23][^24][^27][^28][^8][^14]

**E. Technical validation instruments**

- **S11 — Bio-GRACE**, **S12 — Entity Attribution Failure**, **S13 — RAGAS/ARES/RAGChecker**, **S17 — Evidence-bound RAG framework**.[^16][^11][^9]

**F. Background references**

- **S18 — NCCN/ESMO/ASCO/JGCA/TNCD gastric guidelines** (as source standards, not cases).[^9][^49]


## 14. Governance Status

- **S01–S05, S07–S15, S17**: CANDIDATE — DISCOVERY ONLY.
- **S16 (ACG vignettes)**: CANDIDATE — DISCOVERY ONLY; POTENTIALLY USABLE — GOVERNANCE REVIEW REQUIRED (for structured extraction and licensing).
- **S18 (Guidelines)**: BACKGROUND ONLY.
- **MTBBench gastric coverage** and **MedGUIDE gastric coverage**: REQUIRES MANUAL REVIEW.[^5][^34][^35][^2][^1][^49]


## 15. Explicit Non-Generation Statement

No Phase 6 validation cases were invented, synthesized, transformed, or fabricated. Candidate materials remain discovery-stage inputs and are not Phase 6 validation evidence.[^52][^4][^12][^13][^18][^19][^20][^21][^22][^23][^24][^25][^26][^27][^28][^29][^34][^35][^36][^43][^2][^5][^8][^14][^17][^1][^11][^16][^6][^9][^49]
<span style="display:none">[^53][^54][^55][^56][^57][^58][^59][^60]</span>

<div align="center">⁂</div>

[^1]: https://arxiv.org/html/2511.20490v1

[^2]: https://arxiv.org/abs/2511.20490

[^3]: https://arxiv.org/abs/2304.05623

[^4]: https://arxiv.org/html/2604.06925v1

[^5]: https://huggingface.co/datasets/EeshaanJain/MTBBench

[^6]: https://github.com/DATEXIS/AMEGA-benchmark/

[^7]: https://pmc.ncbi.nlm.nih.gov/articles/PMC12723766/

[^8]: https://arxiv.org/html/2602.06268

[^9]: https://arxiv.org/html/2608.01409v1

[^10]: https://www.medrxiv.org/content/10.64898/2026.02.26.26347212v1

[^11]: https://arxiv.org/abs/2607.09349

[^12]: https://arxiv.org/pdf/2509.22041.pdf

[^13]: https://arxiv.org/html/2506.12482v2

[^14]: https://arxiv.org/html/2601.03699v1

[^15]: https://www.johnsnowlabs.com/wp-content/uploads/2026/04/LLM-Red-teaming-paper-2026.pdf

[^16]: https://www.linkedin.com/posts/teoman-karadağ-054a49131_i-am-pleased-to-share-our-latest-peer-reviewed-activity-7396766862488969216-KHSu

[^17]: https://www.nature.com/articles/s41467-025-62386-6

[^18]: https://pmc.ncbi.nlm.nih.gov/articles/PMC10042099/

[^19]: https://medicalxpress.com/news/2024-11-automated-approach-silos-cancer-outcomes.html

[^20]: https://ieee-dataport.org/documents/biomedical-question-answer-dataset-medquad-bioasq-task-b-and-pubmedqa

[^21]: https://participants-area.bioasq.org/datasets/

[^22]: https://aclanthology.org/2025.emnlp-industry.124.pdf

[^23]: https://aclanthology.org/2026.eacl-industry.39.pdf

[^24]: https://arxiv.org/html/2403.03744v4

[^25]: https://arxiv.org/html/2604.06925v2

[^26]: https://arxiv.org/abs/2604.06925

[^27]: https://github.com/AI4LIFE-GROUP/med-safety-bench

[^28]: https://huggingface.co/datasets/microsoft/PatientSafetyBench/blob/main/README.md

[^29]: https://huggingface.co/datasets/Fine2378/LungCURE

[^30]: https://journals.lww.com/ajg/fulltext/2011/10002/an_extremely_rare_form_of_gastric_cancer__a_case.491.aspx

[^31]: https://journals.lww.com/ajg/fulltext/2016/10001/blumer_s_shelf__2244.2244.aspx

[^32]: https://journals.lww.com/ajg/abstract/2019/10001/2773_gastric_small_cell_cancer__an_extremely_rare.2774.aspx

[^33]: https://journals.lww.com/ajg/fulltext/2020/10001/s2967_an_unusual_presentation_of_metastatic.2966.aspx

[^34]: https://bsse.ethz.ch/mail/news/medical-ai-lab-news/2025/09/mtbbench-a-multimodal-sequential-clinical-decision-making-benchmark-in-oncology-got-accepted-to-neurips-2025.html

[^35]: https://www.emergentmind.com/papers/2511.20490

[^36]: https://www.medrxiv.org/content/10.1101/2024.05.29.24308141v1

[^37]: https://zenodo.org/records/15084070

[^38]: https://www.cancerimagingarchive.net/collection/hancock/

[^39]: https://hancock.research.fau.eu/

[^40]: https://www.hancock.research.uni-erlangen.org/explore?patient=8

[^41]: https://hancock.research.fau.eu/explore

[^42]: https://www.cancer.gov/about-nci/organization/cbiit/news-events/events/real-world-data-integration-improves-cancer-outcome-prediction

[^43]: https://datacatalog.mskcc.org/dataset/11458

[^44]: https://communities.springernature.com/posts/msk-chord-an-ai-enabled-24-950-patient-clinicogenomic-dataset-for-cancer-research

[^45]: https://datacatalog.ccdi.cancer.gov/dataset/cBioPortal-MSK-CHORD

[^46]: https://arxiv.org/pdf/2604.06925.pdf

[^47]: https://www.alphaxiv.org/overview/2604.06925

[^48]: https://www.layerthelatestinalattice.com/papers/edfa9e382f8ac89ce9bffe927832bb0da6b43627

[^49]: https://openreview.net/pdf/07c2a85f2355803fe92312f6a9808c0e5065ddef.pdf

[^50]: https://huggingface.co/datasets/israel-adewuyi/med-safety-bench-reproduced

[^51]: https://github.com/AI4LIFE-GROUP/med-safety-bench/tree/main

[^52]: https://safetyprompts.com/

[^53]: https://escholarship.org/content/qt49p867zw/qt49p867zw_noSplash_2ce0b6e1fc15ac387ae91f5a7b628d88.pdf?t=ssagko

[^54]: https://journals.viamedica.pl/rpor/article/download/111982/89069

[^55]: https://arxiv.org/pdf/2602.19948.pdf

[^56]: https://labelstud.io/learningcenter/how-to-build-a-red-teaming-dataset/

[^57]: https://www.semdial.org/anthology/Z24-Monaghan_semdial_0035.pdf

[^58]: https://www.linkedin.com/posts/yousseftemraz-digitalhealth_ai-aisafety-healthcareai-activity-7429163263092772866-Ricp

[^59]: https://www.ijasret.com/VolumeArticles/FullTextPDF/1719_IJ_MEDICAL.pdf

[^60]: https://openreview.net/pdf/12a1638233ed711151b702a35d81c3a4572fb475.pdf

