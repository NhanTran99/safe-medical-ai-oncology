# 1. Search Scope

The discovery search scope focuses on identifying existing, published, and verifiable candidate materials to support future **Phase 6 — Validation** activities for a Safe Medical AI Oncology system, prioritizing gastric adenocarcinoma and upper-GI oncology.

* **Target Scope:**
* **Gastric Oncology / Upper-GI Oncology:** Real patient cases, clinical vignettes, tumor board datasets, and consensus guidelines (e.g., NCCN, ESMO, JGCA).
* **General Oncology Benchmarks:** Molecular Tumor Board datasets, oncology QA benchmarks, and multi-specialty clinical case sets.
* **Medical AI & Safety Instruments:** Clinical safety taxonomies, adversarial medical prompt benchmarks, medical hallucination/toxicity evaluation sets.
* **Technical Validation Instruments:** RAG faithfulness, claim-level attribution, citation precision/recall frameworks, and retrieval evaluation tools.


* **Exclusion Criteria:** Unverified secondary summaries, synthesized/invented clinical cases generated ad hoc, and unvetted non-peer-reviewed blog posts.

---

# 2. Candidate Source Inventory

| ID | Material | Primary Type | Validation Family | Case/Scenario Present? | Gastric Relevance | Provenance | License | Sufficiency | Status |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| **SRC-01** | MTB-Bench (Molecular Tumor Board Benchmark) | DATASET_BENCHMARK | VC-CLIN, VC-TECH | YES | ONCOLOGY ANALOG | Peer-reviewed / GitHub | CC BY 4.0 | Sufficient for Benchmark | CANDIDATE — DISCOVERY ONLY |
| **SRC-02** | NCCN Clinical Practice Guidelines in Oncology: Gastric Cancer (v2024/v2025) | BACKGROUND_CLINICAL_REFERENCE | VC-CLIN | NO | DIRECT GASTRIC RELEVANCE | Official NCCN Release | Proprietary / Educational Non-Commercial | Reference Standard Only | BACKGROUND ONLY |
| **SRC-03** | MedQA-USMLE (Oncology Subset) | DATASET_BENCHMARK | VC-CLIN | YES | GENERAL METHODOLOGICAL SOURCE | Open Source / GitHub | MIT License | Partial (General Medical) | CANDIDATE — DISCOVERY ONLY |
| **SRC-04** | MedHALT (Medical Hallucination Test Suite) | TECHNICAL_VALIDATION_INSTRUMENT | VC-TECH, VC-SAFE | YES | GENERAL METHODOLOGICAL SOURCE | Peer-reviewed / GitHub | Apache 2.0 | Sufficient for Hallucination Screening | CANDIDATE — DISCOVERY ONLY |
| **SRC-05** | ESMO Clinical Practice Guideline: Gastric Cancer | BACKGROUND_CLINICAL_REFERENCE | VC-CLIN | NO | DIRECT GASTRIC RELEVANCE | Peer-reviewed (Annals of Oncology) | Open Access / Non-Commercial | Reference Standard Only | BACKGROUND ONLY |
| **SRC-06** | MedSafetyBench / Adversarial Medical Safety Taxonomy | SAFETY_INSTRUMENT | VC-SAFE, VC-HUMAN | YES (Research-Generated) | GENERAL METHODOLOGICAL SOURCE | Peer-reviewed Paper | CC BY-NC 4.0 | Methodological Safety Source | POTENTIALLY USABLE — GOVERNANCE REVIEW REQUIRED |
| **SRC-07** | RAGAS (Retrieval Augmented Generation Assessment) | TECHNICAL_VALIDATION_INSTRUMENT | VC-TECH | NO | GENERAL METHODOLOGICAL SOURCE | Open Source Library | Apache 2.0 | Framework Tooling | CANDIDATE — DISCOVERY ONLY |
| **SRC-08** | PubMedQA (GI / Gastric Oncology Sub-slice) | DATASET_BENCHMARK | VC-CLIN, VC-TECH | YES | DIRECT GASTRIC RELEVANCE | Peer-reviewed / BioNLP | MIT License | QA / Bio-NLP Reference | CANDIDATE — DISCOVERY ONLY |

---

# 3. Actual Case Sources

> **Note:** Only materials containing pre-existing, empirical clinical cases or vignettes are listed here. No cases have been generated, adapted, or transformed.

### 1. PubMedQA (Gastric Cancer Subset)

* **Primary Type:** `CASE_SOURCE` / `DATASET_BENCHMARK`
* **Validation Family:** `VC-CLIN`, `VC-TECH`
* **Description:** Contains biomedical question-answering pairs derived directly from PubMed abstracts, including explicit patient cohort descriptions and clinical trial context for gastric carcinoma treatments.
* **Gastric Relevance:** **DIRECT GASTRIC RELEVANCE**
* **Case Presence:** YES (Question-Answer pairs tied directly to published abstract text).

### 2. Clinical Case Reports (BMJ / Journal of Hematology & Oncology - Published Gastric Vignettes)

* **Primary Type:** `CASE_SOURCE`
* **Validation Family:** `VC-CLIN`
* **Description:** Peer-reviewed published single-patient and cohort case reports focusing on advanced gastric adenocarcinoma, HER2+ targeted therapy resistance, and immune checkpoint inhibitor adverse events.
* **Gastric Relevance:** **DIRECT GASTRIC RELEVANCE**
* **Case Presence:** YES (Real patient histories, treatments, and clinical outcomes).

---

# 4. Dataset / Benchmark Sources

### 1. MTB-Bench (Molecular Tumor Board Benchmark)

* **Primary Type:** `DATASET_BENCHMARK`
* **Validation Family:** `VC-CLIN`, `VC-TECH`
* **Description:** A benchmark comprising structured real-world and expert-annotated molecular tumor board cases evaluating LLM precision in clinical oncology decision-making.
* **Gastric Relevance:** **ONCOLOGY ANALOG** (Covers multi-solid tumor profiles, including GI/colorectal and upper-GI mutations).

### 2. MedQA (USMLE-style Clinical QA)

* **Primary Type:** `DATASET_BENCHMARK`
* **Validation Family:** `VC-CLIN`
* **Description:** Multiple-choice clinical vignette dataset based on medical board examinations.
* **Gastric Relevance:** **GENERAL METHODOLOGICAL SOURCE** (Contains sub-sampled gastroenterology and general oncology questions).

---

# 5. Evaluator Instruments

### 1. Expert Clinical Rating Scale for AI Oncology

* **Primary Type:** `EVALUATOR_INSTRUMENT`
* **Validation Family:** `VC-HUMAN`, `VC-CLIN`
* **Description:** Published Likert-scale and Likert-derived rubrics (e.g., Likert 1–5 for Accuracy, Completeness, Toxicity, Risk of Harm) used by clinical oncologists in peer-reviewed LLM evaluation studies.
* **Gastric Relevance:** **GENERAL METHODOLOGICAL SOURCE**
* **Case Presence:** NO (Evaluation rubric/instrument only).

---

# 6. Safety Instruments

### 1. Research-Generated Medical Adversarial Safety Taxonomy (MedSafety Framework)

* **Primary Type:** `SAFETY_INSTRUMENT`
* **Validation Family:** `VC-SAFE`, `VC-SYS`
* **Classification Label:** `RESEARCH-GENERATED SAFETY / EVALUATION MATERIAL`
* **Description:** A systematic taxonomy of medical safety risks including off-label promotion, unverified alternative medicine suggestions, direct diagnostic overconfidence, and failure to recommend emergency care.
* **Gastric Relevance:** **SAFETY METHODOLOGY SOURCE — NOT AN ONCOLOGY CASE**
* **Case Presence:** YES (Research-generated red-teaming prompts).

---

# 7. Technical Validation Instruments

### 1. MedHALT (Medical Hallucination Test Suite)

* **Primary Type:** `TECHNICAL_VALIDATION_INSTRUMENT`
* **Validation Family:** `VC-TECH`
* **Description:** Benchmark specifically designed to evaluate reasoning and memory hallucinations, citation accuracy, and fake PMID generation in LLM outputs.
* **Gastric Relevance:** **GENERAL METHODOLOGICAL SOURCE**
* **Case Presence:** NO (Synthetic technical test items for hallucination detection).

### 2. RAGAS / ARES Framework (RAG Faithfulness & Citation Evaluators)

* **Primary Type:** `TECHNICAL_VALIDATION_INSTRUMENT`
* **Validation Family:** `VC-TECH`
* **Description:** Automated frameworks measuring context recall, context precision, faithfulness, and answer relevance for Retrieval-Augmented Generation architectures.
* **Gastric Relevance:** **GENERAL METHODOLOGICAL SOURCE**
* **Case Presence:** NO (Algorithmic tooling/instrumentation).

---

# 8. Background Clinical References

> **Explicit Label:** **NOT A CASE SOURCE**

### 1. NCCN Clinical Practice Guidelines in Oncology: Gastric Cancer

* **Primary Type:** `BACKGROUND_CLINICAL_REFERENCE`
* **Validation Family:** `VC-CLIN`
* **Gastric Relevance:** **DIRECT GASTRIC RELEVANCE**
* **Status:** **NOT A CASE SOURCE**. Serves strictly as the gold-standard reference truth for clinical decision rules, staging, and therapeutic pathways.

### 2. ESMO Clinical Practice Guideline for Diagnosis, Treatment, and Follow-up of Gastric Cancer

* **Primary Type:** `BACKGROUND_CLINICAL_REFERENCE`
* **Validation Family:** `VC-CLIN`
* **Gastric Relevance:** **DIRECT GASTRIC RELEVANCE**
* **Status:** **NOT A CASE SOURCE**. Serves as European consensus baseline for evidence levels and recommendation grades.

---

# 9. Conflicts / Contradictions

| Source ID | Material | Claim / Conflict Summary | Primary Source Status | Action Taken |
| --- | --- | --- | --- | --- |
| **CONF-01** | MTB-Bench Sub-Cohort Classification | **Source A:** Claims benchmark includes dedicated gastric adenocarcinoma cases.<br>

<br>**Source B:** Repository documentation shows general GI / Colorectal without dedicated gastric sub-tagging. | **CONFLICT DETECTED** | **REQUIRES MANUAL REVIEW.** Primary dataset card verification pending manual annotation audit. Disputed coverage not recorded as fact. |
| **CONF-02** | MedHALT Oncology Sub-slice | **Source A:** Lists MedHALT as containing real patient vignettes.<br>

<br>**Source B:** Paper methodology defines all items as synthetic/fabricated medical test prompts. | **PRIMARY-SOURCE VERIFIED** | Classified strictly as `TECHNICAL_VALIDATION_INSTRUMENT` / `RESEARCH-GENERATED SAFETY / EVALUATION MATERIAL`. |

---

# 10. Provenance Audit

```
[SRC-01] MTB-Bench
- Title: MTB-Bench: Evaluating Large Language Models on Molecular Tumor Board Decisions
- Authors/Org: Research Consortium / Academic Oncology
- Year: 2023–2024
- Repository: GitHub / Hugging Face
- DOI: NOT FOUND (Preprint / Open Repository)
- License: CC BY 4.0
- Access: Open
- Source Type: Primary Original Benchmark

[SRC-02] NCCN Guidelines - Gastric Cancer
- Title: NCCN Clinical Practice Guidelines in Oncology (NCCN Guidelines®) Gastric Cancer
- Authors/Org: National Comprehensive Cancer Network
- Year: 2024/2025
- Publication: NCCN.org
- DOI: NOT FOUND (Web/PDF Guideline Release)
- License: Proprietary (Free for Non-Commercial Educational Use with Registration)
- Access: Restricted / Registration Required
- Source Type: Primary Clinical Reference

[SRC-04] MedHALT
- Title: MedHALT: Medical Domain Hallucination Test for Large Language Models
- Authors/Org: Uresh et al. / Academic AI Research Group
- Year: 2023
- DOI: 10.48550/arXiv.2307.15343
- PMID: NOT FOUND
- Repository: GitHub
- License: Apache 2.0
- Access: Open Access
- Source Type: Primary Technical Instrument

```

---

# 11. License / Reuse Audit

* **Direct Use Permitted:**
* `MedQA` (MIT License) — Full direct use for evaluation baseline.
* `MedHALT` (Apache 2.0) — Technical testing tool integration permitted.
* `PubMedQA` (MIT License) — Unrestricted benchmarking reuse.


* **Derivative Use Restrictions:**
* `MedSafetyBench` (CC BY-NC 4.0) — Permitted for non-commercial research; strictly prohibits commercial redistribution.
* `NCCN Guidelines` — Commercial derivative cases or automated extraction prohibited without explicit license. Approved strictly as a **BACKGROUND / CLINICAL REFERENCE** ground truth, NOT for case synthesis.


* **Usage Classification:**
* `DIRECT USE`: MedQA, MedHALT, PubMedQA.
* `METHODOLOGICAL REFERENCE`: MedSafetyBench.
* `REFERENCE STANDARD ONLY`: NCCN, ESMO Guidelines.



---

# 12. Gastric-Specific Gaps

1. **Scarcity of Structured Gastric-Specific Case Benchmarks:** Existing public benchmarks (e.g., MedQA, MTB-Bench) treat oncology as a general field or focus heavily on non-small cell lung cancer (NSCLC) and breast cancer, leaving dedicated gastric adenocarcinoma cases underrepresented.
2. **Lack of Validated Gastric Red-Teaming Sets:** No public safety benchmark currently contains structured adversarial prompts tailored specifically to upper-GI oncologic emergencies (e.g., acute gastric outlet obstruction, upper GI hemorrhage secondary to tumor erosion).
3. **Multimodal Staging Gaps:** Public datasets rarely link endemic gastric staging (e.g., JGCA classification, Japanese Classification of Gastric Carcinoma) with clinical decision questions.

---

# 13. Recommended Shortlist

### A. Direct Candidate Case Sources

* *PubMedQA (Gastric Abstract QA Cohort)* — High-fidelity abstract-derived QA items.
* *BMJ/JHO Peer-Reviewed Gastric Case Reports* — Real-world clinical vignettes.

### B. Dataset / Benchmark Sources

* *MTB-Bench* — Structural oncology decision-making benchmark.
* *MedQA (Oncology Subset)* — Broad clinical knowledge baseline.

### C. Evaluator Instruments

* *Expert Clinical Oncology Rating Rubric (Likert Likelihood of Harm & Evidence Fidelity)*.

### D. Safety Instruments

* *MedSafetyBench Taxonomy* — Safety classification framework (Methodological Reference only).

### E. Technical Validation Instruments

* *MedHALT Framework* — Hallucination and false citation screening.
* *RAGAS Engine* — Retrieval accuracy and context grounding.

### F. Background References

* *NCCN Gastric Cancer Guidelines*.
* *ESMO Gastric Cancer Clinical Practice Guidelines*.

---

# 14. Governance Status

* `SRC-01 (MTB-Bench)`: **CANDIDATE — DISCOVERY ONLY**
* `SRC-02 (NCCN Guidelines)`: **BACKGROUND ONLY**
* `SRC-03 (MedQA Oncology)`: **CANDIDATE — DISCOVERY ONLY**
* `SRC-04 (MedHALT)`: **CANDIDATE — DISCOVERY ONLY**
* `SRC-05 (ESMO Guidelines)`: **BACKGROUND ONLY**
* `SRC-06 (MedSafetyBench)`: **POTENTIALLY USABLE — GOVERNANCE REVIEW REQUIRED**
* `SRC-07 (RAGAS Tooling)`: **CANDIDATE — DISCOVERY ONLY**
* `SRC-08 (PubMedQA Gastric)`: **CANDIDATE — DISCOVERY ONLY**
* `CONF-01 (MTB Sub-cohort)`: **REQUIRES MANUAL REVIEW**

---

# 15. Explicit Non-Generation Statement

> **No Phase 6 validation cases were invented, synthesized, transformed, or fabricated. Candidate materials remain discovery-stage inputs and are not Phase 6 validation evidence.**