# PHASE 6 --- VALIDATION EXECUTION & RUN-CONTROL ARCHITECTURE

**Document:** Phase 6 Validation Execution & Run-Control Architecture\
**Phase:** Phase 6 --- Validation\
**Decision Batch:** 06\
**Version:** 1.0\
**Status:** APPROVED --- LOCKED\
**Approval basis:** V6-B06.1 → V6-B06.14 approved by Project
Coordinator\
**Date:** 2026-08-14

------------------------------------------------------------------------

# 1. Purpose

This document defines the approved architecture for transitioning
validation sets from readiness into controlled Phase 6 execution.

It establishes execution lifecycle, pre-execution readiness,
version/configuration capture, evaluator separation, reproducibility,
evidence capture, invalid/partial run handling, change control, rerun
authorization, and execution completion.

It does not begin actual validation execution or define exact cases,
datasets, schedules, statistical methods, or numeric risk thresholds.

------------------------------------------------------------------------

# 2. Inherited Baseline

Phase 6 is:

**Phase 6 --- Validation**

Locked preceding Decision Batches:

-   Batch 01 --- Architecture / Scope Gate
-   Batch 02 --- Validation Architecture & Evidence Model
-   Batch 03 --- Validation Case, Scenario & Dataset Architecture
-   Batch 04 --- Validation Metrics, Acceptance Criteria & Scoring
    Architecture
-   Batch 05 --- Validation Risk, Finding & Disposition Architecture

Phase 5 remains:

**CLOSED / PASS**

Implementation baseline:

**Task #002 → Task #009**

Final implementation commit:

`0f413c9`

------------------------------------------------------------------------

# 3. Locked Decisions

## V6-B06.1 --- Validation Execution Lifecycle

**LOCKED**

The controlled execution lifecycle is:

``` text
VALIDATION SET READY
        ↓
PRE-EXECUTION CHECK
        ↓
EXECUTION AUTHORIZED
        ↓
RUN INITIALIZED
        ↓
CASE EXECUTION
        ↓
EVIDENCE CAPTURE
        ↓
RUN REVIEW
        ↓
RUN COMPLETED
        ↓
VALIDATION RECORD
        ↓
REVIEW / DISPOSITION
```

Dataset existence alone does not constitute validation execution.

------------------------------------------------------------------------

## V6-B06.2 --- Pre-Execution Readiness Gate

**LOCKED**

Before controlled execution, the following shall be confirmed:

-   validation set is READY;
-   requirement mapping is complete;
-   expected behavior is defined;
-   relevant system versions are identified;
-   knowledge/evidence version is identified;
-   execution configuration is identified;
-   evaluator/role is identified;
-   required evidence capture is available;
-   no unresolved execution blocker exists.

The gate is:

``` text
Ready Set
+
Ready System
+
Ready Configuration
+
Ready Evidence Capture
        ↓
EXECUTION AUTHORIZED
```

------------------------------------------------------------------------

## V6-B06.3 --- Environment & Version Capture

**LOCKED**

Each validation run shall capture sufficient context to identify:

-   software/runtime version;
-   relevant implementation commit/version;
-   validation framework version;
-   validation dataset version;
-   configuration;
-   execution date/time;
-   relevant environment identifier.

A validation record shall not depend on an unidentifiable system state.

------------------------------------------------------------------------

## V6-B06.4 --- System Configuration Freeze

**LOCKED**

The validated configuration shall remain frozen during a controlled run.

If code, prompt, runtime configuration, safety configuration, retrieval
configuration, or another validation-relevant setting changes, the
change shall be controlled and the resulting execution shall not
silently remain part of the original run.

------------------------------------------------------------------------

## V6-B06.5 --- Knowledge / Evidence Version Capture

**LOCKED**

Clinical/evidence validation shall capture the versions relevant to the
executed behavior, including where applicable:

-   knowledge-base/repository version;
-   Population / Knowledge Asset version;
-   Runtime Evidence Package version;
-   relevant source/provenance version.

The execution record must support reconstruction of what governed
knowledge the system used.

------------------------------------------------------------------------

## V6-B06.6 --- Prompt / Runtime Configuration Capture

**LOCKED**

Where runtime behavior depends on configuration, the relevant versions
or identifiers shall be captured, including where applicable:

-   system prompt;
-   generation configuration;
-   retrieval configuration;
-   safety configuration;
-   model/runtime version.

Prompt and runtime configuration shall not remain hidden uncontrolled
variables.

------------------------------------------------------------------------

## V6-B06.7 --- Evaluator Role Separation

**LOCKED**

Phase 6 shall distinguish:

``` text
Execution
   ≠
Evaluation
   ≠
Disposition
```

The conceptual role flow is:

``` text
Executor
   ↓
Evidence / Observation
   ↓
Evaluator / Reviewer
   ↓
Finding
   ↓
Disposition Authority
```

Final governed disposition remains under the established Project
Coordinator authority.

------------------------------------------------------------------------

## V6-B06.8 --- Execution Reproducibility

**LOCKED**

Execution records shall contain sufficient metadata to identify:

-   exact case;
-   exact dataset;
-   system state;
-   configuration;
-   expected behavior;
-   observed behavior;
-   supporting evidence.

Where a component has controlled nondeterminism, the reproducibility
boundary shall be explicit rather than silently assuming bit-for-bit
identity.

------------------------------------------------------------------------

## V6-B06.9 --- Evidence Capture During Execution

**LOCKED**

Evidence shall be captured during controlled execution as appropriate to
the validation objective.

Possible evidence includes:

-   input;
-   expected output;
-   observed output;
-   runtime trace;
-   Runtime Evidence Package;
-   safety decision;
-   validation result;
-   evaluator assessment;
-   relevant logs/screenshots/artifacts.

Evidence capture shall remain proportional to the validation objective.

------------------------------------------------------------------------

## V6-B06.10 --- Run Interruption / Invalid-Run Rules

**LOCKED**

A run shall be marked `INVALID` or `ABORTED`, rather than PASS/FAIL,
when execution integrity is compromised, including:

-   invalid environment;
-   missing required configuration;
-   wrong dataset version;
-   unexpected system-state change;
-   failed evidence capture;
-   evaluator protocol violation;
-   invalid execution setup.

An invalid run shall not silently be counted as a failed validation
case.

------------------------------------------------------------------------

## V6-B06.11 --- Partial-Run Handling

**LOCKED**

An interrupted validation batch shall distinguish:

``` text
Completed cases
+
Interrupted cases
+
Unexecuted cases
```

A batch shall not be marked COMPLETE while required cases remain
unexecuted or formally dispositioned.

Partial-run evidence shall be retained and the continuation/restart
decision shall be explicit.

------------------------------------------------------------------------

## V6-B06.12 --- Execution Change Control

**LOCKED**

Changes between controlled runs shall be classified as applicable:

-   administrative;
-   configuration;
-   system;
-   knowledge;
-   dataset;
-   protocol;
-   safety/governance.

Where a change may affect validation validity:

``` text
Change
 ↓
Impact Assessment
 ↓
New Run / Re-validation Decision
```

Execution conditions shall not be silently modified.

------------------------------------------------------------------------

## V6-B06.13 --- Validation Rerun Authorization

**LOCKED**

Every rerun shall have an explicit reason, such as:

-   technical execution error;
-   invalid run;
-   configuration correction;
-   dataset correction;
-   evaluator error;
-   approved remediation;
-   re-validation requirement;
-   governance decision.

Reruns shall not be used as uncontrolled "run until PASS" behavior.
Previous runs and their outcomes remain traceable.

------------------------------------------------------------------------

## V6-B06.14 --- Execution Completion & Transition

**LOCKED**

A validation batch may transition from EXECUTION to REVIEW/DISPOSITION
only when:

1.  required cases are executed or formally dispositioned;
2.  execution records are complete;
3.  required evidence is captured;
4.  invalid/aborted runs are identified;
5.  deviations are documented;
6.  configuration/version context is complete;
7.  no unresolved execution-integrity issue remains.

The transition is:

``` text
EXECUTION COMPLETE
        ↓
REVIEW
        ↓
FINDING / RISK
        ↓
DISPOSITION
```

------------------------------------------------------------------------

# 4. Controlled Execution Architecture

The complete controlled execution pathway is:

``` text
Validation Set Ready
        ↓
Pre-Execution Readiness
        ↓
Execution Authorization
        ↓
Configuration / Version Freeze
        ↓
Run Initialization
        ↓
Controlled Case Execution
        ↓
Evidence Capture
        ↓
Run Integrity Review
        ↓
Execution Complete
        ↓
Validation Record
        ↓
Finding / Risk / Disposition
```

------------------------------------------------------------------------

# 5. Execution Integrity Principle

A validation result is credible only when the execution context itself
is credible.

Therefore Phase 6 distinguishes:

``` text
Validation Result
```

from:

``` text
Validation Execution Integrity
```

A technically correct observation obtained under an invalid execution
context cannot automatically be used as controlled validation evidence.

------------------------------------------------------------------------

# 6. Rerun / Re-validation Boundary

The controlled distinction is:

``` text
Execution Error
   ↓
Correct execution problem
   ↓
Rerun

Behavior / Validation Basis Changed
   ↓
Impact Assessment
   ↓
Re-test or Re-validation
```

This preserves the Batch 05 RETEST / REVALIDATE architecture.

------------------------------------------------------------------------

# 7. Version-Lineage Principle

A validation record shall support the lineage:

``` text
Validation Case
 ↓
Dataset Version
 ↓
System / Commit
 ↓
Runtime / Configuration
 ↓
Knowledge / Evidence Version
 ↓
Observed Result
 ↓
Evidence
 ↓
Disposition
```

This lineage is required for reproducibility and final Phase 6
auditability.

------------------------------------------------------------------------

# 8. Execution Boundary

Batch 06 does not authorize:

-   actual clinical validation execution;
-   production deployment;
-   uncontrolled evaluator testing;
-   changing locked architecture;
-   modifying validation cases during a controlled run;
-   changing knowledge/configuration without change control;
-   declaring Phase 6 acceptance.

Execution authorization occurs only after the relevant validation set
passes the Batch 03 Validation Set Acceptance Gate and the execution
readiness gate defined here.

------------------------------------------------------------------------

# 9. Deferred Decisions

The following remain intentionally open:

-   exact execution tooling;
-   exact run identifiers;
-   exact evaluator roster;
-   exact validation schedule;
-   exact datasets/cases;
-   statistical execution;
-   numeric risk matrix;
-   final reporting format.

------------------------------------------------------------------------

# 10. Next Decision Batch

## Decision Batch 07 --- Validation Evidence Capture & Record Architecture

### Purpose

Define the controlled evidence-record structure produced during Phase 6
execution and establish how execution evidence becomes reviewable,
traceable, auditable validation evidence.

### Proposed Must-Decide-Now Topics

1.  Validation Record canonical structure.
2.  Execution Record vs Validation Record relationship.
3.  Evidence artifact taxonomy.
4.  Mandatory evidence fields.
5.  Expected vs observed behavior recording.
6.  Trace/log artifact handling.
7.  Clinical evaluator evidence capture.
8.  Safety evidence capture.
9.  Provenance and citation capture.
10. Evidence integrity and completeness checks.
11. Evidence storage / reference model.
12. Evidence review status.
13. Evidence-to-finding linkage.
14. Evidence retention and immutability.
15. Final validation evidence package structure.

### Intentionally Deferred

-   exact storage technology;
-   exact database/schema implementation;
-   final Phase 6 report;
-   final repository organization;
-   deployment packaging.

------------------------------------------------------------------------

# 11. Decision Status

**V6-B06.1 → V6-B06.14: APPROVED → LOCKED**

**Phase 6 Validation Execution & Run-Control Architecture: LOCKED**

**Validation Execution: NOT STARTED**

**Next Decision Batch: V6-B07 --- Validation Evidence Capture & Record
Architecture**
