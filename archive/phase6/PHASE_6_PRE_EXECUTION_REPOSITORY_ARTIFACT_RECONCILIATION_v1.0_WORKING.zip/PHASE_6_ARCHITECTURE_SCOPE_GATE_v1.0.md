# PHASE 6 --- ARCHITECTURE / SCOPE GATE

**Document:** Phase 6 Architecture / Scope Gate\
**Phase:** Phase 6 --- Validation\
**Gate:** Entry Gate / Architecture / Scope Gate\
**Version:** 1.0\
**Status:** APPROVED --- LOCKED\
**Approval basis:** V6-B1 → V6-B12 approved by Project Coordinator\
**Date:** 2026-08-14

------------------------------------------------------------------------

# 1. Purpose

This document defines the approved Architecture / Scope Gate for **Phase
6 --- Validation**.

The Architecture / Scope Gate is the **entry gate of Phase 6**. It is
not the name of the phase.

Phase 6 validates the implemented Safe Medical AI system against
approved technical, clinical, safety, human-oversight, acceptance,
traceability, and risk-disposition requirements.

Phase 6 does not automatically reopen Phase 5 implementation or
authorize deployment.

------------------------------------------------------------------------

# 2. Inherited Baseline

Phase 5 is formally:

**CLOSED / PASS**

Completed implementation scope:

-   Task #002 --- Implementation Scaffolding --- PASS
-   Task #003 --- Retrieval Foundation --- PASS
-   Task #004 --- Filesystem Repository Source --- PASS
-   Task #005 --- Runtime Evidence Package --- PASS
-   Task #006 --- Runtime Integration / GenerationContext --- PASS
-   Task #007 --- Generation Boundary --- PASS
-   Task #008 --- Validation Boundary --- PASS
-   Task #009 --- Safety Enforcement Boundary --- PASS

Phase 5 final technical acceptance: PASS\
Remote verification: PASS\
Final implementation commit: `0f413c9`

Final Phase 5 governance records:

-   `PHASE_5_IMPLEMENTATION_READINESS_DECISION_RECORD_v12.0.md`
-   `Phase_5_Governance_Consolidated_Decision_Record_v12.0.md`

Phase 5 implementation baseline is inherited by Phase 6 and is not
reopened by default.

------------------------------------------------------------------------

# 3. Locked Decisions

## V6-B1 --- Phase Identity

**LOCKED**

The current phase is:

> **Phase 6 --- Validation**

------------------------------------------------------------------------

## V6-B2 --- Architecture / Scope Gate Role

**LOCKED**

Architecture / Scope Gate is the **entry gate of Phase 6**.

No Phase 6 validation execution begins before this gate is approved and
locked.

------------------------------------------------------------------------

## V6-B3 --- Phase 6 Objective

**LOCKED**

Phase 6 shall determine whether the implemented system satisfies the
approved validation criteria through reproducible validation evidence
and explicit acceptance/risk disposition.

Phase 6 shall not overclaim clinical deployment readiness, unrestricted
patient use, or regulatory approval.

------------------------------------------------------------------------

## V6-B4 --- Validation Layers

**LOCKED**

Phase 6 contains five validation layers:

1.  Technical / Architectural Validation
2.  Clinical Knowledge & Evidence Validation
3.  Safety / Behavioral Validation
4.  Human-Oversight / User Evaluation
5.  System-Level Acceptance & Risk Disposition

------------------------------------------------------------------------

## V6-B5 --- Technical / Architectural Validation Boundary

**LOCKED**

Technical validation evaluates system-level behavior against the
approved architecture and Phase 5 implementation baseline.

It includes:

-   runtime boundary behavior;
-   contract compatibility;
-   deterministic behavior;
-   traceability;
-   evidence flow;
-   architectural isolation;
-   regression/integration behavior;
-   prohibited-pathway verification.

It does not automatically reopen completed Phase 5 tasks.

------------------------------------------------------------------------

## V6-B6 --- Clinical Knowledge & Evidence Fidelity Boundary

**LOCKED**

Clinical/evidence validation evaluates whether governed clinical
knowledge is used with preservation of:

-   clinical meaning;
-   evidence fidelity;
-   provenance;
-   guideline/source traceability;
-   knowledge boundaries;
-   evidence-supported response behavior.

The runtime chain to be evaluated is:

`Repository → Retrieval → RTEP → GenerationContext → Generation → CandidateResponse → Validation`

Validation shall not invent evidence or silently replace governed
evidence with uncontrolled model knowledge.

------------------------------------------------------------------------

## V6-B7 --- Safety / Behavioral Validation Boundary

**LOCKED**

Safety validation evaluates system-level safety behavior, including the
governed actions:

-   `ALLOW`
-   `ALLOW_WITH_WARNING`
-   `ASK_CLARIFICATION`
-   `REDIRECT`
-   `ESCALATE`
-   `REJECT`
-   emergency termination semantics where applicable

Restrictive safety decisions remain authoritative and cannot be
overridden by downstream validation success.

------------------------------------------------------------------------

## V6-B8 --- Human-Oversight / User Evaluation Boundary

**LOCKED**

Phase 6 shall evaluate:

-   clarity of system boundaries;
-   recognition of insufficient evidence;
-   clarification behavior;
-   refusal/redirect behavior;
-   escalation behavior;
-   human intervention points;
-   risk of users interpreting the system as having unrestricted
    clinical authority.

Human evaluation does not constitute clinical approval or deployment
authorization.

------------------------------------------------------------------------

## V6-B9 --- System-Level Acceptance and Risk Disposition

**LOCKED**

Phase 6 shall integrate evidence across validation layers and explicitly
disposition findings and residual risks.

The system-level disposition vocabulary shall distinguish at least:

-   `PASS`
-   `PASS WITH CONTROLLED REMEDIATION`
-   `FAIL`

A validation PASS does not equal clinical deployment readiness.

------------------------------------------------------------------------

## V6-B10 --- Validation Sequence

**LOCKED**

The default validation sequence is:

``` text
V-Batch 01
Technical / Architecture Validation
        ↓
V-Batch 02
Clinical Knowledge / Evidence Fidelity
        ↓
V-Batch 03
Safety Behavioral Validation
        ↓
V-Batch 04
Human-Oversight / User Evaluation
        ↓
V-Batch 05
System Acceptance / Risk Disposition
```

Non-dependent activities may execute in parallel when authorized by the
relevant validation batch.

------------------------------------------------------------------------

## V6-B11 --- Explicit Exclusions

**LOCKED**

Phase 6 does not automatically include:

-   uncontrolled architecture redesign;
-   new implementation without an approved scope;
-   reopening Phase 3 Gold production;
-   reopening Phase 4 repository verification;
-   replacing the Phase 5 architecture;
-   production deployment;
-   unrestricted public/clinical release;
-   final GitHub cleanup/canonicalization;
-   unrestricted clinical deployment authorization.

A genuine architecture-level gap discovered during validation must be
governed through the applicable amendment / Architecture / Scope
process.

------------------------------------------------------------------------

## V6-B12 --- Closure and Non-Overclaim Boundary

**LOCKED**

Phase 6 may close only when:

1.  approved validation batches are completed;
2.  required technical validation is dispositioned;
3.  clinical/evidence validation is dispositioned;
4.  safety validation is dispositioned;
5.  human-oversight/user evaluation is completed and dispositioned;
6.  critical findings are resolved or explicitly governed;
7.  residual risks are documented;
8.  required remediation and re-validation are completed where
    applicable;
9.  requirements → validation → evidence → disposition traceability is
    complete;
10. Phase 6 closure evidence is approved.

Phase 6 closure shall not by itself claim:

-   unrestricted clinical deployment;
-   patient-specific medical approval;
-   regulatory authorization;
-   production readiness beyond the explicitly approved acceptance
    scope.

------------------------------------------------------------------------

# 4. Phase 6 Architecture

The approved high-level validation model is:

``` text
                PHASE 5
        CLOSED / PASS BASELINE
                 │
                 ▼
        PHASE 6 — VALIDATION
                 │
                 ▼
       Architecture / Scope Gate
                 │
        ┌────────┴────────┐
        ▼                 ▼
 Technical           Clinical /
 Validation          Evidence Fidelity
        │                 │
        └────────┬────────┘
                 ▼
       Safety / Behavioral
           Validation
                 │
                 ▼
     Human-Oversight / User
           Evaluation
                 │
                 ▼
      System Acceptance +
       Risk Disposition
                 │
                 ▼
          Phase 6 Closure
```

------------------------------------------------------------------------

# 5. Validation Evidence Principle

Every validation result shall be traceable through:

``` text
Validation Objective
        ↓
Validation Scenario / Test
        ↓
Input / Case / Dataset
        ↓
Expected Behavior
        ↓
Observed Behavior
        ↓
Evidence
        ↓
Result
        ↓
Finding / Risk
        ↓
Disposition
```

A bare PASS/FAIL without supporting evidence is not sufficient as final
validation evidence.

------------------------------------------------------------------------

# 6. Phase 6 Working Boundary

Phase 6 is an evaluation/validation phase.

Validation findings may result in:

``` text
Finding
  ↓
Classification
  ↓
Impact / Risk Assessment
  ↓
Disposition
  ├── Accept
  ├── Remediate
  ├── Re-test / Re-validate
  └── Escalate for governance decision
```

Validation does not silently authorize implementation changes.

------------------------------------------------------------------------

# 7. Deferred Decisions

The following are intentionally deferred to subsequent Decision Batches:

-   exact validation case inventory;
-   exact number of cases/tests;
-   detailed clinical scenarios;
-   exact technical metrics;
-   exact user-evaluation protocol;
-   evaluator composition;
-   scoring rubrics;
-   statistical methodology;
-   validation datasets;
-   detailed evidence-record schema;
-   remediation workflow details;
-   exact artifact filenames for individual validation batches;
-   exact domain-specific acceptance thresholds.

------------------------------------------------------------------------

# 8. Required Inputs for Subsequent Validation Architecture Decisions

The next Decision Batches should be grounded in the existing controlled
project frameworks.

Relevant source families include:

-   `SYSTEM_EVALUATION_FRAMEWORK`
-   `SAFETY_FRAMEWORK`
-   `CLINICAL_NAVIGATION_ENGINE`
-   `MEDICAL_GOVERNANCE`
-   `EVIDENCE_PACKAGE_SPECIFICATION`
-   `RESPONSE_GENERATION_ARCHITECTURE`
-   `OUTPUT_VALIDATION_FRAMEWORK`
-   `DELIVERY_POLICY`
-   relevant Phase 5 validation/acceptance records
-   current Phase 5 implementation evidence where behavior-level
    validation requires it

If any required controlled source is unavailable in the active
materials, it shall be requested before the affected decision is locked.

------------------------------------------------------------------------

# 9. Governance / Repository Boundary

Phase 6 validation artifacts shall remain distinct from:

-   Phase 3 knowledge products;
-   Phase 4 repository integration evidence;
-   Phase 5 implementation specifications and closure records.

Project-level living documents may evolve locally during Phase 6 under
the project-level synchronization policy.

Final project-wide canonicalization remains deferred to final project
closure/deployment packaging.

------------------------------------------------------------------------

# 10. Approval and Status

The following decisions are approved and locked:

**V6-B1 → V6-B12**

Therefore:

**Phase 6 Architecture / Scope Gate --- LOCKED**

This artifact establishes the entry boundary for Phase 6 validation
execution.

It does not authorize detailed validation execution until the
corresponding validation batches are themselves defined and approved
through the established Decision Batch workflow.

------------------------------------------------------------------------

# 11. Next Decision Batch

**Decision Batch 02 --- Validation Architecture & Evidence Model**

Primary purpose:

Define how Phase 6 validation will be structured and evidenced at an
operational architecture level, without yet committing to detailed case
counts or domain-specific thresholds.

Primary topics:

-   validation requirement taxonomy;
-   validation evidence unit;
-   traceability model;
-   validation case/scenario structure;
-   cross-layer evidence relationships;
-   defect/finding classification;
-   risk disposition interface;
-   re-validation trigger principles;
-   validation record lifecycle;
-   dependency on existing evaluation/safety/clinical frameworks.

Required source review before final lock:

`SYSTEM_EVALUATION_FRAMEWORK`, `SAFETY_FRAMEWORK`,
`CLINICAL_NAVIGATION_ENGINE`, `MEDICAL_GOVERNANCE`, and relevant runtime
validation/delivery specifications.

------------------------------------------------------------------------

# 12. Decision Status

**V6-B1 → V6-B12: APPROVED → LOCKED**

**Phase 6 Architecture / Scope Gate: LOCKED**

**Phase 6 Validation Execution: NOT YET STARTED**

**Next: Decision Batch 02**
