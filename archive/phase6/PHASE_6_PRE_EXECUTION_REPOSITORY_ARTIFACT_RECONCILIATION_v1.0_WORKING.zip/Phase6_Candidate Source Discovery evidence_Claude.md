# Phase 6 Validation — Candidate Source Material Discovery & Provenance Search
**Project:** Safe Medical AI Oncology | **Phase:** 6 — Validation (Execution Preparation)
**Role of this document:** Source discovery only. Nothing below is a Phase 6 validation case, validation evidence, or acceptance decision.

---

## 1. Search Scope

- **Search engine:** general web search (Anthropic web_search tool), no login-gated or paywalled full-text retrieval performed.
- **Date searched:** 2026-08-14.
- **Databases/repositories surfaced:** arXiv, medRxiv, PMC/PubMed Central, Nature/Scientific Reports/Scientific Data, ScienceDirect, JMIR AI, ClinicalTrials.gov, ResearchGate/Research Square preprint mirrors, SSRN, vendor/tooling blogs (Vectara, Evidently, Confident AI, Maxim AI).
- **Search terms used (representative):** "oncology clinical decision support evaluation benchmark dataset"; "gastric cancer clinical vignette dataset case bank"; "medical LLM safety benchmark hallucination evaluation dataset RAG healthcare"; "clinician evaluation rubric large language model medical output rating framework"; "MedRAG benchmark retrieval augmented generation medical evidence grounded QA"; "clinical AI red team escalation refusal insufficient evidence safety scenario dataset"; "RAG citation correctness provenance verification test suite evaluation software".
- **Inclusion logic:** materials that (a) contain or plausibly reference actual cases/scenarios/questions/rubrics, or (b) are dataset/benchmark/tooling artifacts with identifiable provenance (paper, repo, or dataset ID).
- **Exclusion logic:** general narrative reviews with no extractable case/instrument; sources with no traceable authorship or venue; results where I could not distinguish primary from secondary reporting.
- **Not performed in this pass:** direct download/inspection of dataset files, GitHub repo browsing, PubMed/PMC structured queries, ESMO/NCCN/ASCO official case-library search, non-English sources. These are listed as gaps in §10.

---

## 2. Candidate Material Inventory

| ID | Material | Source | Year | Type | Validation Family | Case/Scenario Present? | Source Sufficiency | Provenance | URL |
|---|---|---|---|---|---|---|---|---|---|
| C01 | Multidimensional LLM oncology benchmarking framework (5 NSCLC stepwise scenarios, 30 questions) | *Scientific Reports* | 2026 | Benchmark study | VC-CLIN, VC-HUMAN | Yes | PARTIAL | Peer-reviewed, journal-hosted code repo referenced | nature.com/articles/s41598-026-61195-1 |
| C02 | Systematic review of oncology CDS evaluations (43 studies) | *ScienceDirect* (Crit Rev Oncol Hematol type) | 2023 | Systematic review | VC-CLIN | No (aggregates others) | NOT A CASE SOURCE | Peer-reviewed | sciencedirect.com/science/article/abs/pii/S1040842823002317 |
| C03 | Cancer-Net BCa (breast cancer CDS imaging benchmark, 253 pts) | arXiv / GlobalCancer.ai initiative | ~2023 | Open dataset | VC-TECH, VC-CLIN | Yes (imaging cases) | PARTIAL (breast, not gastric) | Original dataset paper | arxiv.org/pdf/2304.05623 |
| C04 | GPT-5 radiation oncology benchmark: TXIT exam (300 MCQ) + 60 curated vignettes | PMC (preprint/journal) | 2026 | Exam + vignette benchmark | VC-CLIN | Yes | PARTIAL (radiation onc, not gastric) | Peer-reviewed/preprint, PMCID present | ncbi.nlm.nih.gov/pmc/articles/PMC12738326 |
| C05 | Clinical decision benchmarks compilation: SEER treatment-plan set, DDXPlus, MIMIC4ED tasks, MedNLI | arXiv ("o1 in Medicine" study) | 2024 | Multi-dataset benchmark | VC-CLIN, VC-TECH | Yes | SUFFICIENT (as pointer to named datasets) | Cites named public datasets | arxiv.org/pdf/2409.15277 |
| C06 | MTBBench — Molecular Tumor Board multimodal longitudinal oncology benchmark | arXiv + GitHub + HuggingFace | 2025 | Agentic benchmark dataset | VC-CLIN, VC-SYS | Yes | SUFFICIENT | Original, repo + HF dataset ID given | arxiv.org/pdf/2511.20490; github.com/bunnelab/MTBBench; huggingface.co/datasets/EeshaanJain/MTBBench |
| C07 | PMC-Patients (167k patient summaries, relation annotations) | arXiv | 2022 | Retrieval CDS benchmark | VC-TECH, VC-SYS | Yes (patient-summary "cases") | SUFFICIENT | Original, large public dataset | arxiv.org/pdf/2202.13876 |
| C08 | Gastric cancer NAPPA biomarker dataset (100 samples, case/control) | arXiv (biomarker ML paper citing Song et al.) | 2024 | Biomarker dataset | VC-TECH (background) | Partial — case/control labels, not clinical vignettes | PARTIAL | Secondary citation of Song et al. dataset | arxiv.org/pdf/2405.10345 |
| C09 | GasHisSDB — gastric histopathology image dataset (245,196 images) | ScienceDirect / arXiv | 2022 | Imaging dataset | VC-TECH | Yes (image-level cases) | PARTIAL (imaging only, not clinical decision cases) | Original dataset paper | sciencedirect.com/science/article/abs/pii/S0010482521010015 ; arxiv.org/pdf/2106.02473 |
| C10 | GasHisSDB ensemble-learning classification study | PMC | 2024 | Applied ML study | VC-TECH | Yes (uses C09) | PARTIAL | Peer-reviewed, PMCID present | ncbi.nlm.nih.gov/pmc/articles/PMC11354078 |
| C11 | National Survey and Case-Vignette Study of Clinical Decisions in Pancreatic Cancer (GECP01) | ClinicalTrials.gov | Registered; completed | Registered vignette study | VC-CLIN | Yes — explicitly "five imaginary cases" (pancreatic, not gastric) | NOT A CASE SOURCE (registry record only; case text not published in record) | Official registry | clinicaltrials.gov/study/NCT04755036 |
| C12 | FREGAT biobank — clinico-biological database for esophageal & gastric cancers | PMC | ~2017 | Clinico-biological registry/biobank | VC-CLIN (background) | No individual case narratives extractable from this record | NOT A CASE SOURCE — BACKGROUND / REFERENCE ONLY | Original consortium publication | ncbi.nlm.nih.gov/pmc/articles/PMC5801889 |
| C13 | HMU-GC gastric cancer histology dataset with tumor-microenvironment annotation + clinical CSV | *Scientific Data* / PMC | 2025 | Imaging + clinical dataset | VC-TECH | Yes (annotated cases) | PARTIAL (histology/TME focus, not decision-support cases) | Original, dataset files named | nature.com/articles/s41597-025-04489-9 ; pmc.ncbi.nlm.nih.gov/articles/PMC11754904 |
| C14 | HaluBench-derived RAG hallucination benchmark analysis (incl. PubMedQA) | Towards Data Science (Cleanlab) | 2025 | Hallucination-detection benchmark evaluation | VC-SAFE, VC-TECH | Yes (uses existing QA instances) | PARTIAL — secondary analysis, points to primary HaluBench/PubMedQA | Secondary/blog, but names primary datasets | towardsdatascience.com/benchmarking-hallucination-detection-methods-in-rag-6a03c555f063 |
| C15 | RAG-based hallucination-detection benchmark (HaluEval, RAGTruthQA, Dolly(NC), new TRIVIA+) | arXiv (Amazon/CMU) | 2026 | Hallucination benchmark | VC-SAFE, VC-TECH | Yes | SUFFICIENT for named component datasets; PARTIAL for new TRIVIA+ (not yet independently verified) | Original + cites primary datasets | arxiv.org/pdf/2605.11330 |
| C16 | Med-HALT / UPHILL — described within MedHalu paper | arXiv | 2024 | Medical hallucination benchmark (exam MCQs) + presupposition-claims dataset | VC-SAFE | Yes (per description) | PARTIAL — description via secondary paper; primary sources (Pal et al. Med-HALT; Kaur et al. UPHILL) not directly retrieved this pass | Secondary citation chain | arxiv.org/pdf/2409.19492 |
| C17 | MedGPTEval — criteria + Chinese-language medical datasets + benchmarks | PMC (JMIR-family) | 2024 | Evaluation framework + dataset | VC-HUMAN, VC-TECH | Yes (dataset designed by 3 clinical experts) | PARTIAL (non-English, oncology-general not gastric-specific) | Peer-reviewed | ncbi.nlm.nih.gov/pmc/articles/PMC11225096 |
| C18 | LLM medical-summarization evaluation rubric review (SaferDx, PDQI-9, Revised-IDEA) | PMC / *npj Health Systems* | 2025 | Rubric review | VC-HUMAN | Partial — names existing instruments, doesn't reproduce full rubric text | PARTIAL | Peer-reviewed | pmc.ncbi.nlm.nih.gov/articles/PMC11928168 ; nature.com/articles/s44401-024-00011-2 |
| C19 | Multi-Domain Red Teaming Framework for medical LLM safety/robustness/fairness | arXiv | 2026 | Red-team benchmark | VC-SAFE, VC-HUMAN | Yes (scenario-based, equity stress-tests) | PARTIAL (oncology not singled out) | Original | arxiv.org/pdf/2606.00027 |
| C20 | CLEVER — Clinical LLM Evaluation by Expert Review (factuality/relevance/conciseness rubric) | JMIR AI / PMC | 2025 | Human-evaluator framework | VC-HUMAN | Yes (rubric + methodology reproducible) | SUFFICIENT for rubric structure; tasks were summarization/extraction/QA, not oncology-specific | Peer-reviewed, journal DOI available on publisher page | ai.jmir.org/2025/1/e72153 ; pmc.ncbi.nlm.nih.gov/articles/PMC12677871 |
| C21 | AIPatient Arena — EHR-grounded 8-dimension consultation rubric | arXiv | 2026 | Human/LLM-jury evaluation framework | VC-HUMAN, VC-SYS | Yes (rubric dimensions explicit) | PARTIAL (general consultation, not oncology-specific) | Original | arxiv.org/pdf/2606.17474 |
| C22 | MedDialogRubrics — EBM-guideline-grounded "must-ask" rubric generation | arXiv | 2026 | Rubric-generation benchmark | VC-HUMAN, VC-CLIN | Yes | PARTIAL | Original | arxiv.org/pdf/2601.03023 |
| C23 | MedHELM — 35 benchmarks across 22 medical-task subcategories incl. Clinical Decision Support | arXiv (Stanford HELM family) | 2025 | Composite benchmark suite | VC-TECH, VC-CLIN, VC-HUMAN | Yes (aggregates many named benchmarks) | SUFFICIENT as an index of component benchmarks; requires drill-down per component | Original, open framework | arxiv.org/pdf/2505.23802 |
| C24 | MIRAGE / MedRAG toolkit — 7,663-question medical RAG evaluation benchmark | arXiv | 2024 | RAG evaluation benchmark | VC-TECH | Yes (assembled from 5 named medical QA datasets) | SUFFICIENT | Original, toolkit + benchmark released | arxiv.org/html/2402.13178v1 |
| C25 | MedRAGChecker — claim-level RAG verification (faithfulness/under-evidence/contradiction/safety-error) | arXiv | 2026 | Technical validation framework | VC-TECH, VC-SAFE | Yes (evaluated on 4 named biomedical QA benchmarks) | PARTIAL (framework; component datasets need separate provenance check) | Original | arxiv.org/abs/2601.06519 |
| C26 | Contradictions in Context — RAG healthcare benchmark from Cochrane reviews + AHA guidelines | arXiv | 2025 | Evidence-conflict benchmark | VC-SAFE, VC-TECH | Yes (per description of a "multi-source benchmark…curated from Cochrane reviews, AHA guidelines") | PARTIAL — described via secondary citation within this paper; primary curation paper not independently retrieved | Secondary citation chain | arxiv.org/pdf/2511.06668 |
| C27 | Red-Teaming Medical AI (medRxiv) — 160 adversarial prompts, dangerous dosing/contraindication/escalation categories | medRxiv preprint | 2026 | Safety red-team dataset | VC-SAFE | Yes | PARTIAL (preprint, general medical assistant, not oncology-specific; physician review "planned") | Preprint, DOI-style medRxiv link | medrxiv.org/content/10.64898/2026.02.26.26347212v1 |
| C28 | Structured Red Teaming — Clinical AI Multi-Agent Platform (PatientGPT), 5-domain rubric, 476 responses | Research Square preprint | 2026 | Safety red-team study + rubric (Table 2) | VC-SAFE, VC-HUMAN | Yes (explicit rubric + scenario table referenced) | PARTIAL (preprint, not oncology-specific; rubric table exists but not reproduced here) | Preprint | researchsquare.com/article/rs-9152209/v1 |
| C29 | AI Safety Training crisis battery (Thousand Voices of Trauma × escalation levels; VERA-MH rubric) | arXiv | 2026 | Mental-health safety scenario battery | VC-SAFE | Yes | NOT SUITABLE for oncology clinical use (mental-health/crisis domain, not oncology) — noted for methodology only | Original | arxiv.org/html/2604.23445v1 |
| C30 | BioSecBench-Refusal — Routine vs Red-Team dual-use biosecurity task benchmark | arXiv | 2026 | Calibrated-refusal benchmark | VC-SAFE (methodology analog) | Yes | NOT SUITABLE directly (biosecurity domain, not oncology) — useful only as a methodology template | Original | arxiv.org/pdf/2607.05462 |
| C31 | Ragas / Arize Phoenix / DeepEval / Confident AI / Evidently / Open RAG Eval — open-source RAG evaluation tooling | Vendor sites / GitHub | ongoing | Technical validation tooling | VC-TECH | Tooling, not cases; some ship example/synthetic test sets | NOT A CASE SOURCE — BACKGROUND / TOOLING REFERENCE | Multiple, mostly primary project sites | getmaxim.ai; confident-ai.com; evidentlyai.com; vectara.com/blog/introducing-open-rag-eval |
| C32 | VerifAI — verifiable open-source biomedical QA search engine (claim-verification against retrieved evidence) | arXiv | 2026 | Technical validation / claim verification tool | VC-TECH, VC-SAFE | Framework, not a case set itself | NOT A CASE SOURCE — BACKGROUND / TOOLING REFERENCE | Original | arxiv.org/pdf/2604.08549 |

---

## 3. Candidate Case Sources
*(Sources confirmed to contain actual cases/scenarios/vignettes/questions, not just background.)*

- **C01** — 5 stepwise NSCLC clinical scenarios, 30 open-ended clinical questions with evidence-based reference answers, expert-rated. Family: VC-CLIN, VC-HUMAN. <cite index="2-1">The study used five stepwise, clinically realistic non-small cell lung cancer scenarios reflecting real-world diagnostic, therapeutic, and follow-up decision-making, with open-ended clinical questions answered by three LLMs and compared against evidence-based reference answers, evaluated via expert-rated clinical accuracy and explainability</cite>. Limitation: lung cancer, not gastric; reference answers/scoring rubric not reproduced here — would need direct access to supplementary material.
- **C04** — 60 curated radiation-oncology vignettes + 300-item exam bank. <cite index="5-1">Performance was assessed using two complementary benchmarks: the ACR Radiation Oncology In-Training Examination (300 multiple-choice items) and a curated set of 60 authentic radiation oncologic vignettes spanning diverse disease sites and treatment indications</cite>. Limitation: radiation oncology, not gastric-cancer specific.
- **C05** — Named public datasets usable for clinical decision-support case sourcing: <cite index="6-1">SEER-derived breast-cancer treatment planning dataset (5-option treatment recommendation task), DDXPlus symptom/diagnosis dialogue dataset, and three MIMIC4ED emergency-medicine outcome-prediction datasets, each with defined evaluation subsamples</cite>. Family: VC-CLIN, VC-TECH. Requires manual review to confirm oncology-specific subset content.
- **C06 — MTBBench**: <cite index="7-1">an agentic benchmark simulating Molecular Tumor Board-style decision-making through clinically challenging, multimodal, longitudinal oncology questions that integrate heterogeneous data types and evolving insights over time</cite>. Family: VC-CLIN, VC-SYS. Strong candidate for oncology-specific test cases; requires review of license/access terms via the linked GitHub/HuggingFace repos.
- **C07 — PMC-Patients**: <cite index="8-1">167,000 patient summaries with 3.1 million patient-article relevance annotations and 293,000 patient-patient similarity annotations, human-evaluated for quality</cite>. Family: VC-TECH, VC-SYS. Case/scenario present as patient-summary retrieval instances (not full clinical-decision vignettes).
- **C11 — GECP01 pancreatic-cancer case-vignette study**: <cite index="12-1">A survey was distributed to centers in the Spanish Group of Pancreatic Surgery describing five imaginary cases of pancreatic cancer corresponding to common scenarios regularly assessed in oncosurgical meetings</cite>. Family: VC-CLIN. Sufficiency: NOT A CASE SOURCE for direct use — the registry record confirms cases exist but does not publish the case text itself; the underlying publication (if any) would need separate retrieval, and the cases concern pancreatic, not gastric, cancer.
- **C24 — MIRAGE**: <cite index="40-1">a benchmark of 7,663 questions drawn from five medical QA datasets, used with the MedRAG toolkit across 41 combinations of corpora, retrievers, and LLMs</cite>. Family: VC-TECH. Strong technical-validation case source for retrieval/grounding testing.
- **C27 — medRxiv red-team set**: <cite index="48-1">160 realistic adversarial prompts spanning dangerous dosing, contraindication bypass, emergency misdirection, and multi-turn escalation categories, tested against several LLMs with an automated harm-level evaluator and physician review planned for high-risk responses</cite>. Family: VC-SAFE. Preprint status and "physician review planned" (not yet completed per this excerpt) limit current sufficiency.
- **C28 — PatientGPT red-team study**: <cite index="45-1">A two-phase adversarial stress test evaluated 476 responses across five safety domains — safety/harm potential, escalation/triage appropriateness, scope adherence, factual accuracy, and completeness of safety-critical elements — with an explicit rubric and named scenario table</cite>. Family: VC-SAFE, VC-HUMAN. The rubric (their Table 2) and scenario table (Table 1) are explicitly cited as existing artifacts but were not reproduced in the retrieved excerpt — REQUIRES MANUAL REVIEW of the full preprint/table to extract verbatim.

---

## 4. Candidate Safety Sources

| ID | Source | What it offers | Limitation |
|---|---|---|---|
| C14/C15 | HaluBench / PubMedQA-based hallucination benchmark; HaluEval, RAGTruthQA, Dolly(NC) compilations | Existing flagged hallucination instances in biomedical QA, usable as candidate safety-challenge source basis | Not oncology-specific; some component datasets (e.g., RAGTruthQA) are general-domain (MS-MARCO-derived) |
| C16 | Med-HALT, UPHILL (via MedHalu secondary description) | Exam-derived reasoning/memory hallucination cases; presupposition/factual-inaccuracy claim sets | Retrieved via secondary citation only — primary sources not independently verified this pass; REQUIRES MANUAL REVIEW |
| C19 | Multi-domain red-teaming framework for medical LLMs | Safety/robustness/equity stress-test scenarios with documented failure-mode analysis | Domain coverage vs. oncology-specificity unconfirmed from excerpt |
| C26 | Cochrane/AHA-sourced evidence-conflict benchmark (via secondary citation) | Candidate basis for "conflicting/outdated evidence" safety cases | Only described secondhand; primary curation paper (cited as ref [27] within C26's source) not retrieved |
| C27 | medRxiv adversarial red-team set (160 prompts) | Contraindication-bypass, dosing, escalation-miss categories with quantified failure rates | General medical assistant context, not oncology; preprint (not peer-reviewed) |
| C28 | PatientGPT structured red-teaming study | 5-domain safety rubric + scenario library, applied at scale (476 responses, inter-rater reliability reported) | Preprint; scenario/rubric tables not extracted verbatim in this pass |

**Explicitly excluded as domain-mismatched (methodology-only relevance):** C29 (mental-health crisis battery) and C30 (biosecurity dual-use benchmark) — useful only as *structural templates* for how a graded safety-challenge battery can be built, not as oncology content sources.

---

## 5. Candidate Technical Sources

| ID | Source | What it offers |
|---|---|---|
| C05, C06, C07 | Named CDS/retrieval datasets (SEER-treatment, DDXPlus, MIMIC4ED, MTBBench, PMC-Patients) | Retrieval- and reasoning-evaluation instances for VC-TECH |
| C23 | MedHELM composite benchmark suite | <cite index="24-1">An extensible evaluation framework spanning nine LLMs across 35 distinct benchmarks covering 22 subcategories of medical tasks, including Clinical Decision Support, using an LLM-jury method whose agreement with clinician ratings exceeded average clinician-clinician agreement</cite> — index of many component technical benchmarks. |
| C24 | MIRAGE/MedRAG toolkit | Retrieval-grounding benchmark with reusable evaluation harness. |
| C25 | MedRAGChecker | <cite index="34-1">A claim-level verification and diagnostic framework that decomposes generated answers into atomic claims and estimates claim support via evidence-grounded natural language inference combined with knowledge-graph consistency, yielding diagnostics for faithfulness, under-evidence, contradiction, and safety-critical error rates</cite> — directly applicable to citation-correctness/provenance-verification testing. |
| C31 | Open-source RAG eval tooling (Ragas, Phoenix, DeepEval, Confident AI, Evidently, Open RAG Eval) | Reusable evaluation harnesses/metrics, not case content — candidate *instrumentation*, not candidate *cases*. |
| C32 | VerifAI | Claim-verification search-engine architecture; <cite index="55-1">studies have found that only around half of generated sentences in biomedical RAG systems are properly cited, and only about three-quarters of those citations actually support the associated claim</cite> — useful as a benchmark figure/context for citation-correctness testing design, not as a case set. |

---

## 6. Candidate Evaluator Sources

| ID | Source | Rubric/instrument offered |
|---|---|---|
| C18 | LLM medical-summarization rubric review | Names existing instruments: <cite index="31-1">the SaferDx tool used for retrospective analysis of GenAI in clinical practice, and the PDQI-9 and Revised-IDEA tools used to compare clinician-written versus GenAI-written clinical documentation</cite>, plus <cite index="31-1">seven broad evaluation criteria spanning hallucination, omission, revision, faithfulness/confidence, bias/harm, groundedness, and fluency</cite>. |
| C20 | CLEVER framework | <cite index="27-1">A framework built on three rubrics — factuality, clinical relevance, and conciseness — validated through blind, randomized, preference-based evaluation by practicing medical doctors</cite>. Reproducible methodology; oncology not the tested domain. |
| C21 | AIPatient Arena | <cite index="29-1">An eight-dimension rubric-based framework covering medical interview questioning skill, information coverage, handling of ambiguous responses, ethical/professional conduct, explanation clarity, information integration, diagnostic accuracy/reasoning, and medication safety/justification</cite>. |
| C22 | MedDialogRubrics | Guideline-grounded "must-ask" item generation pipeline — evaluator instrument construction methodology, not a fixed rubric. |
| C23 (MedHELM) | LLM-jury evaluation method | <cite index="24-1">An LLM-jury evaluation method that achieved better agreement with clinician ratings than either average clinician-clinician agreement or automated baselines such as ROUGE-L and BERTScore-F1</cite>. |
| C32 (background) | Toward Clinical-Grade Evaluation review | Points to <cite index="32-1">Singhal et al.'s framework for clinician and lay-person evaluation of LLM output on biomedical tasks</cite> as a starting-point evaluator instrument — primary framework itself not retrieved this pass; REQUIRES MANUAL REVIEW.

---

## 7. Background-Only Sources
**NOT A CASE SOURCE — BACKGROUND / REFERENCE ONLY**

- C02 — systematic review of 43 oncology CDS evaluation studies (context/landscape only).
- C12 — FREGAT gastric/esophageal biobank (registry/consortium description; no individual case narrative in the retrieved excerpt).
- C11 registry record itself (the underlying case-vignette *content*, if published, would need separate retrieval; the ClinicalTrials.gov page confirms existence but is not the case text).
- C31, C32 — evaluation tooling/frameworks (methodological infrastructure, not case content).

---

## 8. Provenance Audit (shortlisted candidates)

| ID | Original or secondary? | Dataset identifiable? | Version identifiable? | Publication identifiable? | License/access identifiable? | Direct material accessible? | Provenance complete? |
|---|---|---|---|---|---|---|---|
| C01 | Original | Partial (code repo referenced, truncated URL) | NOT FOUND | Yes (Sci Rep, DOI via URL) | NOT FOUND | Partial | PARTIAL |
| C04 | Original/preprint | Partial (60-vignette set named, not released as standalone file per excerpt) | NOT FOUND | Yes (PMCID present) | NOT FOUND | NOT FOUND | PARTIAL |
| C06 (MTBBench) | Original | Yes (HuggingFace dataset ID: EeshaanJain/MTBBench) | NOT FOUND from excerpt | Yes (arXiv ID) | NOT FOUND | Yes (GitHub + HF links) | PARTIAL |
| C07 (PMC-Patients) | Original | Yes (named, large public release) | NOT FOUND from excerpt | Yes (arXiv ID) | NOT FOUND | Likely yes (well-known public dataset) | PARTIAL |
| C11 (GECP01) | Original (registry) | Yes (NCT04755036) | N/A | Registry record confirmed; peer-reviewed publication NOT FOUND this pass | NOT FOUND | NOT FOUND (case text not in registry excerpt) | INSUFFICIENT |
| C20 (CLEVER) | Original | N/A (rubric, not dataset) | NOT FOUND | Yes (JMIR AI, DOI-bearing URL) | NOT FOUND (JMIR AI is open access by norm, not confirmed here) | Yes (published rubric described) | PARTIAL |
| C24 (MIRAGE) | Original | Yes (named benchmark, MedRAG toolkit) | NOT FOUND from excerpt | Yes (arXiv) | NOT FOUND | Likely yes (established public benchmark) | PARTIAL |
| C25 (MedRAGChecker) | Original | Partial (evaluated on 4 named biomedical QA benchmarks, not itself a released case set) | NOT FOUND | Yes (arXiv ID 2601.06519) | NOT FOUND | Partial | PARTIAL |
| C27 (medRxiv red-team) | Original preprint | Partial (160-prompt set described, not confirmed as separately released file) | NOT FOUND | Yes (medRxiv DOI-style link) | NOT FOUND | NOT FOUND | PARTIAL |
| C28 (PatientGPT) | Original preprint | Partial (Table 1/Table 2 referenced but not retrieved) | NOT FOUND | Yes (Research Square) | NOT FOUND | Partial | PARTIAL |

No DOI, PMID, dataset ID, license, or version was invented anywhere in this audit; all "NOT FOUND" fields reflect genuine absence from the retrieved excerpts, not omission.

---

## 9. Suitability Assessment

- **HIGH** — C06 (MTBBench, oncology-specific, multimodal, identifiable repo/dataset), C24 (MIRAGE/MedRAG, technical retrieval-grounding benchmark, well-established), C20 (CLEVER, reusable human-evaluator rubric methodology).
- **MEDIUM** — C01, C04, C05, C07, C23 (MedHELM as an index), C25 (MedRAGChecker), C21/C22 (evaluator rubrics, general not oncology-specific), C14/C15 (hallucination benchmarks, general biomedical not oncology-specific).
- **LOW** — C08, C09, C10, C13 (gastric-cancer datasets, but imaging/biomarker-classification focus, not clinical-decision or safety-scenario content), C16 (secondary-citation only), C26 (secondary-citation only), C27/C28 (preprints, non-oncology domain, key tables not yet extracted).
- **NOT SUITABLE** — C29 (mental-health crisis domain), C30 (biosecurity domain), C02/C12 (background-only, no case content), C31/C32 (tooling, not case content).

---

## 10. Gaps

- **Missing gastric-cancer-specific clinical decision or safety cases.** Every gastric-cancer source found (C08, C09, C10, C12, C13) is either an imaging/histopathology dataset or a biobank/registry — none contains published clinical-decision vignettes, safety-challenge cases, or escalation scenarios specific to gastric adenocarcinoma diagnosis, staging, treatment selection, or survival prognosis. This is the most significant gap relative to the project's actual clinical domain.
- **Missing oncology-specific safety/red-team material.** The strongest red-teaming sources (C27, C28) are general medical-assistant or multi-agent platforms, not oncology-specific; oncology-specific adversarial/safety-boundary case libraries were not located in this pass.
- **Missing evaluator materials calibrated to oncology decision support.** CLEVER, AIPatient Arena, and MedDialogRubrics are general-purpose; no oncology-specific clinician-scoring instrument was found.
- **Missing technical test cases for citation/provenance correctness in a governed RAG system specifically.** MedRAGChecker and VerifAI are the closest fits but are frameworks/methodologies, not off-the-shelf test-case sets.
- **Not searched this pass (recommended for follow-up):** ESMO/NCCN/ASCO official educational case libraries and self-assessment question banks (likely membership/access-gated); PubMed/PMC structured search using MeSH terms for "gastric neoplasms" + "clinical vignette"; GitHub topic search for "oncology-benchmark" / "medical-RAG-eval"; non-English (Vietnamese, French) sources given the project's Vietnam/France context; direct inspection of MTBBench and MIRAGE dataset files for gastric-cancer subset coverage.

---

## 11. Recommended Candidate Shortlist

| Candidate ID | Why relevant | Can potentially support | Cannot support | Provenance quality | Required governance review |
|---|---|---|---|---|---|
| C06 — MTBBench | Oncology-specific, multimodal, longitudinal decision-making structure closely mirrors real tumor-board reasoning | VC-CLIN and VC-SYS case construction (structure/format template); possibly direct case adaptation if license permits | Direct gastric-cancer content (need to check tumor-type coverage inside the dataset) | Medium-high (repo + HF dataset ID present) | License/access review; tumor-type coverage check; governance sign-off before any content reuse |
| C24 — MIRAGE/MedRAG | Established, technically rigorous retrieval-grounding benchmark | VC-TECH case construction for retrieval/citation-grounding validation | Clinical/safety case content (it's QA-format, not scenario/vignette format) | High (established, cited widely) | Confirm license terms for reuse in a governed system |
| C25 — MedRAGChecker | Directly targets faithfulness/under-evidence/contradiction/safety-critical-error detection — matches VC-TECH + VC-SAFE governance goals | Technical validation test design (methodology, not case set) | Cannot itself serve as a source of gastric-oncology content | Medium (framework paper, component datasets need separate audit) | Review whether framework or only its evaluation approach is being adopted |
| C20 — CLEVER | Reusable, clinician-validated 3-rubric structure (factuality/clinical relevance/conciseness) | VC-HUMAN evaluator-instrument design | Oncology-specific weighting/criteria (would need adaptation) | High (peer-reviewed, DOI-bearing) | Confirm reuse/adaptation terms; oncology-specific adaptation would need separate expert review |
| C28 — PatientGPT structured red-teaming | Explicit 5-domain safety rubric + scenario library at meaningful scale (476 responses, inter-rater reliability reported) | VC-SAFE, VC-HUMAN scenario/rubric structure template | Not oncology-specific; preprint status; tables not yet extracted | Medium (preprint, not peer-reviewed) | Full-text retrieval of Tables 1–2 required; treat as structural template only pending peer review |
| C01 — NSCLC oncology LLM benchmark | Closest oncology-domain analog to the project's own use case (stepwise clinical scenarios with reference answers) | VC-CLIN structural template for how to build gastric-cancer stepwise scenarios | Direct gastric content (it is lung-cancer specific) | Medium (peer-reviewed, Sci Rep) | Confirm supplementary-material access for the actual 30 questions/reference answers |

---

## 12. Explicit Non-Generation Statement

No Phase 6 validation cases were invented, synthesized, or fabricated in this search. The identified materials are candidate source materials only and are not Phase 6 validation evidence.
