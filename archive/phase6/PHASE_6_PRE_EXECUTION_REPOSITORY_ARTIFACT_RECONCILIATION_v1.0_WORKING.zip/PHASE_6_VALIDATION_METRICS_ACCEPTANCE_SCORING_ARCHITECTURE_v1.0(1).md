# PHASE 6 --- VALIDATION METRICS, ACCEPTANCE CRITERIA & SCORING ARCHITECTURE

**Document:** Phase 6 Validation Metrics, Acceptance Criteria & Scoring
Architecture\
**Phase:** Phase 6 --- Validation\
**Decision Batch:** 04\
**Version:** 1.0\
**Status:** APPROVED --- LOCKED\
**Approval basis:** V6-B04.1 → V6-B04.14 approved by Project
Coordinator\
**Date:** 2026-08-14

------------------------------------------------------------------------

# 1. Purpose

This document defines the approved architecture for interpreting Phase 6
validation results, evaluating layer-specific performance, classifying
findings, determining blocking status, and producing system-level
acceptance decisions.

It does not prematurely establish numeric thresholds, statistical
methods, or detailed scoring instruments where controlled project
evidence has not yet established them.

------------------------------------------------------------------------

# 2. Inherited Baseline

Phase 6 is:

**Phase 6 --- Validation**

The Architecture / Scope Gate is locked.

The following Decision Batches are locked:

-   Batch 01 --- Architecture / Scope Gate
-   Batch 02 --- Validation Architecture & Evidence Model
-   Batch 03 --- Validation Case, Scenario & Dataset Architecture

Phase 5 remains:

**CLOSED / PASS**

Implementation baseline:

**Task #002 → Task #009**

Final implementation commit:

`0f413c9`

------------------------------------------------------------------------

# 3. Locked Decisions

## V6-B04.1 --- Validation Result Vocabulary

**LOCKED**

Case-level validation results shall use:

-   `PASS`
-   `FAIL`
-   `NOT_APPLICABLE`
-   `INCONCLUSIVE`

`PASS_WITH_CONTROLLED_REMEDIATION` is not a case-level test result. It
is a batch/system-level disposition.

------------------------------------------------------------------------

## V6-B04.2 --- Layer-Specific Evaluation Dimensions

**LOCKED**

### Technical

-   correctness;
-   integration;
-   deterministic behavior;
-   traceability;
-   boundary integrity;
-   regression behavior.

### Clinical

-   clinical accuracy;
-   clinical appropriateness;
-   scope adherence;
-   patient-safety relevance.

### Evidence

-   evidence presence;
-   evidence relevance;
-   provenance;
-   claim-to-evidence fidelity;
-   evidence-insufficiency handling.

### Safety

-   correct safety classification;
-   restrictive behavior;
-   escalation;
-   emergency precedence;
-   fail-closed behavior.

### Human

-   clinical accuracy;
-   patient safety;
-   communication quality;
-   boundary recognition;
-   uncertainty recognition;
-   escalation recognition.

------------------------------------------------------------------------

## V6-B04.3 --- Technical Validation Metric Families

**LOCKED**

Technical validation shall use requirement-specific metric families
including:

-   functional correctness;
-   boundary compliance;
-   integration correctness;
-   determinism/consistency;
-   traceability completeness;
-   regression status.

A single aggregate technical score shall not replace
requirement-specific evidence.

------------------------------------------------------------------------

## V6-B04.4 --- Clinical Validation Dimensions

**LOCKED**

Clinical validation shall evaluate:

-   clinical correctness;
-   clinical relevance;
-   clinical appropriateness;
-   scope adherence;
-   safety relevance.

Clinical validation shall not be reduced to automated factuality
metrics.

------------------------------------------------------------------------

## V6-B04.5 --- Evidence-Fidelity Dimensions

**LOCKED**

Evidence fidelity shall assess:

``` text
Evidence Present?
        ↓
Relevant?
        ↓
Supports Claim?
        ↓
Correct Provenance?
        ↓
Meaning Preserved?
        ↓
Insufficiency Handled Correctly?
```

Citation presence alone is insufficient to establish evidence fidelity.

------------------------------------------------------------------------

## V6-B04.6 --- Safety Behavioral Scoring

**LOCKED**

Safety cases shall be evaluated primarily through expected-action
matching:

``` text
Expected Safety Action
        vs
Observed Safety Action
```

A safety-critical incorrect action shall not be hidden by aggregate
scoring.

------------------------------------------------------------------------

## V6-B04.7 --- Human-Evaluation Dimensions

**LOCKED**

Human evaluation shall assess:

1.  Clinical Accuracy
2.  Patient Safety
3.  Communication Quality
4.  Boundary Recognition
5.  Uncertainty Recognition
6.  Escalation Recognition

Exact scale and evaluator instrument remain deferred.

------------------------------------------------------------------------

## V6-B04.8 --- System-Level Acceptance Model

**LOCKED**

System-level acceptance shall not be calculated as a simple arithmetic
average of layer scores.

The acceptance model is:

``` text
Layer Results
    ↓
Critical Finding Review
    ↓
Acceptance Criteria
    ↓
Risk Disposition
    ↓
System-Level Decision
```

------------------------------------------------------------------------

## V6-B04.9 --- Finding Severity Vocabulary

**LOCKED**

Findings shall use the following high-level severity vocabulary:

-   `CRITICAL`
-   `MAJOR`
-   `MINOR`
-   `OBSERVATION`

Detailed operational definitions remain subject to the subsequent risk/
disposition architecture decision.

------------------------------------------------------------------------

## V6-B04.10 --- Blocking / Non-Blocking

**LOCKED**

A finding is blocking when it can invalidate a core:

-   safety boundary;
-   clinical correctness requirement;
-   evidence-fidelity requirement;
-   human-oversight requirement;
-   mandatory acceptance criterion.

Non-blocking findings may be remediated under controlled disposition
when they do not invalidate the acceptance basis.

------------------------------------------------------------------------

## V6-B04.11 --- Minimum Evidence for PASS

**LOCKED**

A PASS requires:

``` text
Requirement identified
+
Case executed
+
Expected behavior defined
+
Observed behavior recorded
+
Supporting evidence present
+
No unresolved blocking finding
```

Without sufficient supporting evidence, the result shall not be treated
as PASS.

------------------------------------------------------------------------

## V6-B04.12 --- PASS WITH CONTROLLED REMEDIATION

**LOCKED**

A batch/system may receive `PASS_WITH_CONTROLLED_REMEDIATION` only when:

-   core acceptance criteria are met;
-   no unresolved critical/blocking safety defect remains;
-   residual findings are formally dispositioned;
-   remediation has traceable ownership and action;
-   re-validation triggers are identified;
-   remediation does not invalidate the acceptance basis.

This disposition shall not be used to mask a failed critical test.

------------------------------------------------------------------------

## V6-B04.13 --- FAIL Conditions

**LOCKED**

A batch/system shall FAIL when there is:

-   an unresolved critical finding;
-   a blocking safety failure;
-   clinically unacceptable behavior;
-   an evidence/provenance failure affecting core claims;
-   a failed mandatory acceptance criterion;
-   insufficient evidence to support the claimed acceptance decision.

------------------------------------------------------------------------

## V6-B04.14 --- Cross-Layer Aggregation and Non-Overclaim

**LOCKED**

Phase 6 conclusions shall preserve the distinction:

``` text
Technical Validation
≠
Clinical Validation
≠
Safety Validation
≠
Human Evaluation
≠
Deployment Readiness
```

Final conclusions shall state precisely what was validated, against
which criteria, with what evidence, and with what residual risks.

Phase 6 PASS shall not automatically be represented as:

-   unrestricted clinical deployment;
-   regulatory approval;
-   patient-specific medical approval;
-   production authorization beyond the approved acceptance scope.

------------------------------------------------------------------------

# 4. Acceptance Decision Architecture

The controlled hierarchy is:

``` text
Case Result
    ↓
Case Finding / Evidence
    ↓
Batch Result
    ↓
Finding Severity / Blocking Status
    ↓
Batch Disposition
    ↓
System-Level Acceptance
```

Case-level PASS therefore does not independently determine system-level
PASS.

------------------------------------------------------------------------

# 5. Safety-Critical Override Principle

Where a safety-critical finding conflicts with aggregate performance,
the safety-critical finding retains precedence.

Conceptually:

``` text
Strong aggregate results
        +
Critical safety failure
        ↓
NOT ACCEPTED
```

The system shall not compensate for a critical safety failure through
strong performance in unrelated validation dimensions.

------------------------------------------------------------------------

# 6. Evidence Sufficiency Principle

A validation conclusion must be proportionate to its evidence.

The acceptance statement shall not exceed what the validation evidence
demonstrates.

Therefore:

``` text
Evidence
   ↓
Validated Claim
   ↓
Acceptance Statement
```

and not:

``` text
Limited Evidence
   ↓
Broad Clinical Claim
```

------------------------------------------------------------------------

# 7. Deferred Decisions

The following remain intentionally open:

-   exact numeric thresholds;
-   statistical tests;
-   evaluator scoring scale;
-   detailed severity definitions;
-   detailed blocking matrix;
-   exact scoring sheets;
-   final aggregate reporting format.

These shall be addressed in subsequent Decision Batches using the
relevant controlled project materials.

------------------------------------------------------------------------

# 8. Next Decision Batch

## Decision Batch 05 --- Validation Risk, Finding & Disposition Architecture

### Purpose

Define the operational risk and finding-management architecture that
sits between validation observations and final acceptance decisions.

### Proposed Must-Decide-Now Topics

1.  Finding lifecycle and state model.
2.  Operational definitions for CRITICAL / MAJOR / MINOR / OBSERVATION.
3.  Blocking decision matrix.
4.  Safety-critical finding precedence.
5.  Clinical/evidence-critical finding handling.
6.  Risk dimensions and risk classification.
7.  Residual-risk documentation.
8.  Remediation ownership and due-state.
9.  Re-test vs re-validation decision logic.
10. Escalation triggers.
11. Finding closure criteria.
12. Acceptance impact of open findings.
13. Cross-batch finding deduplication and linkage.
14. Final disposition authority.
15. Traceability of finding → remediation → re-validation → closure.

### Intentionally Deferred

-   project-specific numeric risk thresholds where controlled source
    material has not yet established them;
-   exact remediation timelines;
-   final issue-tracker implementation;
-   detailed statistical treatment;
-   final Phase 6 closure report format.

------------------------------------------------------------------------

# 9. Decision Status

**V6-B04.1 → V6-B04.14: APPROVED → LOCKED**

**Phase 6 Validation Metrics / Acceptance / Scoring Architecture:
LOCKED**

**Validation Execution: NOT STARTED**

**Next Decision Batch: V6-B05 --- Validation Risk, Finding & Disposition
Architecture**
