**# 1. Search Scope**

Searches targeted existing candidate source materials for Phase 6 Validation (Safe Medical AI Oncology), prioritizing gastric adenocarcinoma / upper-GI / GI oncology, then broader oncology and general medical evaluation/safety materials. Queries covered clinical case/vignette sources, multimodal benchmarks with patient cases or QA, evaluator instruments, safety/red-team datasets and taxonomies, technical validation tools (citation/provenance/RAG faithfulness), and clinical guidelines as background references only.

Primary sources examined: arXiv papers and HTML versions, Hugging Face dataset cards, GitHub repositories, official guideline pages (NCCN/ESMO), PubMed/PMC, and related dataset descriptions. No transformation, synthesis, or adaptation of materials into new cases, scenarios, or prompts was performed. All classifications follow the mandated PRIMARY TYPE and validation-family rules. Missing provenance fields are recorded as NOT FOUND.

**# 2. Candidate Source Inventory**

| ID | Material | Primary Type | Validation Family | Case/Scenario Present? | Gastric Relevance | Provenance | License | Sufficiency | Status |
|----|----------|--------------|-------------------|------------------------|-------------------|------------|---------|-------------|--------|
| S1 | Gastric-X | DATASET_BENCHMARK | VC-TECH, VC-CLIN | Yes (1.7K multimodal cases + VQA) | DIRECT GASTRIC RELEVANCE | arXiv:2603.19516 (2026); HF HaoChen2/Gastric-X; authors Lu/Chen/Yin et al. | CC BY-NC-ND 4.0 (non-commercial, no derivatives, no redistribution) | High for multimodal gastric VLM tasks | CANDIDATE — DISCOVERY ONLY |
| S2 | MTBBench | DATASET_BENCHMARK | VC-TECH, VC-CLIN, VC-SYS | Yes (26 multimodal + 40 longitudinal cases + QA) | ONCOLOGY ANALOG (head-neck; MSK-CHORD multi-cancer) | arXiv:2511.20490 (2025); HF EeshaanJain/MTBBench; GitHub bunnelab/MTBBench | Underlying HANCOCK CC BY 4.0; MSK-CHORD CC BY-NC-ND 4.0; paper CC BY 4.0 | High for agentic MTB-style sequential reasoning | CANDIDATE — DISCOVERY ONLY |
| S3 | Red Teaming LLMs in Medicine (Daneshjou Lab) | SAFETY_INSTRUMENT | VC-SAFE | Yes (376 prompts / scenarios) | GENERAL METHODOLOGICAL SOURCE | npj Digital Medicine 2025; GitHub/site daneshjoulab; Chang/Farah/Gui et al. | Public CSV + datasheet (check site for exact terms) | Medium–high for general medical safety/privacy/hallucination/bias | CANDIDATE — DISCOVERY ONLY |
| S4 | PatientSafetyBench (Microsoft) | SAFETY_INSTRUMENT | VC-SAFE | Yes (~466–609 patient-perspective queries) | GENERAL METHODOLOGICAL SOURCE (some cancer-related) | HF microsoft/PatientSafetyBench; arXiv 2507.07248 | CDLA-Permissive-2.0 | Medium for patient-facing safety red-teaming | CANDIDATE — DISCOVERY ONLY |
| S5 | Multi-Domain Red Teaming Framework (690 scenarios) | SAFETY_INSTRUMENT | VC-SAFE | Yes (research-generated scenarios) | GENERAL METHODOLOGICAL SOURCE | arXiv:2606.00027 (2026) | NOT FOUND (paper only) | Medium | CANDIDATE — DISCOVERY ONLY |
| S6 | MedQA / MedMCQA / PubMedQA | DATASET_BENCHMARK | VC-TECH, VC-CLIN | Yes (exam/abstract QA items; oncology subset possible) | GENERAL METHODOLOGICAL SOURCE / ONCOLOGY ANALOG | Multiple papers (Jin et al., Pal et al., etc.); public releases | Varies (often open for research) | Medium for knowledge/clinical QA | CANDIDATE — DISCOVERY ONLY |
| S7 | NCCN Gastric Cancer Guidelines | BACKGROUND_CLINICAL_REFERENCE | VC-CLIN | No | DIRECT GASTRIC RELEVANCE | JNCCN / NCCN.org (Version 2.2025 and updates) | Proprietary / institutional access | High as evidence standard | BACKGROUND ONLY |
| S8 | ESMO Gastric Cancer CPG + Pan-Asian adaptation | BACKGROUND_CLINICAL_REFERENCE | VC-CLIN | No | DIRECT GASTRIC RELEVANCE | Ann Oncol / ESMO.org (2022 + living updates; PAGA 2024) | ESMO terms | High as evidence standard | BACKGROUND ONLY |
| S9 | PatchGastricADC22 + related pathology sets | DATASET_BENCHMARK | VC-TECH | Image/patch cases | DIRECT GASTRIC RELEVANCE | Public pathology releases (Mita Hospital origin; used in captioning papers) | Varies; check source | Medium for pathology VLM | CANDIDATE — DISCOVERY ONLY |
| S10 | GRACE / gastric pathology foundation model cohorts | DATASET_BENCHMARK / TECHNICAL | VC-TECH | Large WSI cohorts (training/validation) | DIRECT GASTRIC RELEVANCE | arXiv:2606.04792 (2026) | NOT FOUND (institutional multi-center) | Medium (access restricted) | REQUIRES MANUAL REVIEW |

Additional lower-priority items (endoscopy image sets, MIMIC-derived ClinicalBench, fictional communication packs, etc.) classified as ONCOLOGY ANALOG or GENERAL and largely TECHNICAL or NOT_SUITABLE for primary case sourcing.

**# 3. Actual Case Sources**

Only materials that demonstrably contain existing cases, vignettes, QA items, or equivalent source-grounded instances:

- **Gastric-X**: 1.7K real-workflow multimodal cases (multi-phase CT, endoscopy, labs, expert diagnostic notes, bounding boxes, VQA pairs). DIRECT GASTRIC. Research-generated VQA components exist but are grounded in the clinical data.
- **MTBBench**: 26 HANCOCK head-and-neck multimodal cases + 40 MSK-CHORD longitudinal cases with clinician-validated QA. ONCOLOGY ANALOG (no confirmed gastric subset in primary sources).
- Red-teaming prompt sets (Daneshjou, PatientSafetyBench, multi-domain frameworks): RESEARCH-GENERATED SAFETY / EVALUATION MATERIAL containing clinical scenarios/prompts. Not real clinical cases.
- MedQA / MedMCQA / PubMedQA: Exam-style or abstract-derived QA items (some oncology content possible via filtering). GENERAL.
- Pathology image/patch collections (e.g., PatchGastricADC22): Image-level cases with diagnostic labels. DIRECT GASTRIC for pathology tasks.

No published tumor-board vignette banks or de-identified gastric adenocarcinoma case series with full clinical narratives suitable for direct Phase 6 use were identified beyond the above multimodal sets.

**# 4. Dataset / Benchmark Sources**

- Gastric-X (primary gastric multimodal VLM benchmark).
- MTBBench (agentic sequential MTB-style oncology benchmark).
- Standard medical QA suites (MedQA, MedMCQA, PubMedQA) and pathology image sets.
- Supporting cohorts used in GRACE and related gastric pathology models (access typically restricted).

**# 5. Evaluator Instruments**

Limited dedicated published clinical evaluator rubrics for oncology AI were located. MTBBench and Gastric-X include clinician-validated ground truth and task definitions that can serve as methodological references. Red-team papers supply multi-axis labeling frameworks (Safety/Privacy/Hallucination/Bias). No standalone validated Phase-6-style multi-family evaluator instrument was found.

**# 6. Safety Instruments**

- Daneshjou Lab Red-Teaming Dataset (376 clinically relevant prompts; Safety/Privacy/Hallucination/Bias taxonomy).
- PatientSafetyBench (patient-perspective unsafe medical advice queries).
- Multi-domain red-teaming frameworks with 690+ scenarios and adversarial mutation methods (RESEARCH-GENERATED).
- Related PIEE-cycle and DAS frameworks (methodological).

All are GENERAL METHODOLOGICAL SOURCES; none are gastric-specific case banks.

**# 7. Technical Validation Instruments**

Gastric-X and MTBBench embed technical tasks (VQA, report generation, cross-modal retrieval, lesion localization, sequential multi-modal reasoning). Broader RAG/citation/provenance evaluators and faithfulness metrics exist in the literature but were not gastric- or oncology-specific in the searches performed. Classify as TECHNICAL_VALIDATION_INSTRUMENT when they release test cases; otherwise methodological only.

**# 8. Background Clinical References**

- NCCN Gastric Cancer Guidelines (current versions, e.g., 2.2025).
- ESMO Gastric Cancer Clinical Practice Guideline (2022 + living updates) and Pan-Asian adaptation.
- Related CSCO / JGCA / KGCA guidelines (comparative literature exists).

**Explicit label: NOT A CASE SOURCE.** These supply evidence standards and recommendation frameworks only. Do not convert guideline statements into validation cases.

**# 9. Conflicts / Contradictions**

- MTBBench disease coverage: Primary sources (paper, HF, GitHub) consistently describe head-and-neck (HANCOCK) and multi-cancer longitudinal (MSK-CHORD) cases. No primary-source confirmation of gastric cases. Any secondary claim of gastric inclusion is CONFLICT DETECTED → REQUIRES MANUAL REVIEW of original dataset cards and supplementary materials.
- Gastric-X license/access: Paper and HF card both state CC BY-NC-ND 4.0 with explicit non-commercial / no-derivatives / no-redistribution terms and access form. No contradiction found.
- Red-team dataset sizes and exact content: Minor numerical variations across papers vs. downloadable files; resolve via primary CSV/datasheet download.

Unresolved items flagged REQUIRES MANUAL REVIEW.

**# 10. Provenance Audit**

- Gastric-X: Full (arXiv DOI/version, authors, HF repo, 2026, CC BY-NC-ND). IRB noted in paper.
- MTBBench: Full (arXiv, HF, GitHub, underlying dataset licenses, clinician validation described).
- Daneshjou red-team: Full (journal DOI, public CSV + datasheet + synthetic notes).
- PatientSafetyBench: HF card + arXiv.
- Guidelines: Official organization sites / JNCCN / Ann Oncol; versioned.
- Many pathology cohorts and secondary benchmarks: Partial (paper available; full license/access/ dataset ID often NOT FOUND or restricted).

Never inferred.

**# 11. License / Reuse Audit**

- Gastric-X: Non-commercial research/education only; no derivatives; no redistribution. DIRECT USE of released artifacts possible under terms; DERIVATIVE USE (case transformation, redistribution of subsets) prohibited. Attribution required. Access via HF form.
- MTBBench / HANCOCK: More permissive (CC BY components); MSK-CHORD non-commercial/no-derivatives. Check each component.
- Red-team sets: Generally research-permissive (public download); confirm commercial and derivative clauses.
- Guidelines: Institutional/non-commercial clinical reference use; redistribution restricted.
- Distinction: DIRECT USE (as-is evaluation) vs. DERIVATIVE USE (adaptation into new vignettes) vs. METHODOLOGICAL REFERENCE only. Most strong gastric sources lean heavily toward the first or third under current licenses.

**# 12. Gastric-Specific Gaps**

- Scarcity of fully released, de-identified, narrative clinical vignettes or tumor-board case banks specifically for gastric adenocarcinoma that are licensed for validation reuse.
- Multimodal imaging + lab + report sets exist (Gastric-X) but are constrained by non-derivative / non-redistribution terms.
- Safety instruments are almost entirely general-medical rather than gastric- or GI-oncology-specific.
- No identified public gastric-specific evaluator rubrics or safety taxonomies aligned to the Phase 6 Clinical State × User Intent × Evidence × Safety × Boundary dimensions.
- Longitudinal genomic + clinical trajectory data for gastric cases under open licenses remains limited.

**# 13. Recommended Shortlist**

**A. Direct candidate case sources**  
Gastric-X (multimodal cases + VQA); selected pathology image/patch collections with gastric adenocarcinoma labels.

**B. Dataset/benchmark sources**  
Gastric-X; MTBBench (oncology analog); MedQA/MedMCQA/PubMedQA (filterable).

**C. Evaluator instruments**  
Task definitions and clinician-validation processes from Gastric-X and MTBBench (methodological).

**D. Safety instruments**  
Daneshjou Lab red-team dataset; PatientSafetyBench; multi-domain red-teaming scenario sets (all GENERAL).

**E. Technical validation instruments**  
Embedded tasks in Gastric-X and MTBBench; general RAG/faithfulness tools (methodological).

**F. Background references**  
NCCN and ESMO gastric guidelines (and comparative Eastern/Western reviews).

**# 14. Governance Status**

All items: **CANDIDATE — DISCOVERY ONLY** or **BACKGROUND ONLY** or **REQUIRES MANUAL REVIEW** (access/license/primary-source verification needed).  
None marked VALIDATION PASS, VALIDATION READY, VALIDATION EVIDENCE, or ACCEPTED. Governance review of license, IRB/provenance, and suitability for controlled Phase 6 use remains outstanding.

**# 15. Explicit Non-Generation Statement**

No Phase 6 validation cases were invented, synthesized, transformed, or fabricated. Candidate materials remain discovery-stage inputs and are not Phase 6 validation evidence.