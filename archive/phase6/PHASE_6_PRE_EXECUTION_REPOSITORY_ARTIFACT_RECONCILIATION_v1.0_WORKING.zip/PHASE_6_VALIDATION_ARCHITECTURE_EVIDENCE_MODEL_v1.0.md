# PHASE 6 --- VALIDATION ARCHITECTURE & EVIDENCE MODEL

**Document:** Phase 6 Validation Architecture & Evidence Model\
**Phase:** Phase 6 --- Validation\
**Decision Batch:** 02\
**Version:** 1.0\
**Status:** APPROVED --- LOCKED\
**Approval basis:** V6-B02.1 → V6-B02.12 approved by Project
Coordinator\
**Date:** 2026-08-14

------------------------------------------------------------------------

# 1. Purpose

This document defines the approved operational architecture for
structuring, evidencing, tracing, reviewing, and dispositioning Phase 6
validation.

It implements the locked Phase 6 Architecture / Scope Gate without
redefining Phase 6 scope.

The objective is to establish a common validation model before detailed
validation cases, datasets, metrics, thresholds, evaluator protocols, or
tooling are defined.

------------------------------------------------------------------------

# 2. Inherited Phase 6 Boundary

Phase 6 is:

**Phase 6 --- Validation**

The Architecture / Scope Gate is the Phase 6 entry gate.

The approved validation layers are:

1.  Technical / Architectural Validation
2.  Clinical Knowledge & Evidence Validation
3.  Safety / Behavioral Validation
4.  Human-Oversight / User Evaluation
5.  System-Level Acceptance & Risk Disposition

Phase 5 remains the inherited implementation baseline:

**Task #002 → Task #009 --- PASS**

Final Phase 5 implementation commit:

`0f413c9`

Phase 5 remains CLOSED / PASS and is not reopened by this Decision
Batch.

------------------------------------------------------------------------

# 3. Locked Decisions

## V6-B02.1 --- Validation Requirement Taxonomy

**LOCKED**

Validation requirements shall use five primary classes:

-   `VR-TECH` --- Technical / Architectural
-   `VR-CLIN` --- Clinical Knowledge / Evidence
-   `VR-SAFE` --- Safety / Behavioral
-   `VR-HUMAN` --- Human-Oversight / User
-   `VR-SYS` --- System-Level Acceptance

Each validation requirement shall have a stable identity.

------------------------------------------------------------------------

## V6-B02.2 --- Validation Evidence Unit

**LOCKED**

The atomic validation evidence unit is:

``` text
Validation Requirement
        ↓
Validation Case / Scenario
        ↓
Expected Behavior
        ↓
Observed Result
        ↓
Evidence
        ↓
Disposition
```

A bare PASS/FAIL without supporting evidence is insufficient for final
validation evidence.

------------------------------------------------------------------------

## V6-B02.3 --- Validation Case Structure

**LOCKED**

A validation case shall contain, at minimum:

-   Validation ID
-   Validation Layer
-   Scenario ID
-   Objective
-   Preconditions
-   Input / Case
-   Expected Behavior
-   Observed Behavior
-   Evidence
-   Result
-   Finding, if applicable
-   Risk, if applicable
-   Disposition
-   Traceability references

Exact implementation schema is deferred.

------------------------------------------------------------------------

## V6-B02.4 --- End-to-End Scenario as a First-Class Validation Object

**LOCKED**

Phase 6 shall include end-to-end validation scenarios in addition to
isolated technical or component-level validation.

The canonical system-level path is:

``` text
User Request
    ↓
Safety Authorization
    ↓
Clinical Navigation
    ↓
Retrieval
    ↓
Runtime Evidence Package
    ↓
Runtime Integration
    ↓
Generation
    ↓
Output Validation
    ↓
Safety / Delivery Disposition
```

The exact scenario inventory is deferred.

------------------------------------------------------------------------

## V6-B02.5 --- Clinical Patient-Journey Scenario Basis

**LOCKED**

Clinical validation scenarios shall be grounded in the project's
existing clinical navigation and patient-journey model.

The scenario architecture shall consider combinations of:

``` text
Clinical State
+
User Intent
+
Evidence / Safety Condition
```

Exact scenario inventory and sampling strategy are deferred.

------------------------------------------------------------------------

## V6-B02.6 --- Evidence Fidelity Validation

**LOCKED**

Evidence fidelity shall be evaluated across the evidence lineage:

``` text
Claim
 ↓
Candidate Response
 ↓
Runtime Evidence Package
 ↓
Knowledge Asset / Population Package
 ↓
Primary Evidence / Source
```

Validation shall assess, as applicable:

-   evidence presence;
-   evidence relevance;
-   provenance preservation;
-   claim-to-evidence traceability;
-   evidence insufficiency behavior;
-   avoidance of silent uncontrolled supplementation.

------------------------------------------------------------------------

## V6-B02.7 --- Safety Behavioral Validation

**LOCKED**

Safety validation shall evaluate behavioral transitions rather than
merely checking the existence of safety components.

The validation model shall cover, as applicable:

-   `ALLOW`
-   `ALLOW_WITH_WARNING`
-   `ASK_CLARIFICATION`
-   `REDIRECT`
-   `ESCALATE`
-   `REJECT`
-   emergency handling
-   fail-closed behavior

Locked Phase 5 safety semantics remain authoritative.

------------------------------------------------------------------------

## V6-B02.8 --- Human Evaluation Model

**LOCKED**

Human evaluation shall assess, at minimum:

1.  Clinical Accuracy
2.  Patient Safety
3.  Communication Quality

It shall additionally assess, where applicable:

-   recognition of system limitations;
-   understanding of uncertainty;
-   understanding of escalation;
-   interpretation of refusal/redirect behavior;
-   recognition of situations requiring human intervention;
-   risk of interpreting the system as unrestricted clinical authority.

Exact evaluator protocol is deferred.

------------------------------------------------------------------------

## V6-B02.9 --- Finding / Defect Classification

**LOCKED**

A failed, anomalous, or safety-relevant validation result shall become a
traceable Finding.

The lifecycle is:

``` text
Finding
  ↓
Classification
  ↓
Severity / Impact
  ↓
Risk
  ↓
Disposition
```

Permitted high-level dispositions:

-   `ACCEPT`
-   `REMEDIATE`
-   `RETEST`
-   `REVALIDATE`
-   `ESCALATE`

Detailed severity taxonomy is deferred.

------------------------------------------------------------------------

## V6-B02.10 --- Re-validation Trigger Principle

**LOCKED**

Re-validation shall be required when an approved remediation or change
may affect previously validated:

-   system behavior;
-   safety behavior;
-   evidence fidelity;
-   traceability;
-   clinical behavior;
-   acceptance criteria.

Administrative or non-behavioral corrections do not automatically
require a full Phase 6 rerun.

The detailed impact matrix is deferred.

------------------------------------------------------------------------

## V6-B02.11 --- Validation Record Lifecycle

**LOCKED**

Validation records shall follow:

``` text
DRAFT
  ↓
EXECUTED
  ↓
REVIEWED
  ↓
DISPOSITIONED
  ↓
ACCEPTED / REQUIRES REMEDIATION
```

A validation batch cannot contribute to final Phase 6 closure while
required findings remain unreviewed.

Validation records shall preserve sufficient version/context information
to support reproducibility.

------------------------------------------------------------------------

## V6-B02.12 --- Bidirectional Validation Traceability

**LOCKED**

Phase 6 shall support bidirectional traceability:

``` text
Requirement
   ↕
Validation Case
   ↕
Evidence
   ↕
Finding
   ↕
Risk
   ↕
Disposition
```

System lineage shall also be traceable:

``` text
Validation Case
 ↓
System Input
 ↓
Navigation Context
 ↓
Safety Decision
 ↓
Retrieval
 ↓
Runtime Evidence Package
 ↓
GenerationContext
 ↓
Candidate Response
 ↓
Validation Result
 ↓
Final Behavioral Disposition
```

------------------------------------------------------------------------

# 4. Validation Architecture

The approved architecture is:

``` text
                VALIDATION REQUIREMENTS
                         │
                         ▼
               VALIDATION CASES
                         │
              ┌──────────┼──────────┐
              ▼          ▼          ▼
          Technical   Clinical    Safety
              │          │          │
              └──────┬───┴──────┬───┘
                     ▼          ▼
                Human Evaluation
                     │
                     ▼
             System Acceptance
                     │
                     ▼
              Risk / Disposition
                     │
              ┌──────┴──────┐
              ▼             ▼
          Accepted       Remediation
                            │
                            ▼
                        Re-validation
```

------------------------------------------------------------------------

# 5. Evidence and Traceability Principle

Phase 6 validation evidence must be sufficient to reconstruct:

1.  what requirement was evaluated;
2.  what case/scenario was used;
3.  what system state and relevant versions applied;
4.  what behavior was expected;
5.  what behavior was observed;
6.  what evidence supports the observation;
7.  what finding/risk was identified;
8.  what disposition was made.

This principle applies across all five validation layers.

------------------------------------------------------------------------

# 6. Controlled Relationship to Existing Frameworks

Batch 02 does not create a competing evaluation or safety framework.

It operationalizes the existing project frameworks, including:

-   System Evaluation Framework;
-   Safety Framework;
-   Clinical Navigation Engine;
-   Medical Governance;
-   Output Validation Framework;
-   existing Phase 5 validation and safety boundaries.

Where an existing Stable Document already defines a controlled behavior,
Phase 6 validates that behavior rather than redefining it.

------------------------------------------------------------------------

# 7. Deferred Decisions

The following remain intentionally open:

-   exact validation dataset;
-   exact number of cases;
-   exact clinical scenario inventory;
-   exact technical metrics;
-   exact acceptance thresholds;
-   evaluator recruitment and composition;
-   statistical analysis methodology;
-   detailed finding severity matrix;
-   exact validation artifact schema;
-   exact filenames;
-   implementation of validation tooling.

These items shall be resolved through subsequent Decision Batches.

------------------------------------------------------------------------

# 8. Next Decision Batch

## Decision Batch 03 --- Validation Case, Scenario & Dataset Architecture

### Purpose

Define the architecture for selecting, structuring, versioning, and
controlling the validation cases, clinical scenarios, datasets, and
evaluation inputs used by Phase 6.

### Proposed Must-Decide-Now Topics

1.  Validation case families by validation layer.
2.  Clinical scenario dimensions.
3.  Scenario coverage model.
4.  Technical test-set architecture.
5.  Clinical evaluation-set architecture.
6.  Safety challenge-set architecture.
7.  Human-evaluation case architecture.
8.  Dataset/source provenance requirements.
9.  Versioning and immutability requirements.
10. Leakage / contamination controls.
11. Case-to-requirement mapping.
12. Dataset-to-validation-record mapping.
13. Sampling principles.
14. Minimum evidence required before a validation set is accepted for
    execution.

### Intentionally Deferred

-   exact case counts;
-   final clinical scenario list;
-   statistical power/sample-size calculations;
-   final acceptance thresholds;
-   evaluator recruitment;
-   detailed scoring rubric.

------------------------------------------------------------------------

# 9. Decision Status

**V6-B02.1 → V6-B02.12: APPROVED → LOCKED**

**Phase 6 Validation Architecture / Evidence Model: LOCKED**

**Phase 6 Validation Execution: NOT STARTED**

**Next Decision Batch: V6-B03 --- Validation Case, Scenario & Dataset
Architecture**
