# LEGACY UI REFERENCE — HANDOFF INSTRUCTIONS

## What to give Claude Code

Provide the **source-code folder/project** for the old gastric-cancer-nomogram website that corresponds to:

`https://gastric-cancer-nomogram.netlify.app/`

The preferred reference is the complete legacy frontend source folder (for example the project containing its UI components, styles, assets, and frontend source files), not merely a screenshot.

## What Claude may use

Only inspect/reuse/adapt UI/UX presentation patterns:
- layout;
- header/navigation;
- typography;
- spacing;
- cards;
- visual hierarchy;
- interaction/presentation patterns.

## What Claude must not import

Do NOT import or reuse:
- calculation/model code;
- model coefficients/parameters;
- clinical logic;
- clinical data;
- survival/logistic calculation logic;
- legacy backend;
- legacy application architecture;
- unrelated business/domain logic.

## Practical handoff

Place the old project source in the Claude project as a clearly named reference folder, e.g.:

`legacy-ui-reference/gastric-cancer-nomogram/`

Claude should inspect it but must not treat it as the Phase 6 application source tree.

The Phase 6 repository remains the authoritative implementation source.
