# PHASE 6 — STAGE 2
## Track 1C — Controlled Chat UI — Usability / Presentation Polish
### Implementation Specification v1.0

**Status:** APPROVED / READY FOR CLAUDE CODE INSPECTION  
**Phase:** Phase 6 — Stage 2  
**Purpose:** Bounded UI/UX enhancement only.

---

## 1. Objective

Upgrade the existing Phase 6 Controlled Chat UI from a functional prototype into a professional, readable, patient-oriented controlled research interface.

The UI must directly support the Phase 6 ultimate goal:

> A real browser-based chatbot interface that can be used for controlled testing and real-world feedback, while clearly declaring that the system is not clinically validated and is not for clinical decision-making.

Track 1C is a presentation/interaction enhancement. It does not change the governed CER execution architecture.

---

## 2. Approved product/UX direction

Position the interface as:

**Safe Medical AI Oncology — Controlled Research Interface**

Primary interaction concept:

**Understand → Ask → Explore**

The interface should not begin as an empty generic chatbot. It should help a user who does not know what to ask.

Approved patient-centered entry point:

> **Not sure what to ask? Start with your situation.**

This is an orientation mechanism, not clinical triage.

---

## 3. Approved two-tier question guidance

### Tier 1 — Situation

Provide patient-centered situation cards, such as:

- I was recently diagnosed
- I'm receiving treatment
- I'm preparing for surgery
- I'm concerned about recurrence
- I'm in follow-up
- I want to understand my cancer

The exact visual labels may be refined for clarity, but the interaction must remain patient-oriented and non-prescriptive.

### Tier 2 — Topic / question guidance

After a situation is selected, show relevant topics and curated question starters.

Concept:

Situation → Topic → Question starter

A question starter must:

1. be selected by the user;
2. populate the existing chat input;
3. remain editable by the user;
4. require the user's existing Send action to submit.

**Do not auto-submit a question starter.**

---

## 4. Approved UI scope

Track 1C may improve:

- layout;
- typography;
- spacing;
- visual hierarchy;
- header / application identity;
- conversation presentation;
- situation cards;
- topic presentation;
- question-starter presentation;
- input/send experience;
- loading state;
- error state;
- controlled-execution status presentation;
- disclaimer visibility;
- basic responsive browser layout;
- accessible/clear interaction states.

The result should no longer feel like a bare prototype. It should look and behave like a serious oncology research application.

---

## 5. Governance / safety presentation

The interface must make the system boundary clear without overwhelming the user.

Recommended visible identity:

**RESEARCH / CONTROLLED EVALUATION**

and a persistent concise statement such as:

> **Not clinically validated. Not for clinical decision-making.**

The UI must not imply:

- diagnosis;
- treatment recommendation;
- clinical decision support;
- validated medical advice;
- patient-specific clinical decision-making.

Question guidance is intended to help users formulate questions, not tell them what medical action to take.

---

## 6. Strict technical boundaries

Track 1C MUST NOT change:

- `/chat` contract;
- `/chat/query` contract;
- CER;
- CER orchestration;
- retrieval;
- PP resolution;
- evidence capture;
- 239-case mechanism;
- 239-PP execution logic;
- backend navigation context;
- RAG integration;
- LLM-generated question suggestions;
- patient-specific reasoning;
- patient-state persistence;
- new clinical decision logic.

Do not create a new backend endpoint merely for UI navigation.

The existing Track 1B path must remain functional:

Browser → `/chat` → `/chat/query` → existing governed CER path → PP-0002 + CKO → response.

Do not generalize PP-0002 in Track 1C.

Do not implement Track 2.

---

## 7. Long-term architecture — explicitly deferred

The project has a longer-term navigation concept:

Patient Context → Navigation Context → Evidence Retrieval → Safe Response.

Track 1C must NOT implement this full architecture.

The following remain deferred:

- navigation-context backend;
- dynamic retrieval driven by navigation;
- RAG integration;
- LLM interpretation;
- patient-state persistence;
- patient-specific navigation reasoning.

Track 1C only implements the front-end presentation/interaction layer that expresses the approved navigation concept.

---

## 8. Responsive/mobile scope

Basic responsive browser layout is allowed and should be implemented where straightforward.

However, comprehensive mobile validation, real-world case validation, and subsequent UX improvement based on actual user feedback are deferred to the later validation/improvement stage.

Do not turn responsive design into an open-ended refinement loop.

---

## 9. Legacy UI source — approved use

The uploaded legacy gastric-cancer-nomogram source is a UI/UX reference and may be selectively reused/adapted.

Approved:

- UI components where compatible;
- layout patterns;
- styling patterns;
- typography;
- spacing;
- cards;
- navigation presentation;
- interaction/presentation patterns.

Forbidden:

- calculation logic;
- clinical/model logic;
- model parameters;
- clinical data;
- legacy backend;
- legacy application/domain architecture;
- unrelated application logic;
- wholesale copying of the legacy application.

Exact boundary:

> The uploaded legacy gastric-cancer-nomogram source is a visual/UX reference only. Reuse design ideas and presentation patterns where appropriate. Do not import its calculation logic, clinical/model logic, data, or application architecture into Phase 6.

Selective reuse is preferred only when it reduces implementation complexity or improves consistency without introducing legacy coupling or dependencies.

If reuse is not technically appropriate, implement the equivalent UI cleanly within the current Phase 6 architecture.

---

## 10. Acceptance target

### A — Professional UI

- Clear product identity.
- Clear visual hierarchy.
- Professional typography and spacing.
- Coherent cards/panels.
- Readable conversation history.
- Professional desktop presentation.
- Basic responsive browser behavior.
- No bare-prototype appearance.

### B — Patient-oriented navigation

- “Not sure what to ask? Start with your situation.”
- Situation cards.
- Patient-centered Option B wording.
- Two-tier navigation.

### C — Question guidance

- Situation → Topic → Question starter.
- Question starter populates the existing input.
- User can edit.
- User explicitly sends.
- No auto-submit.

### D — Interaction

- Existing Send behavior remains functional.
- Clear loading state.
- Clear error state.
- Usable keyboard interaction.
- Conversation history remains readable.
- Responsive interaction is reasonable.

### E — Governance

- Research / Controlled Evaluation identity is visible.
- Non-clinical-validation boundary is visible.
- UI does not imply clinical authority.

### F — Technical boundary

No changes to the contracts or mechanisms listed in Section 6.

### G — Regression / human acceptance

- Existing test suite passes.
- Track 1A behavior remains intact.
- Track 1B real CER behavior remains intact.
- `git diff --check` passes.
- Browser human run demonstrates the redesigned UI while still completing the existing Track 1B flow.

---

## 11. Implementation discipline

Claude Code must:

1. inspect the current repository and Track 1A/1B implementation;
2. inspect the legacy UI source;
3. identify reusable UI/presentation elements;
4. produce an implementation plan before coding;
5. STOP and report if a genuine ambiguity requires a new decision;
6. implement only after the implementation plan is reviewed/approved;
7. keep changes additive/minimal where possible;
8. preserve existing backend/CER behavior;
9. run focused and full regression tests;
10. report exactly what changed and what was not changed.

No commit or push during this task.

---

## 12. Explicit non-goals

Track 1C does not:

- deploy clinical functionality;
- claim clinical validation;
- implement 239-PP execution;
- implement batch evaluation;
- modify the execution manifest;
- redesign CER;
- redesign retrieval;
- introduce patient-specific AI reasoning;
- create a remediation/refinement loop.

---

## 13. Handoff state

Track 1A: PASS / CLOSED.  
Track 1B: PASS / CLOSED.  
Track 1C: READY FOR IMPLEMENTATION-PLAN INSPECTION.

Current controlled-evaluation coverage remains:

**1 / 239**

Track 2 remains separate and approved as the next execution workstream after Track 1C.

Phase 7 remains unchanged.
