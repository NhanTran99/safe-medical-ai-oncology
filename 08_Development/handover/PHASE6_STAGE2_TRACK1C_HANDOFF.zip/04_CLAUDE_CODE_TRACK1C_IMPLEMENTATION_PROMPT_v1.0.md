# CLAUDE CODE PROMPT
## Phase 6 Stage 2 — Track 1C
### Controlled Chat UI — Usability / Presentation Polish
### INSPECTION + IMPLEMENTATION PLAN ONLY — DO NOT CODE YET

You are working on the Safe Medical AI Oncology project.

You already have the full repository/project materials available in the Claude project. Do not assume this prompt replaces the repository or governance materials.

Read these handoff materials first:

1. `PHASE6_STAGE2_TRACK1C_IMPLEMENTATION_SPEC_v1.0.md`
2. `PHASE6_STAGE2_TRACK1A_CLOSEOUT_RECORD_v1.0.md`
3. `PHASE6_STAGE2_TRACK1B_CLOSEOUT_RECORD_v1.0.md`

Also inspect the uploaded legacy UI source under the supplied legacy reference folder if available.

---

# 1. Current project state

Phase 6 Stage 2 is in progress.

Track 1A:
- PASS / CLOSED
- browser-facing Controlled Chat UI shell exists.

Track 1B:
- PASS / CLOSED
- real browser `/chat` → `/chat/query` → existing governed CER path → PP-0002 + CKO → deterministic response has been human-verified.
- focused tests: 16 passed.
- full implementation regression: 308 passed.

Current controlled-evaluation coverage remains:

**1 / 239**

Track 2 is a separate approved workstream and must NOT be implemented in Track 1C.

The ultimate Phase 6 goal remains:

> A real browser-based chatbot interface that can be used for controlled testing and real-world feedback, with all 239 PP eventually covered by controlled evaluation, while clearly declaring that the system is not clinically validated and is not for clinical decision-making.

---

# 2. Your task NOW

This turn is an **inspection and implementation-planning task only**.

DO NOT write or modify code yet.

Inspect:

1. current Track 1A/1B implementation;
2. current tests;
3. current FastAPI `/chat` and `/chat/query` boundaries;
4. existing project architecture relevant to the UI;
5. the legacy gastric-cancer-nomogram source;
6. the Track 1C specification and closeout records.

Then produce a concise but concrete implementation plan for Track 1C.

STOP after the plan.

Do not commit.
Do not push.
Do not modify files.

---

# 3. Approved Track 1C objective

Upgrade the current functional chat prototype into a professional, readable, patient-oriented controlled research interface.

The approved UX concept is:

**Understand → Ask → Explore**

The first screen should help a user who does not know what to ask:

> **Not sure what to ask? Start with your situation.**

This is question formulation/orientation, NOT clinical triage.

---

# 4. Approved two-tier navigation

Tier 1:

**Situation**

Examples:
- I was recently diagnosed
- I'm receiving treatment
- I'm preparing for surgery
- I'm concerned about recurrence
- I'm in follow-up
- I want to understand my cancer

Tier 2:

**Topic → Question starter**

Example:

Situation:
`I'm receiving treatment`

Topic:
`Side effects`

Question starters:
- What side effects can this treatment cause?
- What symptoms should I discuss with my care team?
- What information should I keep track of?

When a user selects a question starter:

**populate the existing chat input.**

The user may edit it.

The user must explicitly press Send.

**Never auto-submit a question starter.**

---

# 5. Visual target

The UI should feel like a serious oncology research application, not a bare prototype and not a generic ChatGPT clone.

Preferred characteristics:
- strong application identity;
- professional header;
- clear hierarchy;
- whitespace;
- readable typography;
- coherent cards;
- polished conversation history;
- clear status presentation;
- visible research/controlled-evaluation boundary;
- usable desktop layout;
- basic responsive browser behavior.

Preferred positioning:

**Safe Medical AI Oncology — Controlled Research Interface**

Possible visible status:

**RESEARCH / CONTROLLED EVALUATION**

Persistent concise boundary:

**Not clinically validated. Not for clinical decision-making.**

Do not create a hospital portal or imply clinical authority.

---

# 6. Legacy source usage — IMPORTANT

The uploaded legacy gastric-cancer-nomogram source is available as a reference.

Use it as follows:

> **The uploaded legacy gastric-cancer-nomogram source is a visual/UX reference only. Reuse design ideas and presentation patterns where appropriate. Do not import its calculation logic, clinical/model logic, data, or application architecture into Phase 6.**

You MAY inspect and selectively reuse/adapt:
- UI components;
- layout patterns;
- styling;
- typography;
- spacing;
- cards;
- navigation presentation;
- interaction/presentation patterns.

You MUST NOT import:
- calculation logic;
- clinical/model logic;
- model parameters;
- clinical data;
- legacy backend;
- legacy application/domain architecture;
- unrelated business/domain logic.

Do NOT copy the legacy application wholesale.

Prefer reuse/adaptation only where it:
1. fits the approved Track 1C visual target;
2. is compatible with the current Phase 6 architecture;
3. reduces implementation complexity or improves consistency;
4. does not introduce inappropriate legacy dependencies/coupling.

If direct reuse is not appropriate, implement the equivalent presentation cleanly within the current Phase 6 UI.

---

# 7. HARD TECHNICAL BOUNDARY

Do NOT modify:

- `/chat` contract;
- `/chat/query` contract;
- CER;
- CER orchestration;
- retrieval;
- PP resolution;
- evidence capture;
- 239-case mechanism;
- 239-PP execution;
- backend navigation context;
- RAG;
- LLM-generated question suggestions;
- patient-specific reasoning;
- patient-state persistence;
- clinical decision logic.

Do NOT implement Track 2.

Do NOT generalize PP-0002.

Do NOT build a batch runner.

Do NOT create a new backend endpoint merely to support UI navigation.

The existing Track 1B path must remain intact:

Browser → `/chat` → `/chat/query` → existing governed CER path → PP-0002 + CKO → response.

---

# 8. Deferred architecture

The project has a longer-term concept:

Patient Context
→ Navigation Context
→ Evidence Retrieval
→ Safe Response

Do NOT implement this architecture in Track 1C.

Do NOT introduce backend navigation context, dynamic retrieval, RAG, LLM interpretation, or patient-state persistence.

Track 1C only implements the front-end interaction/presentation layer expressing the approved navigation concept.

---

# 9. Responsive scope

Basic responsive browser layout is allowed.

Comprehensive mobile validation, real-world case validation, and user-feedback-driven improvement are deferred to the later validation/improvement stage.

Do not create an open-ended mobile refinement loop.

---

# 10. Required inspection questions

Before proposing implementation, explicitly determine:

1. What is the current UI architecture?
2. Which current files should remain untouched?
3. Which UI files need modification?
4. Can the existing UI be upgraded without changing backend contracts?
5. Which legacy UI components/patterns are genuinely reusable?
6. Which legacy components should NOT be reused and why?
7. Would reuse introduce dependencies or architectural coupling?
8. How will the two-tier situation/topic/question-starter interaction be represented purely at the UI layer?
9. How will question starters populate the existing input without changing `/chat/query`?
10. How will existing Track 1B behavior be protected by tests?
11. What focused tests should be added/updated?
12. What browser acceptance checks should be performed by the human operator?

---

# 11. Required output

Return an implementation plan with these sections:

## A. Repository inspection findings
Exact files/modules inspected and relevant findings.

## B. Proposed UI architecture
Describe the proposed page/component structure.

## C. Legacy reuse/adaptation assessment
List:
- reusable;
- adapt;
- do not reuse;
- reason for each.

## D. Exact files to change/create
Provide repository-relative paths.

## E. Backend-boundary confirmation
Explicitly confirm `/chat` and `/chat/query` contracts remain unchanged.

## F. Interaction flow
Show:

Situation
→ Topic
→ Question starter
→ populate input
→ user edit
→ Send
→ existing `/chat/query`
→ existing Track 1B CER path.

## G. Test plan
Focused tests + regression expectations.

## H. Browser human-run plan
Exact checks needed after implementation.

## I. Scope confirmation
Explicitly state:
- no CER change;
- no retrieval change;
- no PP generalization;
- no 239-case execution;
- no batch architecture;
- no backend navigation engine;
- no clinical reasoning;
- no clinical validation claim.

## J. Ambiguities / decisions required

If and ONLY if a genuine implementation dependency requires a new decision, STOP and identify it clearly.

Do NOT invent a solution and silently convert it into a requirement.

If there is no genuine ambiguity, state:

**NO NEW DECISION REQUIRED.**

---

# 12. Final instruction

This task ends after the inspection report and implementation plan.

**Do not code.**
**Do not modify files.**
**Do not commit.**
**Do not push.**

Wait for human review/approval before implementing Track 1C.
