# SAFE MEDICAL AI ONCOLOGY
# CLAUDE CODE HANDOFF — PROJECT CONTEXT & PHASE STATUS
Version 1.0 — 2026-08-15

## 1. Purpose

This document is the project-level context for Claude Code.

Claude Code is the IMPLEMENTATION AGENT.
It must inspect the repository uploaded into the Claude project and implement only the already-approved Phase 6 Stage 2 work.

This document is not a replacement for the repository.
The repository's governed documents remain the primary source for detailed project architecture, contracts, governance, and implementation history.

## 2. Ultimate Phase 6 goal — LOCKED

Phase 6 must ultimately achieve BOTH:

1. Open a browser and chat with the system like a real controlled chatbot through the Controlled Chat UI.
2. Complete controlled evaluation coverage of all 239 Population Packages (PP), with traceable execution evidence and final 239/239 coverage.

Do NOT reinterpret Phase 6 as unrestricted clinical deployment.
The operational boundary remains Research / Development / Controlled Evaluation.
Formal clinical validation and clinical deployment authorization are separate and are not implied by this work.

## 3. Project phase history

### Phase 1 — Foundation & System Architecture
COMPLETED.

### Phase 2 — Clinical Knowledge Curation / Architecture
COMPLETED.

### Phase 3 — Knowledge Population & Clinical Content Development
CLOSED.

Established the governed population:
- PP-0001 → PP-0239
- 239 Population Packages
- 956 canonical Gold artifacts

### Phase 4 — Repository & Integration Verification
CLOSED / PASS.

Repository and integration integrity for the governed PP population was verified.

### Phase 5 — Runtime Implementation & Safety Enforcement
CLOSED / PASS.

Completed implementation tasks:
- Task #002 — Implementation Scaffolding
- Task #003 — Retrieval Foundation
- Task #004 — Filesystem Repository Source
- Task #005 — Runtime Evidence Package
- Task #006 — Runtime Integration / GenerationContext
- Task #007 — Generation Boundary
- Task #008 — Validation Boundary
- Task #009 — Safety Enforcement Boundary

Phase 5 technical acceptance and regression verification were completed.

### Phase 6 — Validation / Controlled Evaluation
CURRENT PHASE.

Phase 6 Architecture / Scope Gate is LOCKED.
Phase 6 decision batches B01 → B21 are locked in the supplied governance history.

Phase 7 remains unchanged and must NOT be redefined from this work.

## 4. Stage 1 completed evidence

CER Run #001:
- PASS / CLOSED
- PP-0002
- CKO
- FilesystemRepositorySource
- deterministic local provider
- controlled CER path demonstrated

Webapp Controlled Trial #001:
- PASS / CLOSED
- POST /cer/evaluate
- PP-0002 + CKO
- real HTTP trial demonstrated

Current confirmed controlled-evaluation coverage:
1 / 239 PP.

Only PP-0002 is currently evidenced as controlled-evaluated.
Do not claim broader execution coverage merely because 239 PP exist in the repository.

## 5. Current Phase 6 Stage 2

Stage 2 is explicitly focused on the two unresolved end-state objectives:

A. Controlled Chat UI
B. Controlled evaluation coverage for all 239 PP

The current implementation historically demonstrated:
- FastAPI API boundary
- Swagger UI
- POST /cer/evaluate
- controlled PP-0002 + CKO boundary

It did NOT yet demonstrate a custom browser Chat UI or 239-PP controlled execution.

## 6. Locked working principle

Do not:
- invent new requirements;
- invent new governance requirements;
- silently expand scope;
- reopen closed Gold PP eligibility/content review;
- reopen CER #001;
- reopen Webapp Trial #001;
- invent a batch-evaluation architecture;
- create automatic remediation/refinement loops;
- turn recommendations into requirements;
- treat technical controlled evaluation as clinical validation.

If an error is found downstream:
diagnose the layer where it originates and correct that layer.

Do not automatically change Gold PP governance metadata because a later gate finds an implementation/evidence problem.

## 7. Role split

Claude Code:
- inspect repository;
- implement approved code changes;
- run tests available in its environment;
- report exact changes and evidence;
- do not make governance decisions.

ChatGPT / project strategist:
- provide context and implementation prompts;
- interpret contracts and governance boundaries;
- review Claude Code output;
- identify whether changes stay within approved scope;
- guide the next gate.

User:
- approves decisions where required;
- runs/validates commands in the intended environment;
- provides runtime evidence;
- approves further changes when a genuinely new decision is required.

## 8. Important source-of-truth rule

The user will upload the nine repository folders/packages into the Claude project.

Claude Code must inspect the repository itself and use the governed documents inside it for detailed contracts.

Do not assume that this handoff alone contains every implementation detail.

## 9. Current state in one view

Phase 1 — COMPLETE
Phase 2 — COMPLETE
Phase 3 — CLOSED
Phase 4 — CLOSED / PASS
Phase 5 — CLOSED / PASS
Phase 6 — CURRENT
Phase 6 Stage 1 — CER #001 PASS/CLOSED; Webapp Trial #001 PASS/CLOSED
Phase 6 Stage 2 — CURRENT

Current confirmed coverage:
1 / 239

Phase 6 ultimate goal:
Browser Controlled Chat UI + 239/239 controlled evaluation.

Phase 7:
UNCHANGED.
