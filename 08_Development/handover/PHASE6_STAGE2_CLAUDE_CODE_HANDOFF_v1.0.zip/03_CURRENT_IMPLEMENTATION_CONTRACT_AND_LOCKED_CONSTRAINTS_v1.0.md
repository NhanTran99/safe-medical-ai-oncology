# PHASE 6 STAGE 2
# CURRENT IMPLEMENTATION CONTRACT & LOCKED CONSTRAINTS
Version 1.0 — 2026-08-15

## 1. Authority and purpose

This document is a compact implementation-facing contract for Claude Code.

It summarizes the current approved implementation boundary.
Detailed source documents in the uploaded repository remain authoritative for their respective domains.

## 2. Current implemented boundary proven by Stage 1

Proven:
- CER implementation foundation;
- FilesystemRepositorySource;
- controlled PP-0002 + CKO endpoint;
- deterministic local provider;
- POST /cer/evaluate;
- real HTTP controlled trial;
- validation/safety pipeline;
- evidence-capture operational mechanism.

Stage 1 evidence:
- CER Run #001 = PASS / CLOSED
- Webapp Controlled Trial #001 = PASS / CLOSED
- confirmed controlled-evaluation coverage = 1/239

These are historical closed milestones.
Do not rewrite them to make Stage 2 look cleaner.

## 3. Gold knowledge population

Phase 3 established:
- PP-0001 → PP-0239
- 239 Population Packages
- 956 canonical Gold artifacts

Current user decision:
- all 239 PP are approved as Gold PP / eligible;
- PP eligibility/content review is CLOSED;
- do not reopen this gate.

This approval does not constitute 239 controlled execution.

## 4. Stage 2 execution target

Target:
- Controlled Chat UI in a browser;
- controlled evaluation of all 239 PP.

The system must preserve the distinction between:
- governed knowledge population;
- controlled evaluation;
- formal validation;
- clinical authorization.

## 5. Evidence contract

For a controlled execution record, preserve where applicable:
- Case ID;
- PP ID;
- controlled question/input;
- requirement/objective;
- expected behavior;
- acceptance criterion;
- observed behavior;
- result;
- Run ID;
- Trace ID;
- timestamp;
- implementation/system baseline;
- runtime context;
- knowledge/evidence version;
- safety state;
- supporting evidence references;
- provenance;
- review/disposition state.

Execution Record and Validation Record remain distinct.

## 6. Execution baseline

Before controlled execution, the actual Phase 6 execution baseline must be identifiable/reproducible, including as applicable:
- repository/commit;
- runtime/environment;
- configuration;
- knowledge baseline;
- evidence baseline;
- safety configuration.

Do not silently promote a draft artifact to the execution baseline.

## 7. Case/manifest contract

Expected:
- 239 primary cases;
- one primary case per PP;
- deterministic PP ↔ Case ID mapping;
- frozen master manifest;
- predefined controlled question;
- expected behavior;
- known target PP;
- no silent post-freeze edits.

Manifest status and execution status are distinct.

## 8. Chat UI boundary

The Chat UI is:
- browser interaction boundary;
- question input surface;
- PP navigation/selection surface;
- response presentation surface.

The Chat UI is NOT:
- a replacement CER;
- a replacement retrieval engine;
- a replacement safety layer;
- a replacement validation layer;
- a clinical reasoning engine.

Conceptual path:

Browser
→ Chat UI
→ question
→ PP navigation
→ CER
→ validation
→ delivery
→ browser

## 9. Multi-PP execution boundary

The current Stage 1 implementation was intentionally restricted to:
PP-0002 + CKO.

Stage 2 needs to expand the controlled execution surface sufficiently to reach the approved 239-PP objective.

Do not silently generalize beyond what the approved Stage 2 contract requires.

First inspect whether the current implementation already supports generalized case execution.

## 10. Batch rule

“Batch” is an operational possibility, not an approved architecture.

Do not:
- invent a batch runner;
- invent batch-specific contracts;
- invent batch-specific governance;
- add batching if the existing mechanism can execute the approved cases.

If a minimal iteration mechanism is required, it must be justified by a concrete implementation gap and remain within the approved case/evidence contract.

## 11. Safety / clinical boundary

Phase 5 safety enforcement remains inherited.

Controlled evaluation remains:
Research / Development / Controlled Evaluation Only.

Do not claim:
- clinical validation;
- clinical decision-making authorization;
- clinical deployment authorization.

VC-CLIN remains deferred where the required governed clinical source/case input is unavailable.

## 12. Phase 7

Phase 7 scope is unchanged.

Do not redesign or advance Phase 7 because of Stage 2 implementation work.

## 13. Change discipline

Every proposed code change must answer:
1. What approved contract does it implement?
2. What existing capability does it reuse?
3. Why is the change necessary?
4. What tests demonstrate it?
5. Does it change any locked boundary?

If it introduces a genuinely new contract or governance decision:
STOP and report it rather than silently implementing it.

## 14. Review workflow

The intended engineering loop is:

Claude Code
→ inspect / code
→ Claude reports implementation + evidence
→ ChatGPT reviews against project contract
→ user runs/tests in intended environment
→ evidence returned
→ ChatGPT reviews
→ refine only if needed
→ repeat only as necessary

This is an engineering iteration loop.
It must NOT become an automatic governance/remediation loop.

## 15. Current state

Phase 6 Stage 2:
ACTIVE.

Already satisfied/closed:
- Gold PP eligibility;
- S2-A;
- S2-B decision;
- S2-C decision;
- S2-D decision;
- CER #001;
- Webapp Trial #001;
- evidence-capture operational check;
- cleanup reconciliation;
- completeness audit.

Still to achieve:
- Controlled Chat UI implementation + E2E evidence;
- 239-case execution capability;
- frozen/reproducible execution baseline;
- Pre-Execution QA PASS;
- GO/NO-GO;
- 239/239 controlled execution evidence;
- final evidence/coverage reconciliation;
- Phase 6 closure.

Current confirmed execution coverage:
1/239.
