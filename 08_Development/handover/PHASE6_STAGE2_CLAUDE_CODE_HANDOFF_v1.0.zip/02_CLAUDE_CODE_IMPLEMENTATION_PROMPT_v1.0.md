# CLAUDE CODE — PHASE 6 STAGE 2 IMPLEMENTATION PROMPT
Version 1.0 — 2026-08-15

## ROLE

You are the coding agent for the Safe Medical AI Oncology project.

The user has uploaded the project's repository as nine repository folders/packages into the Claude project.

READ THE REPOSITORY BEFORE CODING.

Your first job is to understand the existing implementation and determine what is reusable.
Do not redesign the system based on assumptions.

## LOCKED END GOAL

Phase 6 must ultimately achieve:

1. Browser → Controlled Chat UI → real controlled chatbot interaction.
2. Controlled evaluation coverage of all 239 approved Gold Population Packages.

Both are required.

## LOCKED GOVERNANCE BOUNDARIES

Do NOT:
- reopen Gold PP eligibility/content review;
- modify Gold PP governance metadata;
- reopen CER Run #001;
- reopen Webapp Controlled Trial #001;
- redesign CER merely to support Stage 2;
- invent a new governance layer;
- invent a new validation layer;
- invent a batch-evaluation architecture;
- create an automatic remediation loop;
- claim 239/239 execution before actual execution evidence exists;
- claim clinical validation or clinical deployment authorization.

If you discover a problem, classify its originating layer:
- case/manifest;
- UI;
- execution mechanism;
- evidence capture;
- runtime/environment;
- baseline/configuration;
- genuinely Gold PP content.

Fix only the originating implementation layer unless a genuinely new governance decision is required.

## APPROVED STAGE 2 CONTRACTS

### S2-B — Controlled Chat UI

The browser-facing UI must be a controlled interaction/presentation boundary above the existing governed runtime.

Intended conceptual flow:

Browser
→ Chat UI
→ user question
→ approved PP navigation/selection mechanism
→ CER
→ validation
→ delivery
→ browser response

The normal user should not need to manually enter a PP ID.

Do not bypass CER, validation, safety, or governed knowledge boundaries.

Do not turn the Chat UI into a second clinical reasoning engine.

### S2-C — 239 controlled evaluation

Approved scope:
- 239 PP
- 239 primary evaluation cases
- one primary case per PP
- controlled predefined questions
- deterministic case identity
- controlled execution
- evidence captured per case
- final coverage target = 239/239

Case failure must not automatically create a remediation loop or automatically rewrite the case/question.

Batch execution is only a possible operational organization.
NO SPECIFIC BATCH RUNNER ARCHITECTURE IS APPROVED.

### S2-D — Case / Manifest

The case contract requires:
- stable Case ID
- deterministic PP ↔ Case mapping
- governed PP-derived case
- representative controlled question
- expected behavior
- known PP target before execution
- frozen master manifest
- no silent post-freeze modification

The manifest does not itself authorize execution.

## CURRENT FOUR CHECKS

### Check 1 — Controlled Chat UI
REQUIRED.
Current historical evidence proves API/HTTP, not a custom browser Chat UI.
Implement only the approved S2-B surface.

### Check 2 — Gold PP population
SATISFIED / CLOSED.
239 PP are approved as Gold / eligible.
Do not re-review them.

Important distinction:
239 PP being Gold does NOT mean they have been controlled-executed.

### Check 3 — 239-case execution capability
UNKNOWN / NEEDS CAPABILITY AUDIT.

BEFORE designing a batch runner:
inspect the current implementation.

Determine whether existing code already supports:
- loading an evaluation case;
- resolving PP identity;
- selecting the target artifact;
- invoking the existing CER path;
- executing deterministically;
- capturing an outcome;
- producing the approved execution evidence record.

If existing capability is sufficient:
REUSE IT.

If insufficient:
implement only the minimal extension required by the approved 239-case execution contract.

Do not invent a new execution architecture simply because there are 239 cases.

### Check 4 — Phase 6 completion evidence
NOT YET ACHIEVED.

Final completion requires:
A. Browser Chat UI E2E evidence.
B. 239/239 controlled execution evidence.
C. final evidence / coverage reconciliation.

## TASK ORDER

### STEP 1 — Repository inspection and capability audit

Before modifying code:
- inspect all nine uploaded repository packages;
- locate project foundation and scope;
- locate architecture and governance;
- locate Phase 3/4 knowledge and repository state;
- locate Phase 5 implementation;
- locate Phase 6 CER/Webapp evidence;
- locate current CER/API implementation;
- locate evidence-capture implementation;
- locate evaluation/case/manifest mechanisms;
- locate tests.

Then report:
1. reusable capability;
2. missing capability;
3. minimal required change;
4. environment dependencies.

Do NOT code a batch runner before this audit.

### STEP 2 — Controlled Chat UI

Implement the already-approved S2-B contract.

The implementation must preserve the existing governed runtime boundaries.

### STEP 3 — 239-case execution capability

Only after Step 1:
- reuse existing capability if possible;
- otherwise implement the smallest extension necessary to execute the frozen cases.

Do not create a new architecture unless the existing implementation cannot satisfy the approved contract.

### STEP 4 — Tests

Run targeted tests for:
- Chat UI;
- PP navigation;
- CER integration;
- multi-case execution capability;
- evidence capture;
- relevant regression.

Report environment limitations honestly.

### STEP 5 — Report

Return:
A. repository understanding;
B. capability audit;
C. implementation changes;
D. files changed;
E. tests and exact results;
F. evidence generated;
G. remaining blockers;
H. explicit governance statement:
   - Gold PP unchanged;
   - CER #001 unchanged;
   - Webapp Trial #001 unchanged;
   - no new governance requirement;
   - no automatic remediation;
   - no full 239 execution unless separately authorized by the project workflow.

## DO NOT EXECUTE THE FULL 239-CASE CAMPAIGN YET

This coding step is preparation/implementation.

Full 239-case execution occurs only after the approved execution baseline, Pre-Execution QA, and GO/NO-GO are satisfied.

## IMPORTANT

If you encounter an ambiguity:
- distinguish FACT from INFERENCE;
- inspect the repository first;
- do not silently invent a requirement;
- ask for clarification only when a genuine approved-contract dependency cannot be resolved from the supplied materials.
